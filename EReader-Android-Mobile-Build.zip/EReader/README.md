# E-Reader (Android starter project)

A minimal Android reader starter app with a black reading surface and white text. It opens local PDF and EPUB files through Android's system file picker. Files are not uploaded anywhere.

## Build
1. Install Android Studio (Giraffe or newer) and Android SDK 35.
2. Open this folder (`EReader`) in Android Studio.
3. Allow Gradle sync.
4. Connect an Android phone with USB debugging enabled, or create an emulator.
5. Press Run. To create an APK: Build > Build Bundle(s) / APK(s) > Build APK(s).

## Notes
- PDF rendering uses Android's built-in `PdfRenderer`.
- EPUB support in this starter is intentionally basic: it extracts HTML/XHTML entries and displays them in a dark WebView. Some EPUBs with complex navigation, fonts, or layouts may not render perfectly.
- This is source code, not a prebuilt APK. A full EPUB engine, saved reading progress, bookmarks, and adjustable typography are good next improvements.
