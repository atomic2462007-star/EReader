# Build E-Reader APK using only an Android phone

This project includes a GitHub Actions workflow at `.github/workflows/build-apk.yml`.
It builds a debug APK in GitHub's cloud; Android Studio or a computer is not needed locally.

1. Create a GitHub account (if needed) and a new **public** repository named `EReader`.
2. Extract this ZIP on your phone using your file manager or an archive app.
3. In the repository on github.com, use **Add file → Upload files** to upload the project contents, keeping the `.github/workflows` folder and the `EReader` folder structure. Commit to `main`.
4. Open the repository's **Actions** tab. Select **Build Android APK** and, if needed, tap **Run workflow**.
5. When the run finishes successfully, open it and download the **EReader-debug-apk** artifact.
6. Extract the downloaded artifact ZIP and tap `app-debug.apk` to install. Android may ask you to allow installs from that browser/file manager.

If the repository is private, GitHub Actions minutes/availability depend on the account plan. A public repository avoids using private-repository minutes, but the source code will be publicly visible. Do not upload personal files or secrets.
