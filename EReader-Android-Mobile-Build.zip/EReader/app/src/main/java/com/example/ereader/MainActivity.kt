package com.example.ereader

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.Bundle
import android.os.ParcelFileDescriptor
import android.view.Gravity
import android.view.View
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.io.FileOutputStream
import java.util.zip.ZipFile

class MainActivity : Activity() {
    private lateinit var root: LinearLayout
    private lateinit var content: FrameHost
    private lateinit var title: TextView
    private lateinit var pageLabel: TextView
    private var pdfRenderer: PdfRenderer? = null
    private var pdfDescriptor: ParcelFileDescriptor? = null
    private var pdfPageIndex = 0
    private var pdfImage: ImageView? = null
    private var currentUri: Uri? = null

    companion object { private const val PICK_BOOK = 41 }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK
        buildHome()
    }

    private fun buildHome() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.BLACK)
            setPadding(dp(18), dp(18), dp(18), dp(12))
        }
        val header = TextView(this).apply {
            text = "E-Reader"
            textSize = 25f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(0, dp(8), 0, dp(18))
        }
        root.addView(header, LinearLayout.LayoutParams(-1, -2))
        title = TextView(this).apply {
            text = "مكتبتك الخاصة"
            textSize = 22f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(0, dp(12), 0, dp(8))
        }
        root.addView(title)
        val intro = TextView(this).apply {
            text = "افتح كتاب PDF أو EPUB من ملفات جهازك"
            textSize = 15f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, dp(22))
        }
        root.addView(intro)
        val open = makeButton("اختيار كتاب من الجهاز") { chooseBook() }
        root.addView(open, LinearLayout.LayoutParams(-1, dp(54)))
        val note = TextView(this).apply {
            text = "القراءة باللون الأبيض على خلفية سوداء\nلا يحتاج التطبيق إلى إنشاء نسخة PDF أو رفع ملفاتك إلى الإنترنت."
            textSize = 14f
            setTextColor(Color.GRAY)
            gravity = Gravity.CENTER
            setPadding(dp(12), dp(22), dp(12), 0)
        }
        root.addView(note)
        content = FrameHost(this)
        root.addView(content, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun chooseBook() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("application/pdf", "application/epub+zip", "application/epub+zip"))
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }
        startActivityForResult(intent, PICK_BOOK)
    }

    @Deprecated("Deprecated by Android, kept for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != PICK_BOOK || resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        currentUri = uri
        try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
        val name = queryName(uri)
        title.text = name
        val mime = contentResolver.getType(uri).orEmpty()
        if (mime == "application/pdf" || name.endsWith(".pdf", true)) openPdf(uri)
        else openEpub(uri)
    }

    private fun openPdf(uri: Uri) {
        try {
            closePdf()
            pdfDescriptor = contentResolver.openFileDescriptor(uri, "r")
                ?: throw IllegalStateException("تعذر فتح الملف")
            pdfRenderer = PdfRenderer(pdfDescriptor!!)
            pdfPageIndex = 0
            pdfImage = ImageView(this).apply {
                adjustViewBounds = true
                scaleType = ImageView.ScaleType.FIT_CENTER
                setBackgroundColor(Color.BLACK)
            }
            content.removeAllViews()
            content.addView(pdfImage, LinearLayout.LayoutParams(-1, 0, 1f))
            val controls = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
            controls.addView(makeButton("السابق") { showPdfPage(pdfPageIndex - 1) }, LinearLayout.LayoutParams(0, dp(48), 1f))
            pageLabel = TextView(this).apply { setTextColor(Color.WHITE); gravity = Gravity.CENTER; textSize = 14f }
            controls.addView(pageLabel, LinearLayout.LayoutParams(0, dp(48), 1f))
            controls.addView(makeButton("التالي") { showPdfPage(pdfPageIndex + 1) }, LinearLayout.LayoutParams(0, dp(48), 1f))
            content.addView(controls, LinearLayout.LayoutParams(-1, dp(52)))
            showPdfPage(0)
        } catch (e: Exception) { showError("لم أستطع فتح ملف PDF: ${e.message}") }
    }

    private fun showPdfPage(index: Int) {
        val renderer = pdfRenderer ?: return
        if (index !in 0 until renderer.pageCount) return
        try {
            val page = renderer.openPage(index)
            val scale = resources.displayMetrics.density.coerceAtLeast(1f)
            val width = (page.width * scale * 1.35f).toInt().coerceAtLeast(600)
            val height = (page.height.toFloat() / page.width * width).toInt()
            val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
            bitmap.eraseColor(Color.WHITE)
            page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
            page.close()
            pdfImage?.setImageBitmap(bitmap)
            pdfPageIndex = index
            pageLabel.text = "${index + 1} / ${renderer.pageCount}"
        } catch (e: Exception) { showError("تعذر عرض الصفحة") }
    }

    private fun openEpub(uri: Uri) {
        try {
            val temp = File(cacheDir, "reading-book.epub")
            contentResolver.openInputStream(uri)?.use { input -> FileOutputStream(temp).use { output -> input.copyTo(output) } }
                ?: throw IllegalStateException("تعذر قراءة الملف")
            val html = extractEpubHtml(temp)
            content.removeAllViews()
            val web = WebView(this).apply {
                setBackgroundColor(Color.BLACK)
                settings.javaScriptEnabled = false
                settings.defaultTextEncodingName = "UTF-8"
                webViewClient = WebViewClient()
                loadDataWithBaseURL("file://${cacheDir.absolutePath}/", html, "text/html", "UTF-8", null)
            }
            content.addView(web, LinearLayout.LayoutParams(-1, -1))
        } catch (e: Exception) { showError("تعذر فتح EPUB. قد يكون تنسيق الكتاب غير مدعوم: ${e.message}") }
    }

    private fun extractEpubHtml(file: File): String {
        ZipFile(file).use { zip ->
            val entries = zip.entries().asSequence().filter {
                !it.isDirectory && (it.name.endsWith(".xhtml", true) || it.name.endsWith(".html", true) || it.name.endsWith(".htm", true))
            }.toList().sortedBy { it.name }
            if (entries.isEmpty()) throw IllegalArgumentException("لا توجد صفحات نصية في الكتاب")
            val body = StringBuilder()
            for (entry in entries) {
                val raw = zip.getInputStream(entry).bufferedReader(Charsets.UTF_8).use { it.readText() }
                val cleaned = raw.replace(Regex("(?is)<head.*?</head>"), "")
                    .replace(Regex("(?is)<script.*?</script>"), "")
                    .replace(Regex("(?is)<style.*?</style>"), "")
                body.append("<section>").append(cleaned).append("</section><hr>")
            }
            return """<!doctype html><html dir="auto"><head><meta name="viewport" content="width=device-width, initial-scale=1"><meta charset="utf-8"><style>
                html,body{background:#000!important;color:#fff!important;margin:0;padding:0}
                body{font-family:serif;font-size:21px;line-height:1.9;padding:22px;color:#f5f5f5}
                p,div,span,h1,h2,h3,li{color:#f5f5f5!important;background:transparent!important}
                img{max-width:100%;height:auto} a{color:#aaa} section{margin-bottom:30px} hr{border:0;border-top:1px solid #333;margin:28px 0}
                </style></head><body>$body</body></html>"""
        }
    }

    private fun queryName(uri: Uri): String {
        var name = "كتابك"
        contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) name = c.getString(0) ?: name
        }
        return name
    }

    private fun makeButton(label: String, action: () -> Unit) = Button(this).apply {
        text = label
        textSize = 14f
        setTextColor(Color.WHITE)
        setBackgroundColor(Color.rgb(38, 38, 38))
        setOnClickListener { action() }
    }

    private fun showError(message: String) { Toast.makeText(this, message, Toast.LENGTH_LONG).show() }
    private fun closePdf() { try { pdfRenderer?.close() } catch (_: Exception) {}; try { pdfDescriptor?.close() } catch (_: Exception) {}; pdfRenderer = null; pdfDescriptor = null }
    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
    override fun onDestroy() { closePdf(); super.onDestroy() }

    class FrameHost(context: android.content.Context) : android.widget.FrameLayout(context) {
        init { setBackgroundColor(Color.BLACK) }
    }
}
