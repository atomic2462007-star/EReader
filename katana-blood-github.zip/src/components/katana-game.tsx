import { useEffect, useRef } from "react";
import { startGame } from "@/game/engine";

export function KatanaGame() {
  const rootRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const root = rootRef.current;
    if (!root) return;
    const q = <T extends Element>(name: string) => {
      const el = root.querySelector(`[data-ui="${name}"]`);
      if (!el) throw new Error(`missing ${name}`);
      return el as T;
    };
    const game = startGame({
      root,
      canvas: q("view"),
      hp: q("hp"),
      obj: q("obj"),
      ammo: q("ammo"),
      charge: q("charge"),
      arr: q("arr"),
      dist: q("dist"),
      boss: q("boss"),
      bossHp: q("bossHp"),
      msg: q("msg"),
      map: q("map"),
      ov: q("ov"),
      go: q("go"),
      ot: q("ot"),
      op: q("op"),
      zone: q("zone"),
      ring: q("ring"),
      knob: q("knob"),
      atk: q("atk"),
      dge: q("dge"),
      jmp: q("jmp"),
      kni: q("kni"),
      look: q("look"),
    });
    return () => game.stop();
  }, []);

  return (
    <div ref={rootRef} className="game-shell">
      <canvas className="view" data-ui="view" />
      <div className="vignette" />
      <div className="hud">
        <div className="hp-track">
          <div className="hp-fill" data-ui="hp" />
        </div>
        <div className="obj" data-ui="obj" />
        <div className="ammo" data-ui="ammo" />
        <div className="charge-track">
          <div className="charge-fill" data-ui="charge" />
        </div>
        <div className="compass">
          <b data-ui="arr">▲</b>
          <span data-ui="dist" />
        </div>
      </div>
      <div className="boss" data-ui="boss">
        اللورد الخائن
        <div className="boss-track">
          <div className="boss-fill" data-ui="bossHp" />
        </div>
      </div>
      <div className="banner-msg" data-ui="msg" />
      <canvas className="minimap" data-ui="map" width={120} height={120} />
      <div className="look-zone touch-only" data-ui="look" />
      <div className="stick-zone touch-only" data-ui="zone" />
      <div className="stick-ring touch-only" data-ui="ring">
        <div className="stick-knob" data-ui="knob" />
      </div>
      <button className="pad pad-dge touch-only" data-ui="dge" type="button" aria-label="تفادي">
        避
      </button>
      <button className="pad pad-jmp touch-only" data-ui="jmp" type="button" aria-label="قفز">
        跳
      </button>
      <button className="pad pad-kni touch-only" data-ui="kni" type="button" aria-label="رمي خنجر">
        <svg viewBox="0 0 64 64" aria-hidden="true">
          <path d="M32 4l3.2 16.5 8.2 2.2-8.4 3.2L36 58l-4-9-4 9 1-31.8-8.4-3.2 8.2-2.2L32 4z" />
        </svg>
      </button>
      <button className="pad pad-atk touch-only" data-ui="atk" type="button" aria-label="ضربة">
        斬
      </button>
      <div className="overlay on" data-ui="ov">
        <h1 data-ui="ot">دم الكاتانا</h1>
        <p data-ui="op">
          باع اللورد قلعتك وخان الشوغون. طهّر معسكرات الخونة الأربعة في العالم المفتوح، ثم اقتحم القصر واقتله على
          عرشه. الكاتانا للقتال القريب، والخناجر الصغيرة تُرمى ككوناي.
        </p>
        <button data-ui="go" type="button">
          ابدأ الاقتحام
        </button>
        <small>
          موبايل: العصا يسارًا للحركة، ادفعها للنهاية للجري، واسحب يمين الشاشة للكاميرا. 斬 ضربة · 避 تفادٍ · 跳 قفز ·
          زر الخنجر للرمي، وأبقِه مضغوطًا لرشقة من ثلاثة.
          <br />
          لوحة المفاتيح: WASD حركة · الأسهم أو سحب الماوس للكاميرا · مسافة ضربة · Shift تفادٍ · F خنجر · C قفز.
        </small>
      </div>
    </div>
  );
}
