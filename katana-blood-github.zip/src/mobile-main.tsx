import React from "react";
import { createRoot } from "react-dom/client";
import { KatanaGame } from "./components/katana-game";
import "./styles.css";

const root = document.getElementById("root");
if (!root) throw new Error("Missing application root");

createRoot(root).render(
  <React.StrictMode>
    <KatanaGame />
  </React.StrictMode>,
);
