import * as THREE from "three";

export type TexSet = {
  grass: THREE.CanvasTexture;
  gravel: THREE.CanvasTexture;
  stone: THREE.CanvasTexture;
  wood: THREE.CanvasTexture;
  plaster: THREE.CanvasTexture;
  tile: THREE.CanvasTexture;
  tatami: THREE.CanvasTexture;
  lacquer: THREE.CanvasTexture;
  banner: THREE.CanvasTexture;
  door: THREE.CanvasTexture;
  sky: THREE.CanvasTexture;
  glow: THREE.CanvasTexture;
  hamon: THREE.CanvasTexture;
  lacing: THREE.CanvasTexture;
  skin: THREE.CanvasTexture;
  water: THREE.CanvasTexture;
  fabric: THREE.CanvasTexture;
  leather: THREE.CanvasTexture;
  eye: THREE.CanvasTexture;
  bark: THREE.CanvasTexture;
  rock: THREE.CanvasTexture;
};

/** كل خامة لها خريطة نتوء (bump) مرافقة تُحفظ هنا بدل userData لتجنّب نسخ JSON ثقيل. */
const bumps = new WeakMap<THREE.Texture, THREE.Texture>();
export const bumpOf = (t: THREE.Texture | null | undefined): THREE.Texture | null =>
  t ? (bumps.get(t) ?? null) : null;

/* ---------- ضجيج قابل للتكرار (tileable value noise) ---------- */
function ihash(x: number, y: number, s: number) {
  let h = (Math.imul(x, 374761393) + Math.imul(y, 668265263) + Math.imul(s, 1442695041)) | 0;
  h = Math.imul(h ^ (h >>> 13), 1274126177);
  h ^= h >>> 16;
  return (h >>> 0) / 4294967296;
}

function vnoise(x: number, y: number, px: number, py: number, seed: number) {
  const xi = Math.floor(x);
  const yi = Math.floor(y);
  const xf = x - xi;
  const yf = y - yi;
  const u = xf * xf * (3 - 2 * xf);
  const v = yf * yf * (3 - 2 * yf);
  const x0 = ((xi % px) + px) % px;
  const y0 = ((yi % py) + py) % py;
  const x1 = (x0 + 1) % px;
  const y1 = (y0 + 1) % py;
  const a = ihash(x0, y0, seed);
  const b = ihash(x1, y0, seed);
  const c = ihash(x0, y1, seed);
  const d = ihash(x1, y1, seed);
  return a + (b - a) * u + (c - a) * v + (a - b - c + d) * u * v;
}

/** u,v في [0,1)، fx/fy عدد الخلايا الأساسي على كل محور (أعداد صحيحة). */
function fbm(u: number, v: number, fx: number, fy: number, oct: number, seed: number) {
  let amp = 0.5;
  let sum = 0;
  let norm = 0;
  let px = fx;
  let py = fy;
  for (let o = 0; o < oct; o++) {
    sum += amp * vnoise(u * px, v * py, px, py, seed + o * 17);
    norm += amp;
    amp *= 0.5;
    px *= 2;
    py *= 2;
  }
  return sum / norm;
}

const rnd = (n: number) => {
  const x = Math.sin(n * 127.1 + 311.7) * 43758.5453;
  return x - Math.floor(x);
};

type Ctx = CanvasRenderingContext2D;

function makeCanvas(w: number, h: number) {
  const c = document.createElement("canvas");
  c.width = w;
  c.height = h;
  const g = c.getContext("2d", { willReadFrequently: true });
  if (!g) throw new Error("canvas");
  return { c, g };
}

function toTexture(c: HTMLCanvasElement, aniso: number, repeat: boolean, linear: boolean) {
  const t = new THREE.CanvasTexture(c);
  if (repeat) {
    t.wrapS = THREE.RepeatWrapping;
    t.wrapT = THREE.RepeatWrapping;
  }
  t.colorSpace = linear ? THREE.NoColorSpace : THREE.SRGBColorSpace;
  t.anisotropy = aniso;
  return t;
}

/** يبني خامة لون + خريطة نتوء. fn يرسم اللون على g والارتفاع على b (رمادي 128 = مستوى). */
function tex(
  w: number,
  h: number,
  aniso: number,
  fn: (g: Ctx, w: number, h: number, b: Ctx) => void,
  opt: { repeat?: boolean; bump?: boolean } = {},
) {
  const repeat = opt.repeat ?? true;
  const A = makeCanvas(w, h);
  const B = makeCanvas(w, h);
  B.g.fillStyle = "#808080";
  B.g.fillRect(0, 0, w, h);
  fn(A.g, w, h, B.g);
  const t = toTexture(A.c, aniso, repeat, false);
  if (opt.bump !== false) bumps.set(t, toTexture(B.c, aniso, repeat, true));
  return t;
}

/** رسم مع التفاف حول الحواف حتى لا تظهر درزات عند التكرار. */
function wrapDraw(w: number, h: number, x: number, y: number, r: number, fn: (x: number, y: number) => void) {
  fn(x, y);
  const nx = x < r ? w : x > w - r ? -w : 0;
  const ny = y < r ? h : y > h - r ? -h : 0;
  if (nx) fn(x + nx, y);
  if (ny) fn(x, y + ny);
  if (nx && ny) fn(x + nx, y + ny);
}

/** تعديل سطوع اللون بضجيج fbm. */
function grain(g: Ctx, w: number, h: number, seed: number, fx: number, oct: number, amt: number, fy = fx) {
  const im = g.getImageData(0, 0, w, h);
  const d = im.data;
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      const n = fbm(x / w, y / h, fx, fy, oct, seed);
      const k = 1 + (n - 0.5) * 2 * amt;
      const i = (y * w + x) * 4;
      d[i] = d[i]! * k;
      d[i + 1] = d[i + 1]! * k;
      d[i + 2] = d[i + 2]! * k;
    }
  }
  g.putImageData(im, 0, 0);
}

/** إضافة ضجيج إلى خريطة الارتفاع. */
function heightNoise(b: Ctx, w: number, h: number, seed: number, fx: number, oct: number, amt: number, fy = fx) {
  const im = b.getImageData(0, 0, w, h);
  const d = im.data;
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      const n = (fbm(x / w, y / h, fx, fy, oct, seed) - 0.5) * 255 * amt;
      const i = (y * w + x) * 4;
      d[i] = d[i]! + n;
      d[i + 1] = d[i + 1]! + n;
      d[i + 2] = d[i + 2]! + n;
    }
  }
  b.putImageData(im, 0, 0);
}

/** تلوين متدرّج بالضجيج نحو لون معيّن (للبقع والطحالب). */
function stain(g: Ctx, w: number, h: number, seed: number, fx: number, rgb: [number, number, number], amt: number, th = 0.5) {
  const im = g.getImageData(0, 0, w, h);
  const d = im.data;
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      const n = fbm(x / w, y / h, fx, fx, 3, seed);
      const t = Math.max(0, (n - th) / (1 - th)) * amt;
      if (t <= 0) continue;
      const i = (y * w + x) * 4;
      d[i] = d[i]! + (rgb[0] - d[i]!) * t;
      d[i + 1] = d[i + 1]! + (rgb[1] - d[i + 1]!) * t;
      d[i + 2] = d[i + 2]! + (rgb[2] - d[i + 2]!) * t;
    }
  }
  g.putImageData(im, 0, 0);
}

function crack(g: Ctx, b: Ctx, w: number, h: number, seed: number, n: number, col: string) {
  for (let k = 0; k < n; k++) {
    let x = rnd(seed + k * 3) * w;
    let y = rnd(seed + k * 3 + 1) * h;
    let a = rnd(seed + k * 3 + 2) * Math.PI * 2;
    const len = 14 + rnd(seed + k) * 40;
    g.strokeStyle = col;
    g.lineWidth = 1;
    b.strokeStyle = "rgba(0,0,0,.7)";
    b.lineWidth = 1.6;
    g.beginPath();
    b.beginPath();
    g.moveTo(x, y);
    b.moveTo(x, y);
    for (let s = 0; s < len; s += 3) {
      a += (rnd(seed + k * 31 + s) - 0.5) * 0.9;
      x += Math.cos(a) * 3;
      y += Math.sin(a) * 3;
      g.lineTo(x, y);
      b.lineTo(x, y);
    }
    g.stroke();
    b.stroke();
  }
}

export function makeTextures(aniso: number): TexSet {
  /* ---------- أرض وعشب ---------- */
  const grass = tex(512, 512, aniso, (g, w, h, b) => {
    g.fillStyle = "#bcc4a8";
    g.fillRect(0, 0, w, h);
    grain(g, w, h, 3, 4, 5, 0.24);
    grain(g, w, h, 41, 16, 3, 0.1);
    heightNoise(b, w, h, 7, 8, 4, 0.5);
    for (let i = 0; i < 9000; i++) {
      const x = rnd(i) * w;
      const y = rnd(i + 9) * h;
      const len = 4 + rnd(i + 4) * 11;
      const a = -Math.PI / 2 + (rnd(i + 6) - 0.5) * 0.9;
      const light = rnd(i + 2) < 0.5;
      wrapDraw(w, h, x, y, 16, (px, py) => {
        g.strokeStyle = light ? `rgba(255,255,230,${0.12 + rnd(i + 5) * 0.16})` : `rgba(15,28,8,${0.14 + rnd(i + 7) * 0.2})`;
        g.lineWidth = 0.8 + rnd(i + 8) * 0.8;
        g.beginPath();
        g.moveTo(px, py);
        g.quadraticCurveTo(px + Math.cos(a) * len * 0.5 + 1.5, py + Math.sin(a) * len * 0.5, px + Math.cos(a) * len, py + Math.sin(a) * len);
        g.stroke();
        b.strokeStyle = light ? "rgba(255,255,255,.4)" : "rgba(0,0,0,.35)";
        b.lineWidth = 1;
        b.beginPath();
        b.moveTo(px, py);
        b.lineTo(px + Math.cos(a) * len, py + Math.sin(a) * len);
        b.stroke();
      });
    }
  });

  const gravel = tex(512, 512, aniso, (g, w, h, b) => {
    g.fillStyle = "#625d4f";
    g.fillRect(0, 0, w, h);
    grain(g, w, h, 11, 6, 4, 0.22);
    for (let i = 0; i < 1700; i++) {
      const x = rnd(i + 1) * w;
      const y = rnd(i + 2) * h;
      const rx = 2 + rnd(i + 3) * 5.5;
      const ry = rx * (0.6 + rnd(i + 4) * 0.35);
      const rot = rnd(i + 5) * Math.PI;
      const l = 36 + rnd(i + 6) * 34;
      const hue = 28 + rnd(i + 7) * 24;
      wrapDraw(w, h, x, y, 8, (px, py) => {
        g.fillStyle = "rgba(0,0,0,.35)";
        g.beginPath();
        g.ellipse(px + 1.2, py + 1.4, rx, ry, rot, 0, Math.PI * 2);
        g.fill();
        const gr = g.createRadialGradient(px - rx * 0.3, py - ry * 0.3, 0.5, px, py, rx * 1.1);
        gr.addColorStop(0, `hsl(${hue} 14% ${l + 14}%)`);
        gr.addColorStop(1, `hsl(${hue} 12% ${l - 10}%)`);
        g.fillStyle = gr;
        g.beginPath();
        g.ellipse(px, py, rx, ry, rot, 0, Math.PI * 2);
        g.fill();
        const gb = b.createRadialGradient(px, py, 0, px, py, rx * 1.1);
        gb.addColorStop(0, "rgba(255,255,255,.9)");
        gb.addColorStop(1, "rgba(60,60,60,.2)");
        b.fillStyle = gb;
        b.beginPath();
        b.ellipse(px, py, rx, ry, rot, 0, Math.PI * 2);
        b.fill();
      });
    }
  });

  const rock = tex(256, 256, aniso, (g, w, h, b) => {
    g.fillStyle = "#8c887f";
    g.fillRect(0, 0, w, h);
    grain(g, w, h, 21, 4, 5, 0.3);
    stain(g, w, h, 23, 3, [96, 120, 74], 0.5, 0.62);
    stain(g, w, h, 29, 5, [52, 48, 44], 0.45, 0.55);
    heightNoise(b, w, h, 25, 6, 5, 0.9);
    crack(g, b, w, h, 300, 7, "rgba(20,18,16,.55)");
  });

  const stone = tex(512, 512, aniso, (g, w, h, b) => {
    g.fillStyle = "#1c1a17";
    g.fillRect(0, 0, w, h);
    b.fillStyle = "#202020";
    b.fillRect(0, 0, w, h);
    for (let r = 0; r < 4; r++) {
      for (let c = -1; c < 3; c++) {
        const x0 = c * 256 + (r % 2 ? 128 : 0);
        const y0 = r * 128;
        const l = 40 + rnd(r * 8 + c + 20) * 16;
        g.fillStyle = `hsl(${32 + rnd(r + c) * 8} 7% ${l}%)`;
        g.fillRect(x0 + 4, y0 + 4, 248, 120);
        g.fillStyle = "rgba(255,255,255,.12)";
        g.fillRect(x0 + 4, y0 + 4, 248, 5);
        g.fillStyle = "rgba(0,0,0,.18)";
        g.fillRect(x0 + 4, y0 + 118, 248, 6);
        b.fillStyle = "#b8b8b8";
        b.fillRect(x0 + 6, y0 + 6, 244, 116);
      }
    }
    grain(g, w, h, 33, 8, 5, 0.26);
    heightNoise(b, w, h, 35, 10, 4, 0.55);
    stain(g, w, h, 37, 4, [60, 80, 50], 0.45, 0.66);
    crack(g, b, w, h, 400, 9, "rgba(10,8,6,.6)");
  });

  const wood = tex(512, 512, aniso, (g, w, h, b) => {
    for (let i = 0; i < 8; i++) {
      const l = 27 + rnd(i + 4) * 11;
      g.fillStyle = `hsl(${22 + rnd(i) * 6} 36% ${l}%)`;
      g.fillRect(0, i * 64, w, 64);
      for (let k = 0; k < 46; k++) {
        const yy = i * 64 + 3 + rnd(i * 91 + k) * 58;
        const ph = rnd(i * 17 + k) * 6;
        g.strokeStyle = rnd(k + i) < 0.5 ? "rgba(0,0,0,.2)" : "rgba(255,210,150,.08)";
        g.lineWidth = 0.7 + rnd(k) * 1.1;
        g.beginPath();
        for (let x = 0; x <= w; x += 8) {
          const y = yy + Math.sin(x * 0.02 + ph) * 1.6 + Math.sin(x * 0.07 + ph * 2) * 0.6;
          if (x === 0) g.moveTo(x, y);
          else g.lineTo(x, y);
        }
        g.stroke();
        b.strokeStyle = "rgba(0,0,0,.35)";
        b.lineWidth = 1;
        b.beginPath();
        b.moveTo(0, yy);
        b.lineTo(w, yy);
        b.stroke();
      }
      if (rnd(i + 70) < 0.55) {
        const kx = rnd(i + 80) * w;
        const ky = i * 64 + 32;
        for (let r = 9; r > 1; r -= 2) {
          g.strokeStyle = `rgba(20,8,0,${0.14 + (9 - r) * 0.05})`;
          g.lineWidth = 1.2;
          g.beginPath();
          g.ellipse(kx, ky, r * 2.2, r, 0, 0, Math.PI * 2);
          g.stroke();
          b.strokeStyle = "rgba(0,0,0,.4)";
          b.beginPath();
          b.ellipse(kx, ky, r * 2.2, r, 0, 0, Math.PI * 2);
          b.stroke();
        }
      }
      g.fillStyle = "rgba(0,0,0,.55)";
      g.fillRect(0, i * 64, w, 3);
      b.fillStyle = "#101010";
      b.fillRect(0, i * 64, w, 3);
    }
    grain(g, w, h, 51, 3, 5, 0.18, 8);
  });

  const bark = tex(256, 256, aniso, (g, w, h, b) => {
    g.fillStyle = "#9a9288";
    g.fillRect(0, 0, w, h);
    grain(g, w, h, 61, 10, 5, 0.45, 2);
    heightNoise(b, w, h, 63, 12, 5, 1.1, 2);
    stain(g, w, h, 65, 3, [70, 86, 56], 0.4, 0.6);
  });

  const plaster = tex(512, 512, aniso, (g, w, h, b) => {
    g.fillStyle = "#d9d0bc";
    g.fillRect(0, 0, w, h);
    grain(g, w, h, 71, 5, 5, 0.12);
    stain(g, w, h, 73, 3, [120, 104, 82], 0.5, 0.52);
    for (let i = 0; i < 800; i++) {
      g.fillStyle = `rgba(40,24,12,${rnd(i) * 0.07})`;
      g.fillRect(rnd(i + 2) * w, rnd(i + 5) * h, 2 + rnd(i) * 8, 1 + rnd(i + 1) * 3);
    }
    heightNoise(b, w, h, 75, 8, 5, 0.45);
    crack(g, b, w, h, 500, 6, "rgba(60,44,30,.5)");
    const beam = (x: number, y: number, bw: number, bh: number) => {
      g.fillStyle = "#3a2416";
      g.fillRect(x, y, bw, bh);
      for (let k = 0; k < 20; k++) {
        g.fillStyle = k % 2 ? "rgba(0,0,0,.18)" : "rgba(255,200,140,.07)";
        if (bw < bh) g.fillRect(x + rnd(k + x) * bw, y, 1, bh);
        else g.fillRect(x, y + rnd(k + y) * bh, bw, 1);
      }
      b.fillStyle = "#d0d0d0";
      b.fillRect(x, y, bw, bh);
    };
    beam(0, 0, 24, h);
    beam(0, 0, w, 20);
    beam(0, h - 20, w, 20);
  });

  const tile = tex(512, 512, aniso, (g, w, h, b) => {
    g.fillStyle = "#1c1f26";
    g.fillRect(0, 0, w, h);
    for (let r = 0; r < 16; r++) {
      for (let c = -1; c < 8; c++) {
        const x0 = c * 64 + (r % 2 ? 32 : 0);
        const y0 = r * 32;
        const l = 15 + rnd(r * 13 + c + 3) * 10;
        const gr = g.createLinearGradient(0, y0, 0, y0 + 32);
        gr.addColorStop(0, `hsl(220 9% ${l + 5}%)`);
        gr.addColorStop(0.7, `hsl(220 10% ${l}%)`);
        gr.addColorStop(1, `hsl(220 12% ${l - 8}%)`);
        g.fillStyle = gr;
        g.beginPath();
        g.moveTo(x0 + 4, y0);
        g.lineTo(x0 + 60, y0);
        g.lineTo(x0 + 54, y0 + 30);
        g.quadraticCurveTo(x0 + 32, y0 + 36, x0 + 10, y0 + 30);
        g.closePath();
        g.fill();
        g.strokeStyle = "rgba(255,255,255,.07)";
        g.beginPath();
        g.moveTo(x0 + 8, y0 + 4);
        g.lineTo(x0 + 56, y0 + 4);
        g.stroke();
        const gb = b.createLinearGradient(0, y0, 0, y0 + 32);
        gb.addColorStop(0, "#606060");
        gb.addColorStop(0.75, "#d0d0d0");
        gb.addColorStop(1, "#303030");
        b.fillStyle = gb;
        b.fillRect(x0 + 4, y0, 56, 31);
      }
    }
    grain(g, w, h, 81, 8, 4, 0.2);
    stain(g, w, h, 83, 5, [58, 78, 52], 0.5, 0.64);
  });

  const tatami = tex(512, 256, aniso, (g, w, h, b) => {
    g.fillStyle = "hsl(72 24% 48%)";
    g.fillRect(0, 0, w, h);
    for (let y = 2; y < h; y += 3) {
      g.fillStyle = rnd(y) < 0.5 ? "rgba(0,0,0,.08)" : "rgba(255,255,200,.06)";
      g.fillRect(0, y, w, 1);
      b.fillStyle = "rgba(0,0,0,.35)";
      b.fillRect(0, y, w, 1);
    }
    grain(g, w, h, 91, 6, 4, 0.14, 3);
    g.fillStyle = "#1c1810";
    g.fillRect(0, 0, w, 14);
    g.fillRect(0, h - 14, w, 14);
    g.fillRect(0, 0, 8, h);
    g.fillRect(w - 8, 0, 8, h);
  });

  const lacquer = tex(256, 256, aniso, (g, w, h, b) => {
    for (let i = 0; i < 4; i++) {
      for (let j = 0; j < 4; j++) {
        g.fillStyle = (i + j) % 2 ? "#241510" : "#311c16";
        g.fillRect(i * 64, j * 64, 64, 64);
      }
    }
    grain(g, w, h, 101, 4, 4, 0.12);
    g.strokeStyle = "rgba(216,180,90,.4)";
    g.lineWidth = 2;
    for (let i = 0; i <= 4; i++) {
      g.beginPath();
      g.moveTo(i * 64, 0);
      g.lineTo(i * 64, h);
      g.moveTo(0, i * 64);
      g.lineTo(w, i * 64);
      g.stroke();
    }
    b.strokeStyle = "#d8d8d8";
    b.lineWidth = 2;
    for (let i = 0; i <= 4; i++) {
      b.beginPath();
      b.moveTo(i * 64, 0);
      b.lineTo(i * 64, h);
      b.moveTo(0, i * 64);
      b.lineTo(w, i * 64);
      b.stroke();
    }
  });

  const fabricWeave = (g: Ctx, b: Ctx, w: number, h: number, step: number, dark: number) => {
    for (let y = 0; y < h; y += step) {
      for (let x = 0; x < w; x += step) {
        const over = ((x / step + y / step) | 0) % 2 === 0;
        g.fillStyle = over ? `rgba(0,0,0,${dark})` : `rgba(255,255,255,${dark * 0.5})`;
        g.fillRect(x, y, step, step);
        b.fillStyle = over ? "#a0a0a0" : "#606060";
        b.fillRect(x, y, step, step);
      }
    }
  };

  const banner = tex(256, 512, aniso, (g, w, h, b) => {
    const gr = g.createLinearGradient(0, 0, 0, h);
    gr.addColorStop(0, "#9a1830");
    gr.addColorStop(1, "#6c0e20");
    g.fillStyle = gr;
    g.fillRect(0, 0, w, h);
    fabricWeave(g, b, w, h, 3, 0.16);
    grain(g, w, h, 111, 3, 4, 0.18, 6);
    g.strokeStyle = "#d8b45a";
    g.lineWidth = 8;
    g.strokeRect(10, 10, w - 20, h - 20);
    g.lineWidth = 2;
    g.strokeRect(22, 22, w - 44, h - 44);
    g.fillStyle = "#d8b45a";
    g.beginPath();
    g.arc(w / 2, h * 0.42, 56, 0, Math.PI * 2);
    g.fill();
    g.fillStyle = "#8d1428";
    g.beginPath();
    g.arc(w / 2, h * 0.42, 32, 0, Math.PI * 2);
    g.fill();
    g.fillStyle = "#d8b45a";
    g.beginPath();
    g.arc(w / 2, h * 0.42, 14, 0, Math.PI * 2);
    g.fill();
    g.fillStyle = "rgba(0,0,0,.25)";
    for (let i = 0; i < 6; i++) g.fillRect(0, 40 + i * 80 + rnd(i) * 20, w, 3);
  });

  const door = tex(256, 512, aniso, (g, w, h, b) => {
    g.fillStyle = "#6e0e1c";
    g.fillRect(0, 0, w, h);
    grain(g, w, h, 121, 3, 5, 0.2, 8);
    g.strokeStyle = "#d8b45a";
    g.lineWidth = 8;
    g.strokeRect(8, 8, w - 16, h - 16);
    g.strokeRect(24, 24, w - 48, h - 48);
    g.fillStyle = "#d8b45a";
    for (let i = 0; i < 4; i++) {
      for (let j = 0; j < 8; j++) {
        g.beginPath();
        g.arc(44 + i * 52, 56 + j * 56, 5, 0, Math.PI * 2);
        g.fill();
        b.fillStyle = "#e0e0e0";
        b.beginPath();
        b.arc(44 + i * 52, 56 + j * 56, 6, 0, Math.PI * 2);
        b.fill();
      }
    }
  });

  /* ---------- سماء ---------- */
  const sky = tex(
    1024,
    512,
    1,
    (g, w, h) => {
      const gr = g.createLinearGradient(0, 0, 0, h * 0.58);
      gr.addColorStop(0, "#05040c");
      gr.addColorStop(0.4, "#14102a");
      gr.addColorStop(0.72, "#40203e");
      gr.addColorStop(0.9, "#9a4a44");
      gr.addColorStop(1, "#c9694e");
      g.fillStyle = gr;
      g.fillRect(0, 0, w, h);
      const sh = Math.floor(h * 0.6);
      const im = g.getImageData(0, 0, w, sh);
      const d = im.data;
      for (let y = 0; y < sh; y++) {
        for (let x = 0; x < w; x++) {
          const n = fbm(x / w, y / h, 4, 3, 5, 131);
          const c = Math.max(0, n - 0.5) * 2;
          const hy = y / sh;
          const k = c * (0.35 + hy * 0.8);
          const i = (y * w + x) * 4;
          d[i] = d[i]! + (150 - d[i]!) * k * 0.45;
          d[i + 1] = d[i + 1]! + (80 - d[i + 1]!) * k * 0.4;
          d[i + 2] = d[i + 2]! + (110 - d[i + 2]!) * k * 0.45;
        }
      }
      g.putImageData(im, 0, 0);
      for (let i = 0; i < 700; i++) {
        const m = rnd(i);
        g.fillStyle = `rgba(255,${240 + rnd(i + 5) * 15},${225 + rnd(i + 6) * 30},${0.18 + m * 0.8})`;
        const s = m > 0.96 ? 2.2 : 1 + rnd(i) * 0.9;
        g.fillRect(rnd(i + 2) * w, rnd(i + 8) * h * 0.46, s, s);
      }
      g.fillStyle = "#12080e";
      g.beginPath();
      g.moveTo(0, h * 0.6);
      for (let x = 0; x <= w; x += 4) {
        const y = h * 0.52 - 30 * (fbm(x / w, 0.3, 6, 2, 4, 141) * 1.4 + Math.sin(x * 0.007 + 1) * 0.3);
        g.lineTo(x, y);
      }
      g.lineTo(w, h);
      g.lineTo(0, h);
      g.fill();
    },
    { repeat: false, bump: false },
  );

  const glow = tex(
    128,
    128,
    1,
    (g) => {
      const gr = g.createRadialGradient(64, 64, 0, 64, 64, 64);
      gr.addColorStop(0, "rgba(255,190,110,.95)");
      gr.addColorStop(0.3, "rgba(255,110,50,.4)");
      gr.addColorStop(1, "rgba(255,60,20,0)");
      g.fillStyle = gr;
      g.fillRect(0, 0, 128, 128);
    },
    { repeat: false, bump: false },
  );

  /* ---------- معدن وجلد ونسيج ---------- */
  const hamon = tex(64, 256, aniso, (g, w, h, b) => {
    const gr = g.createLinearGradient(0, 0, w, 0);
    gr.addColorStop(0, "#7a8ca0");
    gr.addColorStop(0.42, "#f6f9fc");
    gr.addColorStop(0.5, "#cfd9e4");
    gr.addColorStop(1, "#8497ab");
    g.fillStyle = gr;
    g.fillRect(0, 0, w, h);
    for (let y = 0; y < h; y += 2) {
      g.fillStyle = rnd(y) < 0.5 ? "rgba(255,255,255,.07)" : "rgba(0,0,0,.05)";
      g.fillRect(0, y, w, 1);
    }
    g.strokeStyle = "rgba(210,225,240,.9)";
    g.lineWidth = 3;
    g.beginPath();
    g.moveTo(w * 0.55, 0);
    for (let y = 0; y <= h; y += 4) g.lineTo(w * 0.5 + Math.sin(y * 0.18) * 5 + Math.sin(y * 0.43) * 2, y);
    g.stroke();
    for (let i = 0; i < 120; i++) {
      g.fillStyle = "rgba(255,255,255,.35)";
      g.fillRect(w * 0.42 + rnd(i) * w * 0.22, rnd(i + 3) * h, 1, 1);
    }
    b.fillStyle = "#909090";
    b.fillRect(0, 0, w, h);
  });

  const lacing = tex(256, 256, aniso, (g, w, h, b) => {
    // صفائح كوزان مطلية بالورنيش مربوطة بخيوط ملوّنة
    g.fillStyle = "#4a4d56";
    g.fillRect(0, 0, w, h);
    for (let r = 0; r < 16; r++) {
      const y = r * 16;
      for (let c = 0; c < 16; c++) {
        const x = c * 16 + (r % 2 ? 8 : 0);
        const l = 0.78 + rnd(r * 19 + c) * 0.22;
        const gr = g.createLinearGradient(x, y, x, y + 14);
        gr.addColorStop(0, `rgb(${255 * l},${255 * l},${255 * l})`);
        gr.addColorStop(1, `rgb(${170 * l},${170 * l},${176 * l})`);
        g.fillStyle = gr;
        g.fillRect(x + 1, y + 1, 14, 13);
        g.fillStyle = "rgba(255,255,255,.35)";
        g.fillRect(x + 2, y + 2, 12, 1);
        b.fillStyle = "#d8d8d8";
        b.fillRect(x + 1, y + 1, 14, 13);
      }
    }
    // خيوط الأودوشي (حبل مضفور)
    for (let r = 0; r < 8; r++) {
      const y = r * 32 + 14;
      g.fillStyle = "rgba(34,30,36,.85)";
      g.fillRect(0, y, w, 4);
      b.fillStyle = "#f0f0f0";
      b.fillRect(0, y, w, 4);
      for (let x = 0; x < w; x += 6) {
        g.fillStyle = "rgba(255,230,160,.35)";
        g.fillRect(x, y, 2, 4);
      }
    }
    grain(g, w, h, 151, 8, 3, 0.1);
  });

  const skin = tex(256, 256, aniso, (g, w, h, b) => {
    g.fillStyle = "#f2e6de";
    g.fillRect(0, 0, w, h);
    grain(g, w, h, 161, 4, 4, 0.07);
    stain(g, w, h, 163, 3, [236, 190, 176], 0.45, 0.45); // احمرار
    stain(g, w, h, 167, 6, [206, 176, 150], 0.3, 0.6); // تفاوت لون
    for (let i = 0; i < 1500; i++) {
      const x = rnd(i + 1) * w;
      const y = rnd(i + 2) * h;
      g.fillStyle = `rgba(90,50,40,${0.04 + rnd(i) * 0.08})`;
      g.fillRect(x, y, 1, 1);
      b.fillStyle = "rgba(0,0,0,.35)";
      b.fillRect(x, y, 1.4, 1.4);
    }
    heightNoise(b, w, h, 169, 12, 3, 0.18);
  });

  const fabric = tex(256, 256, aniso, (g, w, h, b) => {
    g.fillStyle = "#d4d0cc";
    g.fillRect(0, 0, w, h);
    fabricWeave(g, b, w, h, 2, 0.14);
    grain(g, w, h, 171, 4, 4, 0.2);
    grain(g, w, h, 173, 12, 3, 0.08);
    heightNoise(b, w, h, 175, 6, 4, 0.35);
  });

  const leather = tex(256, 256, aniso, (g, w, h, b) => {
    g.fillStyle = "#b8b0a8";
    g.fillRect(0, 0, w, h);
    grain(g, w, h, 181, 16, 3, 0.2);
    grain(g, w, h, 183, 4, 3, 0.16);
    for (let i = 0; i < 40; i++) {
      g.strokeStyle = `rgba(255,255,255,${0.04 + rnd(i) * 0.06})`;
      g.lineWidth = 1;
      g.beginPath();
      const x = rnd(i + 1) * w;
      const y = rnd(i + 2) * h;
      g.moveTo(x, y);
      g.lineTo(x + (rnd(i + 3) - 0.5) * 50, y + (rnd(i + 4) - 0.5) * 50);
      g.stroke();
    }
    heightNoise(b, w, h, 185, 24, 3, 0.8);
  });

  const eye = tex(
    128,
    128,
    4,
    (g, w, h) => {
      g.fillStyle = "#000";
      g.fillRect(0, 0, w, h);
      const cx = w / 2;
      const cy = h / 2;
      const gr = g.createRadialGradient(cx, cy, 4, cx, cy, 60);
      gr.addColorStop(0, "#f0f0f0");
      gr.addColorStop(0.7, "#b8b8b8");
      gr.addColorStop(0.94, "#5a5a5a");
      gr.addColorStop(1, "#1c1c1c");
      g.fillStyle = gr;
      g.beginPath();
      g.arc(cx, cy, 60, 0, Math.PI * 2);
      g.fill();
      for (let i = 0; i < 90; i++) {
        const a = (i / 90) * Math.PI * 2;
        g.strokeStyle = i % 2 ? "rgba(0,0,0,.28)" : "rgba(255,255,255,.22)";
        g.lineWidth = 1;
        g.beginPath();
        g.moveTo(cx + Math.cos(a) * 18, cy + Math.sin(a) * 18);
        g.lineTo(cx + Math.cos(a) * 56, cy + Math.sin(a) * 56);
        g.stroke();
      }
      g.fillStyle = "#050505";
      g.beginPath();
      g.arc(cx, cy, 17, 0, Math.PI * 2);
      g.fill();
    },
    { repeat: false, bump: false },
  );

  const water = tex(512, 512, aniso, (g, w, h, b) => {
    g.fillStyle = "#1a5870";
    g.fillRect(0, 0, w, h);
    const im = g.getImageData(0, 0, w, h);
    const d = im.data;
    const bm = b.getImageData(0, 0, w, h);
    const bd = bm.data;
    for (let y = 0; y < h; y++) {
      for (let x = 0; x < w; x++) {
        const u = x / w;
        const v = y / h;
        const n1 = fbm(u, v, 4, 8, 4, 191);
        const n2 = fbm(u + 0.31, v + 0.17, 8, 8, 3, 193);
        const rip = Math.abs(Math.sin((n1 * 6 + n2 * 3) * Math.PI));
        const i = (y * w + x) * 4;
        const k = 0.75 + n1 * 0.55;
        d[i] = d[i]! * k + rip * rip * 38;
        d[i + 1] = d[i + 1]! * k + rip * rip * 56;
        d[i + 2] = d[i + 2]! * k + rip * rip * 62;
        const hv = 128 + (rip - 0.5) * 120;
        bd[i] = bd[i + 1] = bd[i + 2] = hv;
      }
    }
    g.putImageData(im, 0, 0);
    b.putImageData(bm, 0, 0);
  });

  return {
    grass,
    gravel,
    stone,
    wood,
    plaster,
    tile,
    tatami,
    lacquer,
    banner,
    door,
    sky,
    glow,
    hamon,
    lacing,
    skin,
    water,
    fabric,
    leather,
    eye,
    bark,
    rock,
  };
}

export function repeat(t: THREE.Texture, x: number, y: number) {
  const c = t.clone();
  c.repeat.set(x, y);
  c.needsUpdate = true;
  const b = bumps.get(t);
  if (b) {
    const cb = b.clone();
    cb.repeat.set(x, y);
    cb.needsUpdate = true;
    bumps.set(c, cb);
  }
  return c;
}
