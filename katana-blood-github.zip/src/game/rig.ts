import * as THREE from "three";
import { mergeGeometries } from "three/examples/jsm/utils/BufferGeometryUtils.js";
import { bumpOf, repeat, type TexSet } from "./materials";

export type Kind = "pl" | "ash" | "sam" | "eli" | "boss";

export type Anim = {
  speed: number;
  attack: number;
  attackDur: number;
  combo: number;
  throwing: number;
  dodge: number;
  dodgeSide: number;
  hurt: number;
  time: number;
  dead: number;
};

export type Rig = {
  kind: Kind;
  root: THREE.Group;
  body: THREE.Group;
  torso: THREE.Group;
  head: THREE.Group;
  legs: [THREE.Group, THREE.Group];
  knees: [THREE.Group, THREE.Group];
  arms: [THREE.Group, THREE.Group];
  fores: [THREE.Group, THREE.Group];
  sword: THREE.Group;
  swBlend: number;
  cape: THREE.Group | null;
  mats: THREE.MeshStandardMaterial[];
  phase: number;
  flashing: boolean;
};

type Face = "young" | "bearded" | "masked" | "oni";

type Pal = {
  armor: number;
  armor2: number;
  cloth: number;
  sleeve: number;
  trim: number;
  cord: number;
  sash: number;
  skin: number;
  hair: number;
  eye: number;
  scale: number;
  hat: "kabuto" | "jingasa" | "hair";
  crest: "moon" | "horn" | "antler" | "none";
  face: Face;
  glow: boolean;
  cape: boolean;
  banner: boolean;
  scar: boolean;
  spikes: boolean;
  foot: "waraji" | "sabaton";
  brow: number;
  hachimaki: boolean;
};

const PALS: Record<Kind, Pal> = {
  // البطل: محارب شاب بدرع كحلي وحبال حمراء وشارة هلال
  pl: {
    armor: 0x3a5a9a,
    armor2: 0x1c2c52,
    cloth: 0x2a3550,
    sleeve: 0x2a3550,
    trim: 0xd8b45a,
    cord: 0xb02a38,
    sash: 0xa81e2e,
    skin: 0xd49a74,
    hair: 0x15110f,
    eye: 0x4a3020,
    scale: 1,
    hat: "hair",
    crest: "moon",
    face: "young",
    glow: false,
    cape: false,
    banner: true,
    scar: true,
    spikes: false,
    foot: "waraji",
    brow: 0.12,
    hachimaki: true,
  },
  // جندي مشاة (أشيغارو): درع بسيط، قبعة مخروطية، لحية خشنة
  ash: {
    armor: 0x8a7050,
    armor2: 0x5a4630,
    cloth: 0x6a5a40,
    sleeve: 0x6a5a40,
    trim: 0xa89068,
    cord: 0x4a3a28,
    sash: 0x7a3a28,
    skin: 0xbf8a64,
    hair: 0x2a2420,
    eye: 0x2a1a10,
    scale: 0.98,
    hat: "jingasa",
    crest: "none",
    face: "bearded",
    glow: false,
    cape: false,
    banner: false,
    scar: false,
    spikes: false,
    foot: "waraji",
    brow: 0.3,
    hachimaki: true,
  },
  // ساموراي: درع أحمر قرمزي وخوذة بقرنين وقناع وجه
  sam: {
    armor: 0x8a2230,
    armor2: 0x4a121c,
    cloth: 0x2a1c20,
    sleeve: 0x2a1c20,
    trim: 0xd0b060,
    cord: 0x1c1c22,
    sash: 0x3a2a30,
    skin: 0xc99a7a,
    hair: 0x120e0c,
    eye: 0x14080c,
    scale: 1.02,
    hat: "kabuto",
    crest: "horn",
    face: "masked",
    glow: false,
    cape: false,
    banner: false,
    scar: false,
    spikes: false,
    foot: "waraji",
    brow: 0.4,
    hachimaki: false,
  },
  // نخبة سوداء بعيون حمراء متوهجة
  eli: {
    armor: 0x2a2c34,
    armor2: 0x15161c,
    cloth: 0x15151a,
    sleeve: 0x15151a,
    trim: 0xd8b45a,
    cord: 0x8a1420,
    sash: 0x6e0c18,
    skin: 0xa87858,
    hair: 0x0c0a0a,
    eye: 0xff2a2a,
    scale: 1.06,
    hat: "kabuto",
    crest: "horn",
    face: "masked",
    glow: true,
    cape: false,
    banner: false,
    scar: false,
    spikes: true,
    foot: "sabaton",
    brow: 0.5,
    hachimaki: false,
  },
  // اللورد الخائن: عملاق بقناع أوني وقرون وعباءة
  boss: {
    armor: 0x24201c,
    armor2: 0x0e0c0a,
    cloth: 0x7a0e1c,
    sleeve: 0x3a0a12,
    trim: 0xe0c05a,
    cord: 0x8a1420,
    sash: 0x5a0a14,
    skin: 0x4a3c3a,
    hair: 0x1a1414,
    eye: 0xff1a1a,
    scale: 1.38,
    hat: "kabuto",
    crest: "antler",
    face: "oni",
    glow: true,
    cape: true,
    banner: false,
    scar: false,
    spikes: true,
    foot: "sabaton",
    brow: 0.6,
    hachimaki: false,
  },
};

/* ---------- هندسة مشتركة (مخزّنة) ---------- */
const geos = new Map<string, THREE.BufferGeometry>();
function G(key: string, build: () => THREE.BufferGeometry) {
  let g = geos.get(key);
  if (!g) {
    g = build();
    geos.set(key, g);
  }
  return g;
}
const box = (w: number, h: number, d: number) => G(`b${w}_${h}_${d}`, () => new THREE.BoxGeometry(w, h, d));
const cyl = (rt: number, rb: number, h: number, s = 14, open = false, ts = 0, tl = Math.PI * 2) =>
  G(`c${rt}_${rb}_${h}_${s}_${open}_${ts}_${tl}`, () => new THREE.CylinderGeometry(rt, rb, h, s, 1, open, ts, tl));
const sph = (r: number, w = 14, h = 10) => G(`s${r}_${w}_${h}`, () => new THREE.SphereGeometry(r, w, h));
const dome = (r: number, tl = Math.PI * 0.52, w = 22, h = 10) =>
  G(`d${r}_${tl}_${w}_${h}`, () => new THREE.SphereGeometry(r, w, h, 0, Math.PI * 2, 0, tl));
const cone = (r: number, h: number, s = 8) => G(`k${r}_${h}_${s}`, () => new THREE.ConeGeometry(r, h, s));
const tor = (r: number, t: number, rs = 8, ts = 20, arc = Math.PI * 2) =>
  G(`t${r}_${t}_${rs}_${ts}_${arc}`, () => new THREE.TorusGeometry(r, t, rs, ts, arc));
const circ = (r: number, s = 18) => G(`o${r}_${s}`, () => new THREE.CircleGeometry(r, s));

let bladeGeo: THREE.BufferGeometry | null = null;
function blade() {
  if (bladeGeo) return bladeGeo;
  // نصل منحنٍ قليلًا بطرف كيساكي
  const s = new THREE.Shape();
  s.moveTo(-0.021, 0);
  s.lineTo(-0.0185, 0.5);
  s.lineTo(-0.0165, 0.8);
  s.quadraticCurveTo(-0.012, 0.9, 0.012, 0.965);
  s.lineTo(0.019, 0.8);
  s.lineTo(0.0205, 0.5);
  s.lineTo(0.021, 0);
  const g = new THREE.ExtrudeGeometry(s, { depth: 0.012, bevelEnabled: false });
  g.translate(0, 0, -0.006);
  bladeGeo = g;
  return g;
}

const whiteBasic = new THREE.MeshBasicMaterial({ color: 0xffffff });
const glowEye = new THREE.MeshBasicMaterial({ color: 0xff2a2a });
whiteBasic.name = "glint";
glowEye.name = "glowEye";

const rnd = (n: number) => {
  const x = Math.sin(n * 127.1 + 311.7) * 43758.5453;
  return x - Math.floor(x);
};

/* ---------- خامات مشتركة بين كل الشخصيات ---------- */
type Assets = { lacBody: THREE.Texture; lacPlate: THREE.Texture; fabric: THREE.Texture };
const assetCache = new WeakMap<TexSet, Assets>();
function assets(tex: TexSet): Assets {
  let a = assetCache.get(tex);
  if (!a) {
    a = {
      lacBody: repeat(tex.lacing, 3, 1.3),
      lacPlate: repeat(tex.lacing, 0.7, 0.7),
      fabric: repeat(tex.fabric, 2, 2),
    };
    assetCache.set(tex, a);
  }
  return a;
}

/* ---------- دمج الأجزاء الثابتة لتقليل عدد الرسمات ---------- */
type Part = { g: THREE.BufferGeometry; mat: THREE.Material; m: THREE.Matrix4 };
const merged = new Map<string, THREE.BufferGeometry | null>();

function bake(kind: Kind, parts: Map<THREE.Object3D, Part[]>) {
  for (const [parent, list] of parts) {
    const byMat = new Map<THREE.Material, Part[]>();
    for (const p of list) {
      const a = byMat.get(p.mat);
      if (a) a.push(p);
      else byMat.set(p.mat, [p]);
    }
    for (const [mat, ps] of byMat) {
      const key = `${kind}|${parent.name}|${mat.name}`;
      let geom = merged.get(key);
      if (geom === undefined) {
        const arr = ps.map((p) => {
          let g = p.g.clone();
          g.applyMatrix4(p.m);
          if (g.index) g = g.toNonIndexed();
          return g;
        });
        geom = mergeGeometries(arr, false);
        for (const g of arr) g.dispose();
        merged.set(key, geom);
      }
      if (geom) {
        const mesh = new THREE.Mesh(geom, mat);
        mesh.castShadow = true;
        mesh.receiveShadow = true;
        parent.add(mesh);
      } else {
        // احتياطي: لو فشل الدمج نضيف الأجزاء منفصلة
        for (const p of ps) {
          const mesh = new THREE.Mesh(p.g, mat);
          p.m.decompose(mesh.position, mesh.quaternion, mesh.scale);
          mesh.castShadow = true;
          parent.add(mesh);
        }
      }
    }
  }
}

export function buildRig(kind: Kind, tex: TexSet, scene: THREE.Scene): Rig {
  const pal = PALS[kind];
  const A = assets(tex);
  const mats: THREE.MeshStandardMaterial[] = [];
  const M = (
    name: string,
    color: number,
    rough: number,
    metal: number,
    map?: THREE.Texture | null,
    bump = 0.5,
    flat = false,
  ) => {
    const m = new THREE.MeshStandardMaterial({
      color,
      roughness: rough,
      metalness: metal,
      map: map ?? null,
      bumpMap: bumpOf(map),
      bumpScale: bump,
      flatShading: flat,
      envMapIntensity: metal > 0.4 ? 1.15 : 0.5,
    });
    m.name = name;
    mats.push(m);
    return m;
  };

  // تنويع بسيط بين الأفراد من نفس النوع
  const tint = (kind === "pl" ? 0 : (Math.random() - 0.5) * 0.04) as number;

  const armor = M("armor", pal.armor, 0.4, 0.55, A.lacPlate, 0.8);
  const armorB = M("armorB", pal.armor, 0.42, 0.5, A.lacBody, 0.9);
  const armor2 = M("armor2", pal.armor2, 0.46, 0.5, A.lacPlate, 0.6);
  const lacquer = M("lacquer", pal.armor2, 0.28, 0.35);
  const cloth = M("cloth", pal.cloth, 0.92, 0.0, A.fabric, 0.7);
  const hakama = M("hakama", pal.cloth, 0.95, 0.0, A.fabric, 0.7, true);
  const sleeve = M("sleeve", pal.sleeve, 0.92, 0.0, A.fabric, 0.7);
  const juban = M("juban", 0xe6dfd0, 0.9, 0.0, A.fabric, 0.5);
  const sash = M("sash", pal.sash, 0.85, 0.0, A.fabric, 0.8);
  const cord = M("cord", pal.cord, 0.7, 0.05, A.fabric, 0.8);
  const trim = M("trim", pal.trim, 0.26, 0.9);
  const skin = M("skin", pal.skin, 0.52, 0.0, tex.skin, 0.35);
  const lips = M("lips", 0x9a5a50, 0.45, 0.0);
  const hair = M("hair", pal.hair, 0.5, 0.1);
  const dark = M("dark", 0x16130f, 0.5, 0.25);
  const leather = M("leather", 0x2a1c14, 0.7, 0.05, tex.leather, 0.7);
  const straw = M("straw", 0x9a8450, 0.95, 0.0, tex.tatami, 0.8);
  const tabi = M("tabi", 0xe8e2d6, 0.9, 0.0, A.fabric, 0.4);
  const steel = M("steel", 0xdfe7ef, 0.14, 0.88, tex.hamon, 0.2);
  const saya = M("saya", 0x12100e, 0.22, 0.3);
  const wrap = M("wrap", 0x1c1410, 0.78, 0.08, tex.leather, 0.9);
  const sclera = M("sclera", 0xe8e2da, 0.3, 0.0);
  const iris = M("iris", pal.eye, 0.25, 0.0, tex.eye, 0.0);
  const maskMat = M("mask", pal.armor2, 0.34, 0.55, tex.lacquer, 0.4);
  armor.color.offsetHSL(0, 0, tint);
  armorB.color.offsetHSL(0, 0, tint);

  const root = new THREE.Group();
  root.scale.setScalar(pal.scale * (kind === "pl" || kind === "boss" ? 1 : 0.97 + Math.random() * 0.06));
  const body = new THREE.Group();
  body.name = "body";
  root.add(body);

  const parts = new Map<THREE.Object3D, Part[]>();
  const tmp = new THREE.Object3D();
  const add = (
    g: THREE.BufferGeometry,
    mat: THREE.Material,
    parent: THREE.Object3D,
    x = 0,
    y = 0,
    z = 0,
    rx = 0,
    ry = 0,
    rz = 0,
    sx = 1,
    sy = 1,
    sz = 1,
  ) => {
    tmp.position.set(x, y, z);
    tmp.rotation.set(rx, ry, rz);
    tmp.scale.set(sx, sy, sz);
    tmp.updateMatrix();
    let list = parts.get(parent);
    if (!list) {
      list = [];
      parts.set(parent, list);
    }
    list.push({ g, mat, m: tmp.matrix.clone() });
  };

  /* ================= الساقان ================= */
  const legs: [THREE.Group, THREE.Group] = [new THREE.Group(), new THREE.Group()];
  const knees: [THREE.Group, THREE.Group] = [new THREE.Group(), new THREE.Group()];

  for (const side of [-1, 1] as const) {
    const i = side === -1 ? 0 : 1;
    const hip = legs[i];
    hip.name = `hip${i}`;
    hip.position.set(side * 0.1, 0.98, 0);
    body.add(hip);
    // فخذ (سروال)
    add(cyl(0.1, 0.082, 0.48, 14), cloth, hip, 0, -0.22, 0);
    // هايدات: حماية الفخذ بصفائح متراكبة
    for (let k = 0; k < 3; k++) {
      add(box(0.13 - k * 0.006, 0.085, 0.05), armor2, hip, 0, -0.07 - k * 0.08, 0.085 - k * 0.004, 0.14 + k * 0.05, 0, 0);
      add(box(0.12, 0.01, 0.052), trim, hip, 0, -0.105 - k * 0.08, 0.09 - k * 0.004, 0.14 + k * 0.05, 0, 0);
    }

    const knee = knees[i];
    knee.name = `knee${i}`;
    knee.position.set(0, -0.46, 0);
    hip.add(knee);
    // ساق ملفوفة
    add(cyl(0.074, 0.054, 0.46, 14), cloth, knee, 0, -0.22, 0);
    for (let k = 0; k < 5; k++) {
      add(cyl(0.07 - k * 0.003, 0.07 - k * 0.003, 0.012, 14), leather, knee, 0, -0.1 - k * 0.07, 0, 0, 0, 0, 1, 1, 1);
    }
    // سونيآتي: درع الساق الأمامي
    add(box(0.1, 0.3, 0.03), armor, knee, 0, -0.2, 0.06, -0.04, 0, 0);
    add(box(0.012, 0.3, 0.036), trim, knee, 0.05, -0.2, 0.058, -0.04, 0, 0);
    add(box(0.012, 0.3, 0.036), trim, knee, -0.05, -0.2, 0.058, -0.04, 0, 0);
    // واقي الركبة
    add(sph(0.05, 14, 10), armor2, knee, 0, 0.0, 0.055, 0, 0, 0, 1, 0.82, 0.7);
    add(cyl(0.012, 0.012, 0.012, 8), trim, knee, 0, 0.0, 0.088, Math.PI / 2, 0, 0);
    // القدم
    if (pal.foot === "waraji") {
      add(box(0.085, 0.05, 0.2), tabi, knee, 0, -0.468, 0.045);
      add(box(0.036, 0.046, 0.07), tabi, knee, 0.022, -0.468, 0.15);
      add(box(0.036, 0.046, 0.07), tabi, knee, -0.022, -0.468, 0.15);
      add(box(0.1, 0.022, 0.27), straw, knee, 0, -0.5, 0.05);
      add(box(0.012, 0.045, 0.1), cord, knee, 0.04, -0.478, 0.06, 0.5, 0, 0);
      add(box(0.012, 0.045, 0.1), cord, knee, -0.04, -0.478, 0.06, 0.5, 0, 0);
    } else {
      add(box(0.1, 0.07, 0.24), armor2, knee, 0, -0.465, 0.05);
      add(sph(0.05, 12, 8), armor, knee, 0, -0.475, 0.16, 0, 0, 0, 1, 0.7, 1.1);
      add(box(0.11, 0.025, 0.28), dark, knee, 0, -0.5, 0.05);
      add(box(0.02, 0.016, 0.2), trim, knee, 0, -0.43, 0.06);
    }
  }

  /* ================= الجذع ================= */
  const torso = new THREE.Group();
  torso.name = "torso";
  torso.position.y = 0.98;
  body.add(torso);

  // الكيمونو الداخلي والهاكاما (طيّات بتظليل مسطّح)
  add(cyl(0.19, 0.17, 0.3, 18), cloth, torso, 0, 0.16, 0, 0, 0, 0, 1, 1, 0.8);
  add(cyl(0.16, 0.3, 0.5, 18), hakama, torso, 0, -0.12, 0, 0, 0, 0, 1.1, 1, 0.85);
  add(box(0.19, 0.13, 0.035), dark, torso, 0, -0.02, -0.165);
  add(box(0.19, 0.012, 0.04), trim, torso, 0, -0.085, -0.165);
  // الحزام (أوبي) وعقدته وذيوله
  add(cyl(0.186, 0.186, 0.09, 20), sash, torso, 0, 0.12, 0, 0, 0, 0, 1, 1, 0.8);
  add(box(0.09, 0.07, 0.05), sash, torso, 0.06, 0.1, 0.17);
  add(box(0.05, 0.05, 0.04), sash, torso, 0.1, 0.12, 0.165, 0, 0, 0.5);
  add(box(0.035, 0.22, 0.012), sash, torso, 0.05, -0.02, 0.19, 0.05, 0, 0.08);
  add(box(0.035, 0.18, 0.012), sash, torso, 0.1, -0.0, 0.185, 0.05, 0, -0.1);
  // الصدر (دو-ماروا بصفائح مربوطة)
  add(cyl(0.205, 0.188, 0.34, 20), armorB, torso, 0, 0.38, 0, 0, 0, 0, 1.04, 1, 0.74);
  add(cyl(0.2, 0.2, 0.026, 20), trim, torso, 0, 0.22, 0, 0, 0, 0, 1.06, 1, 0.76);
  add(cyl(0.2, 0.2, 0.02, 20), trim, torso, 0, 0.545, 0, 0, 0, 0, 1.0, 1, 0.72);
  add(box(0.25, 0.14, 0.05), armor2, torso, 0, 0.45, 0.13);
  add(box(0.26, 0.012, 0.054), trim, torso, 0, 0.52, 0.13);
  add(box(0.26, 0.012, 0.054), trim, torso, 0, 0.38, 0.13);
  add(cyl(0.04, 0.04, 0.014, 16), trim, torso, 0, 0.45, 0.158, Math.PI / 2, 0, 0);
  add(cyl(0.022, 0.022, 0.016, 16), pal.cord === pal.trim ? dark : cord, torso, 0, 0.45, 0.16, Math.PI / 2, 0, 0);
  // حبال رأسية وأحزمة الكتف
  for (const sx of [-0.1, 0, 0.1]) add(box(0.012, 0.3, 0.012), cord, torso, sx, 0.37, 0.142);
  for (const side of [-1, 1] as const) {
    add(box(0.05, 0.03, 0.16), armor2, torso, side * 0.12, 0.57, 0, 0, 0, 0);
    add(box(0.05, 0.012, 0.162), trim, torso, side * 0.12, 0.586, 0);
  }
  // الظهر
  add(box(0.3, 0.28, 0.05), armor2, torso, 0, 0.38, -0.125);
  add(box(0.3, 0.012, 0.054), trim, torso, 0, 0.24, -0.125);
  // كوساتسوري: صفائح الوسط المتدلية
  const kus = [0, 0.5, -0.5, 1.0, -1.0, 1.55, -1.55, Math.PI - 0.5, Math.PI + 0.5, Math.PI];
  for (const a of kus) {
    const px = Math.sin(a) * 0.235;
    const pz = Math.cos(a) * 0.19;
    add(box(0.105, 0.17, 0.018), armor2, torso, px, 0.1, pz, 0.1, a, 0);
    add(box(0.105, 0.012, 0.022), trim, torso, px + Math.sin(a) * 0.006, 0.014, pz + Math.cos(a) * 0.006, 0.1, a, 0);
    add(box(0.01, 0.15, 0.022), cord, torso, px, 0.1, pz, 0.1, a, 0);
  }
  // سوديه: واقيات الكتف (ثلاث طبقات)
  for (const side of [-1, 1] as const) {
    for (let k = 0; k < 3; k++) {
      add(box(0.15 + k * 0.014, 0.07, 0.2 + k * 0.01), armor, torso, side * (0.295 + k * 0.012), 0.58 - k * 0.062, 0, 0, 0, side * -0.32);
      add(box(0.152 + k * 0.014, 0.01, 0.204 + k * 0.01), trim, torso, side * (0.3 + k * 0.014), 0.548 - k * 0.062, 0, 0, 0, side * -0.32);
    }
    add(box(0.012, 0.18, 0.012), cord, torso, side * 0.3, 0.5, 0.098, 0, 0, side * -0.32);
    if (pal.spikes) {
      add(cone(0.028, 0.2, 8), trim, torso, side * 0.33, 0.7, 0, 0, 0, side * -0.5);
      add(cone(0.02, 0.14, 8), trim, torso, side * 0.27, 0.68, -0.07, -0.4, 0, side * -0.3);
    }
  }

  // السيف الصغير (واكيزاشي) في الغمد على الخصر الأيسر
  add(cyl(0.028, 0.024, 0.74, 12), saya, torso, 0.21, 0.0, -0.12, -0.4, 0, 0.1);
  add(cyl(0.031, 0.031, 0.05, 12), trim, torso, 0.222, 0.138, 0.23, -0.4, 0, 0.1);
  add(cyl(0.025, 0.025, 0.03, 12), trim, torso, 0.196, -0.145, -0.472, -0.4, 0, 0.1);
  add(box(0.04, 0.034, 0.16), wrap, torso, 0.226, 0.204, 0.31, -0.4, 0, 0.1);
  add(cyl(0.05, 0.05, 0.01, 18), trim, torso, 0.228, 0.164, 0.248, Math.PI / 2 - 0.4, 0, 0.1, 1, 1, 0.8);
  // خيط الساجيو المتدلّي
  add(box(0.008, 0.2, 0.008), cord, torso, 0.17, -0.12, 0.18, 0.1, 0, 0.1);

  // حقيبة الكوناي
  add(box(0.11, 0.13, 0.06), leather, torso, -0.2, 0.04, 0.1, 0, -0.5, 0);
  add(box(0.11, 0.02, 0.064), dark, torso, -0.2, 0.1, 0.1, 0, -0.5, 0);
  for (let i = 0; i < 3; i++) {
    add(box(0.012, 0.09, 0.012), steel, torso, -0.22 + i * 0.022, 0.15, 0.115, 0, 0, 0.1 - i * 0.1);
    add(cyl(0.01, 0.01, 0.014, 8), dark, torso, -0.22 + i * 0.022, 0.2, 0.115, 0, 0, 0.1 - i * 0.1);
  }

  // راية الظهر (ساشيمونو): تواجه الخلف ليراها اللاعب
  if (pal.banner) {
    add(cyl(0.011, 0.011, 1.0, 8), dark, torso, 0, 0.66, -0.17);
    add(cyl(0.01, 0.01, 0.3, 8), dark, torso, 0, 1.12, -0.17, 0, 0, Math.PI / 2);
    add(cyl(0.02, 0.02, 0.05, 10), trim, torso, 0, 1.17, -0.17);
    const bm = new THREE.MeshStandardMaterial({
      map: tex.banner,
      bumpMap: bumpOf(tex.banner),
      bumpScale: 0.6,
      roughness: 0.75,
      metalness: 0.02,
      side: THREE.DoubleSide,
    });
    bm.name = "banner";
    mats.push(bm);
    add(box(0.27, 0.52, 0.008), bm, torso, 0, 0.85, -0.18);
  }

  // العباءة للزعيم: ثلاث ألواح مع طيّات
  let cape: THREE.Group | null = null;
  if (pal.cape) {
    cape = new THREE.Group();
    cape.name = "cape";
    cape.position.set(0, 0.52, -0.14);
    torso.add(cape);
    add(box(0.5, 1.0, 0.02), cloth, cape, 0, -0.5, 0);
    add(box(0.26, 1.0, 0.02), cloth, cape, 0.36, -0.5, 0.06, 0, -0.45, 0);
    add(box(0.26, 1.0, 0.02), cloth, cape, -0.36, -0.5, 0.06, 0, 0.45, 0);
    add(box(0.5, 0.025, 0.026), trim, cape, 0, -0.99, 0);
    add(box(0.5, 0.06, 0.03), armor2, cape, 0, -0.02, 0);
    add(sph(0.05, 10, 8), trim, cape, 0.2, -0.02, 0.03);
    add(sph(0.05, 10, 8), trim, cape, -0.2, -0.02, 0.03);
  }

  /* ================= الرأس والوجه ================= */
  const head = new THREE.Group();
  head.name = "head";
  head.position.set(0, 0.62, 0);
  torso.add(head);

  // الرقبة + ياقة الجوبان + حماية الحلق
  add(cyl(0.05, 0.058, 0.1, 14), skin, head, 0, -0.02, 0);
  add(cyl(0.07, 0.092, 0.07, 18), armor2, head, 0, -0.045, 0);
  add(cyl(0.074, 0.074, 0.01, 18), trim, head, 0, -0.012, 0);
  add(box(0.024, 0.08, 0.016), juban, head, 0.028, -0.02, 0.07, 0, 0, -0.42);
  add(box(0.024, 0.08, 0.016), juban, head, -0.028, -0.02, 0.07, 0, 0, 0.42);

  // الجمجمة والفك والخدود والذقن
  add(sph(0.105, 26, 18), skin, head, 0, 0.1, 0, 0, 0, 0, 0.94, 1.05, 1.02);
  add(sph(0.09, 20, 14), skin, head, 0, 0.04, 0.012, 0, 0, 0, 0.95, 0.75, 0.96);
  add(sph(0.03, 12, 8), skin, head, 0, 0.012, 0.08, 0, 0, 0, 1.2, 0.8, 0.9);
  for (const s of [-1, 1] as const) {
    add(sph(0.032, 12, 8), skin, head, s * 0.062, 0.07, 0.07, 0, 0, 0, 1, 0.9, 0.8);
    // الأذن
    add(sph(0.024, 12, 8), skin, head, s * 0.1, 0.1, -0.008, 0, 0, 0, 0.45, 1.1, 0.8);
    add(sph(0.012, 8, 6), dark, head, s * 0.103, 0.1, -0.003, 0, 0, 0, 0.4, 1, 0.8);
    // العين: صلبة + قزحية بملمس + لمعة + جفن
    const ex = s * 0.037;
    add(sph(0.0175, 14, 10), sclera, head, ex, 0.115, 0.082);
    if (pal.glow) {
      add(circ(0.0118, 16), glowEye, head, ex, 0.115, 0.0995);
    } else {
      add(circ(0.0105, 18), iris, head, ex, 0.115, 0.0995);
      add(sph(0.003, 6, 5), whiteBasic, head, ex + 0.004, 0.12, 0.1008);
    }
    add(box(0.042, 0.008, 0.026), skin, head, ex, 0.13, 0.088, -0.25, 0, s * 0.12);
    add(box(0.04, 0.005, 0.02), skin, head, ex, 0.101, 0.09, 0.2, 0, -s * 0.1);
    // الحاجب
    add(box(0.05, 0.011, 0.014), hair, head, s * 0.04, 0.152 + pal.brow * 0.02, 0.098, 0, 0, s * pal.brow * 1.1);
  }
  add(box(0.15, 0.014, 0.03), skin, head, 0, 0.143, 0.088, -0.15, 0, 0);

  const lowerFace = pal.face === "young" || pal.face === "bearded";
  if (lowerFace) {
    // الأنف والفم
    add(box(0.016, 0.05, 0.022), skin, head, 0, 0.098, 0.099, -0.15, 0, 0);
    add(sph(0.0155, 10, 8), skin, head, 0, 0.073, 0.108, 0, 0, 0, 1, 0.85, 1);
    add(sph(0.009, 8, 6), skin, head, 0.015, 0.072, 0.1);
    add(sph(0.009, 8, 6), skin, head, -0.015, 0.072, 0.1);
    add(box(0.04, 0.008, 0.014), lips, head, 0, 0.049, 0.098);
    add(box(0.036, 0.01, 0.014), lips, head, 0, 0.038, 0.096);
    add(box(0.044, 0.003, 0.012), dark, head, 0, 0.0435, 0.1);
  }
  if (pal.scar) {
    add(box(0.06, 0.006, 0.01), M("scar", 0x9a4a46, 0.6, 0), head, -0.03, 0.14, 0.099, 0, 0, 0.9);
    add(box(0.02, 0.003, 0.012), juban, head, -0.026, 0.139, 0.1, 0, 0, 0.9);
  }

  // اللحية والشارب للجندي
  if (pal.face === "bearded") {
    for (let i = 0; i < 34; i++) {
      const a = (rnd(i + 1) - 0.5) * 2.4;
      const r = 0.085 + rnd(i + 2) * 0.012;
      add(sph(0.012 + rnd(i + 3) * 0.006, 6, 5), hair, head, Math.sin(a) * r, 0.02 + rnd(i + 4) * 0.035, Math.cos(a) * r * 0.95 + 0.012, 0, 0, 0, 1, 1, 0.7);
    }
    add(box(0.05, 0.016, 0.02), hair, head, 0.026, 0.056, 0.1, 0, 0, 0.18);
    add(box(0.05, 0.016, 0.02), hair, head, -0.026, 0.056, 0.1, 0, 0, -0.18);
    add(sph(0.026, 10, 8), hair, head, 0, 0.0, 0.085, 0, 0, 0, 1, 1.3, 0.8);
  }

  // قناع الوجه (مينبو) للساموراي والنخبة والزعيم
  if (!lowerFace) {
    add(sph(0.11, 22, 14), maskMat, head, 0, 0.04, 0.026, 0, 0, 0, 1, 0.64, 1);
    add(box(0.07, 0.026, 0.02), trim, head, 0, 0.082, 0.12, -0.2, 0, 0);
    for (const s of [-1, 1] as const) {
      add(box(0.06, 0.01, 0.02), hair, head, s * 0.04, 0.062, 0.118, 0, 0, s * -0.25);
      add(box(0.022, 0.08, 0.04), maskMat, head, s * 0.092, 0.04, 0.04, 0, s * 0.4, 0);
      add(cyl(0.012, 0.012, 0.012, 8), trim, head, s * 0.1, 0.05, 0.05, 0, 0, Math.PI / 2);
    }
    // أسنان المنخر الغاضب
    add(box(0.07, 0.022, 0.02), dark, head, 0, 0.032, 0.116);
    for (let i = -3; i <= 3; i++) {
      add(box(0.007, 0.02, 0.008), juban, head, i * 0.0095, 0.032, 0.124);
    }
    if (pal.face === "oni") {
      for (const s of [-1, 1] as const) {
        add(cone(0.011, 0.045, 6), juban, head, s * 0.03, 0.062, 0.124, Math.PI, 0, 0);
        add(cone(0.014, 0.05, 6), juban, head, s * 0.042, 0.01, 0.114, 0, 0, 0);
        add(cone(0.014, 0.1, 6), trim, head, s * 0.1, 0.19, 0.04, 0.2, 0, s * -0.7);
      }
    }
  }

  /* ================= غطاء الرأس ================= */
  if (pal.hat === "jingasa") {
    add(cyl(0.012, 0.3, 0.12, 28, false), leather, head, 0, 0.225, 0, 0, 0, 0, 1, 1, 1);
    add(cyl(0.3, 0.3, 0.012, 28), dark, head, 0, 0.17, 0);
    add(sph(0.022, 10, 8), trim, head, 0, 0.292, 0);
    add(cyl(0.06, 0.07, 0.03, 12), dark, head, 0, 0.21, 0);
    for (const s of [-1, 1] as const) {
      add(box(0.008, 0.12, 0.008), cord, head, s * 0.09, 0.07, 0.04, 0, 0, s * 0.35);
    }
  } else if (pal.hat === "hair") {
    // شعر البطل: قبعة شعر + عقدة (تشونمَغي) + ذيل
    add(sph(0.112, 20, 14), hair, head, 0, 0.118, -0.016, 0, 0, 0, 1, 1, 1.0);
    for (const s of [-1, 1] as const) {
      add(box(0.012, 0.06, 0.03), hair, head, s * 0.103, 0.1, 0.02);
    }
    add(cyl(0.032, 0.04, 0.12, 12), hair, head, 0, 0.225, -0.045, -0.35, 0, 0);
    add(sph(0.036, 12, 8), hair, head, 0, 0.292, -0.08, 0, 0, 0, 1, 0.8, 1.2);
    add(cone(0.026, 0.16, 8), hair, head, 0, 0.345, -0.13, -1.0, 0, 0);
    add(cyl(0.036, 0.036, 0.012, 12), trim, head, 0, 0.27, -0.065, -0.35, 0, 0);
    // عصبة الجبين (هاتشيماكي) مع عقدة وذيلين
    add(tor(0.108, 0.013, 8, 28), juban, head, 0, 0.152, 0, Math.PI / 2, 0, 0, 1.0, 1.0, 1);
    add(box(0.11, 0.04, 0.012), trim, head, 0, 0.152, 0.114);
    add(tor(0.034, 0.005, 6, 14, Math.PI * 1.25), trim, head, 0, 0.154, 0.121, 0, 0, -0.4);
    add(sph(0.018, 8, 6), juban, head, 0, 0.152, -0.112);
    add(box(0.022, 0.15, 0.006), juban, head, 0.016, 0.075, -0.125, 0.25, 0, 0.1);
    add(box(0.022, 0.13, 0.006), juban, head, -0.016, 0.085, -0.122, 0.2, 0, -0.14);
  } else {
    // الخوذة (كابوتو): قبة + حافة + واقي جبهة + حماية عنق من صفائح
    add(dome(0.14, Math.PI * 0.52), armor, head, 0, 0.1, -0.005, 0, 0, 0, 1, 1.05, 1.04);
    add(cyl(0.148, 0.152, 0.03, 24), armor2, head, 0, 0.09, -0.005, 0, 0, 0, 1, 1, 1.04);
    add(box(0.21, 0.014, 0.075), armor2, head, 0, 0.17, 0.118, -0.38, 0, 0);
    add(box(0.21, 0.01, 0.078), trim, head, 0, 0.162, 0.125, -0.38, 0, 0);
    for (let r = 0; r < 8; r++) {
      const a = (r / 8) * Math.PI * 2;
      add(box(0.012, 0.15, 0.012), trim, head, Math.sin(a) * 0.075, 0.21, Math.cos(a) * 0.075 - 0.005, Math.cos(a) * 0.5, 0, -Math.sin(a) * 0.5);
    }
    for (let r = 0; r < 18; r++) {
      const a = (r / 18) * Math.PI * 2;
      add(sph(0.0085, 6, 5), trim, head, Math.sin(a) * 0.137, 0.115, Math.cos(a) * 0.137 - 0.005);
    }
    add(sph(0.016, 8, 6), trim, head, 0, 0.245, -0.005);
    // شيكورو: صفائح حماية العنق الخلفية
    for (let k = 0; k < 4; k++) {
      add(cyl(0.142 + k * 0.012, 0.15 + k * 0.014, 0.034, 20, true, Math.PI * 0.45, Math.PI * 1.1), armor, head, 0, 0.06 - k * 0.03, -0.01, 0, 0, 0);
      add(cyl(0.146 + k * 0.012, 0.146 + k * 0.012, 0.006, 20, true, Math.PI * 0.45, Math.PI * 1.1), trim, head, 0, 0.044 - k * 0.03, -0.01);
    }
    // فوكيغايشي: أجنحة الخوذة الجانبية
    for (const s of [-1, 1] as const) {
      add(box(0.016, 0.1, 0.075), armor2, head, s * 0.138, 0.11, 0.05, 0, s * -0.5, s * -0.15);
      add(box(0.018, 0.008, 0.078), trim, head, s * 0.14, 0.06, 0.05, 0, s * -0.5, s * -0.15);
    }
    // الشارة الأمامية (مايداتي)
    if (pal.crest === "horn") {
      for (const s of [-1, 1] as const) {
        add(cone(0.02, 0.22, 8), trim, head, s * 0.1, 0.3, 0.05, 0, 0, s * -0.55);
        add(cone(0.012, 0.1, 8), trim, head, s * 0.175, 0.39, 0.05, 0, 0, s * -0.1);
      }
      add(tor(0.05, 0.007, 6, 16, Math.PI), trim, head, 0, 0.225, 0.14, 0, 0, 0);
    } else if (pal.crest === "antler") {
      for (const s of [-1, 1] as const) {
        add(cone(0.024, 0.38, 8), trim, head, s * 0.1, 0.34, 0.0, 0, 0, s * -0.38);
        add(cone(0.014, 0.18, 6), trim, head, s * 0.18, 0.34, 0.0, 0, 0, s * -1.1);
        add(cone(0.012, 0.16, 6), trim, head, s * 0.22, 0.5, 0.0, 0, 0, s * -0.2);
        add(cone(0.011, 0.14, 6), trim, head, s * 0.14, 0.42, 0.0, 0.5, 0, s * -0.3);
      }
      add(box(0.06, 0.09, 0.012), trim, head, 0, 0.2, 0.15, -0.2, 0, 0);
    } else if (pal.crest === "moon") {
      add(tor(0.09, 0.01, 6, 20, Math.PI * 1.25), trim, head, 0, 0.3, 0.02, 0, 0, -0.4);
    }
  }

  /* ================= الذراعان واليدان ================= */
  const arms: [THREE.Group, THREE.Group] = [new THREE.Group(), new THREE.Group()];
  const fores: [THREE.Group, THREE.Group] = [new THREE.Group(), new THREE.Group()];
  for (const side of [-1, 1] as const) {
    const i = side === -1 ? 1 : 0; // -1 هي يمين الشخصية
    const arm = arms[i];
    arm.name = `arm${i}`;
    arm.position.set(side * 0.24, 0.48, 0);
    torso.add(arm);
    // كم الكيمونو الواسع
    add(cyl(0.056, 0.075, 0.3, 14), sleeve, arm, 0, -0.15, 0);
    add(cyl(0.078, 0.078, 0.012, 14), trim, arm, 0, -0.295, 0);
    add(box(0.09, 0.1, 0.09), armor2, arm, 0, -0.06, 0.0);
    const fore = fores[i];
    fore.name = `fore${i}`;
    fore.position.set(0, -0.28, 0);
    arm.add(fore);
    // ساعد + كوته (درع الساعد)
    add(cyl(0.044, 0.036, 0.26, 12), cloth, fore, 0, -0.13, 0);
    add(cyl(0.054, 0.046, 0.2, 12), armorB, fore, 0, -0.12, 0);
    for (let k = 0; k < 3; k++) {
      add(cyl(0.056 - k * 0.004, 0.056 - k * 0.004, 0.01, 12), trim, fore, 0, -0.04 - k * 0.07, 0);
    }
    add(box(0.06, 0.07, 0.014), armor2, fore, 0, -0.275, -0.03);
    add(box(0.062, 0.008, 0.016), trim, fore, 0, -0.31, -0.03);
    // اليد: كف + أصابع بمفصلين + إبهام
    add(box(0.06, 0.065, 0.034), skin, fore, 0, -0.29, 0.004);
    for (let f = 0; f < 4; f++) {
      const fx = -0.021 + f * 0.014;
      add(box(0.0125, 0.036, 0.016), skin, fore, fx, -0.33, 0.026, -0.7, 0, 0);
      add(box(0.0115, 0.028, 0.014), skin, fore, fx, -0.332, 0.05, -1.5, 0, 0);
    }
    add(box(0.016, 0.04, 0.018), skin, fore, side * 0.036, -0.3, 0.022, -0.6, 0, side * 0.4);
  }

  /* ================= السيف (كاتانا) ================= */
  const sw = new THREE.Group();
  sw.name = "sword";
  sw.position.set(0, -0.28, 0.02);
  sw.rotation.set(1.35, 0.2, 0.15);
  fores[1].add(sw);
  add(cyl(0.017, 0.016, 0.25, 12), wrap, sw, 0, 0.07, 0);
  for (let k = 0; k < 7; k++) {
    add(box(0.036, 0.008, 0.008), cord, sw, 0, -0.02 + k * 0.032, 0.012, 0, 0, k % 2 ? 0.7 : -0.7);
  }
  add(cyl(0.02, 0.02, 0.016, 12), trim, sw, 0, -0.06, 0);
  add(sph(0.021, 10, 8), trim, sw, 0, -0.065, 0, 0, 0, 0, 1, 0.8, 1);
  add(cyl(0.062, 0.062, 0.012, 24), dark, sw, 0, 0.2, 0, 0, 0, 0, 1, 1, 0.82);
  add(tor(0.06, 0.005, 6, 24), trim, sw, 0, 0.2, 0, Math.PI / 2, 0, 0, 1, 0.82, 1);
  add(cyl(0.026, 0.026, 0.026, 12), trim, sw, 0, 0.222, 0, 0, 0, 0, 1, 1, 0.5);
  add(blade(), steel, sw, 0, 0.23, 0);
  add(box(0.004, 0.62, 0.016), steel, sw, 0.0, 0.58, 0.0);

  scene.add(root);
  bake(kind, parts);

  const rig: Rig = {
    kind,
    root,
    body,
    torso,
    head,
    legs,
    knees,
    arms,
    fores,
    sword: sw,
    swBlend: 0,
    cape,
    mats,
    phase: Math.random() * 6,
    flashing: false,
  };
  poseRig(rig, idleAnim(0), 0);
  return rig;
}

export function idleAnim(time: number): Anim {
  return {
    speed: 0,
    attack: 0,
    attackDur: 0.4,
    combo: 0,
    throwing: 0,
    dodge: 0,
    dodgeSide: 1,
    hurt: 0,
    time,
    dead: 0,
  };
}

export function poseRig(r: Rig, a: Anim, dt: number) {
  r.phase += dt * (2.1 + Math.min(8, a.speed) * 1.35);
  const s = Math.sin(r.phase);
  const walk = Math.min(1, a.speed / 3.4);
  r.legs[0].rotation.x = s * 0.7 * walk;
  r.legs[1].rotation.x = -s * 0.7 * walk;
  r.knees[0].rotation.x = Math.max(0, -s) * 0.95 * walk;
  r.knees[1].rotation.x = Math.max(0, s) * 0.95 * walk;
  r.body.position.y = -Math.abs(Math.sin(r.phase)) * 0.035 * walk;
  // تنفّس وتمايل خفيف أثناء المشي
  r.torso.rotation.set(Math.sin(a.time * 1.6) * 0.02, -s * 0.08 * walk, Math.sin(r.phase * 0.5) * 0.02 * walk);
  r.head.rotation.set(-0.08, Math.sin(a.time * 0.7) * 0.05 + s * 0.04 * walk, 0);
  r.arms[0].rotation.set(0.22 + s * 0.35 * walk, 0, 0.22);
  r.arms[1].rotation.set(0.42 - s * 0.2 * walk, 0.1, -0.28);
  r.fores[0].rotation.set(-0.5, 0, 0);
  r.fores[1].rotation.set(-0.62, 0, 0);

  // وضع السيف: مرفوع للأمام في الوقوف، ويعود لوضع الضربة أثناء الهجوم
  const striking = a.attack > 0 || a.throwing > 0;
  const k = dt > 0 ? Math.min(1, dt * 14) : 1;
  r.swBlend += ((striking ? 1 : 0) - r.swBlend) * k;
  r.sword.rotation.x = 1.35 + (-1.05 - 1.35) * r.swBlend;

  if (a.dead > 0) {
    const u = Math.min(1, a.dead / 0.7);
    r.body.rotation.x = u * 1.35;
    r.body.position.y = -u * 0.15;
    r.arms[0].rotation.x = 0.4;
    r.arms[1].rotation.x = 0.2;
    return;
  }
  r.body.rotation.x = 0;

  if (a.attack > 0) {
    const u = 1 - a.attack / Math.max(0.05, a.attackDur);
    const swing = Math.sin(Math.min(1, Math.max(0, u)) * Math.PI);
    if (a.combo === 0) {
      r.torso.rotation.y = -swing * 1.05;
      r.torso.rotation.x = -0.12 * swing;
      r.arms[1].rotation.set(-0.5 + u * 2.1, 0, -0.55);
      r.fores[1].rotation.x = -0.15;
    } else if (a.combo === 1) {
      r.torso.rotation.y = swing * 1.15;
      r.arms[1].rotation.set(-0.15, 0, 0.35 - u * 1.5);
      r.fores[1].rotation.x = -0.25;
    } else {
      r.torso.rotation.x = -0.55 + u * 1.25;
      r.arms[1].rotation.set(-2.5 + u * 3.5, 0, -0.15);
      r.fores[1].rotation.x = -0.05;
      r.body.position.y -= 0.04;
    }
  } else if (a.throwing > 0) {
    r.torso.rotation.y = -0.4 * a.throwing;
    r.torso.rotation.x = -0.1 * a.throwing;
    r.arms[1].rotation.set(-1.65 * a.throwing, 0, -0.1);
    r.fores[1].rotation.x = -0.05 * a.throwing;
  }

  if (a.dodge > 0) {
    r.torso.rotation.x = 0.85;
    r.body.rotation.z = a.dodgeSide * 0.28;
    r.body.position.y -= 0.12;
  } else {
    r.body.rotation.z = 0;
  }

  if (a.hurt > 0) r.torso.rotation.x += 0.4;

  if (r.cape) r.cape.rotation.x = 0.16 + Math.sin(a.time * 2.5) * 0.07 + walk * 0.22;

  const on = a.hurt > 0;
  if (r.flashing !== on) {
    r.flashing = on;
    for (const m of r.mats) m.emissive.setHex(on ? 0x7a1618 : 0x000000);
  }
}

export function destroyRig(rig: Rig, scene: THREE.Scene) {
  scene.remove(rig.root);
  // الهندسة المدمجة مشتركة بين كل أفراد النوع الواحد، لذلك نحرّر الخامات فقط
  for (const m of rig.mats) m.dispose();
}
