import * as THREE from "three";
import { RoomEnvironment } from "three/examples/jsm/environments/RoomEnvironment.js";
import { bumpOf, makeTextures } from "./materials";
import { buildRig, destroyRig, poseRig, type Anim, type Kind, type Rig } from "./rig";
import { buildWorld, type Spawn, type Wall, type WorldApi } from "./world";

declare global {
  interface Window {
    __controlsTest?: {
      getYaw: () => number;
      getSpeed: () => number;
      setKeys?: (codes: string[]) => void;
    };
  }
}

export type GameUi = {
  root: HTMLElement;
  canvas: HTMLCanvasElement;
  hp: HTMLElement;
  obj: HTMLElement;
  ammo: HTMLElement;
  charge: HTMLElement;
  arr: HTMLElement;
  dist: HTMLElement;
  boss: HTMLElement;
  bossHp: HTMLElement;
  msg: HTMLElement;
  map: HTMLCanvasElement;
  ov: HTMLElement;
  go: HTMLButtonElement;
  ot: HTMLElement;
  op: HTMLElement;
  zone: HTMLElement;
  ring: HTMLElement;
  knob: HTMLElement;
  atk: HTMLElement;
  dge: HTMLElement;
  jmp: HTMLElement;
  kni: HTMLElement;
  look: HTMLElement;
};

type EKind = Exclude<Kind, "pl">;
type AI = "idle" | "chase" | "wind" | "recover" | "slam";

type Enemy = {
  kind: EKind;
  x: number;
  z: number;
  yaw: number;
  camp: number;
  palace: boolean;
  dormant: boolean;
  patrol: [number, number][] | null;
  pi: number;
  hp: number;
  max: number;
  r: number;
  alive: boolean;
  state: AI;
  st: number;
  alert: boolean;
  hurt: number;
  kx: number;
  kz: number;
  slamCd: number;
  rig: Rig | null;
};

const STATS: Record<EKind, { hp: number; speed: number; dmg: number; range: number; wind: number; r: number; aggro: number }> = {
  ash: { hp: 100, speed: 3.15, dmg: 8, range: 1.6, wind: 0.48, r: 0.38, aggro: 13 },
  sam: { hp: 170, speed: 3.45, dmg: 12, range: 1.75, wind: 0.4, r: 0.4, aggro: 15 },
  eli: { hp: 280, speed: 3.7, dmg: 16, range: 1.9, wind: 0.36, r: 0.42, aggro: 16 },
  boss: { hp: 720, speed: 3.25, dmg: 18, range: 2.55, wind: 0.55, r: 0.72, aggro: 22 },
};

const clamp = (v: number, a: number, b: number) => Math.max(a, Math.min(b, v));
const lerpAng = (a: number, b: number, t: number) => {
  const d = Math.atan2(Math.sin(b - a), Math.cos(b - a));
  return a + d * clamp(t, 0, 1);
};
const angDiff = (a: number, b: number) => Math.abs(Math.atan2(Math.sin(b - a), Math.cos(b - a)));

function mulberry(seed: number) {
  let s = seed >>> 0;
  return () => {
    s = (s + 0x6d2b79f5) | 0;
    let t = Math.imul(s ^ (s >>> 15), 1 | s);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

const GAME_KEYS = new Set([
  "Space",
  "ShiftLeft",
  "ShiftRight",
  "KeyF",
  "KeyC",
  "ArrowUp",
  "ArrowDown",
  "ArrowLeft",
  "ArrowRight",
  "KeyW",
  "KeyA",
  "KeyS",
  "KeyD",
]);

export function startGame(ui: GameUi) {
  const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  const coarse = window.matchMedia("(pointer: coarse)").matches;
  const renderer = new THREE.WebGLRenderer({
    canvas: ui.canvas,
    antialias: true,
    alpha: false,
    powerPreference: "high-performance",
  });
  if (!renderer.getContext()) {
    ui.op.textContent = "تعذّر تشغيل الرسوم ثلاثية الأبعاد في هذا المتصفح.";
    ui.go.hidden = true;
    return { stop() {} };
  }
  const dpr = Math.min(window.devicePixelRatio || 1, coarse ? 1.5 : 2);
  renderer.setPixelRatio(dpr);
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = 1.0;
  renderer.shadowMap.enabled = true;
  renderer.shadowMap.type = THREE.PCFSoftShadowMap;
  renderer.setClearColor(0x140c14);

  const scene = new THREE.Scene();
  scene.fog = new THREE.FogExp2(0x1d1226, 0.0105);
  scene.background = new THREE.Color(0x1a1022);
  const camera = new THREE.PerspectiveCamera(58, 1, 0.12, 520);

  const tex = makeTextures(Math.min(8, renderer.capabilities.getMaxAnisotropy()));
  try {
    const pmrem = new THREE.PMREMGenerator(renderer);
    const env = pmrem.fromScene(new RoomEnvironment(), 0.05).texture;
    scene.environment = env;
    scene.environmentIntensity = 0.55;
    pmrem.dispose();
  } catch {
    /* reflection probe is optional */
  }

  const hemi = new THREE.HemisphereLight(0x9fb2e8, 0x2e2018, 0.8);
  scene.add(hemi);
  const moon = new THREE.DirectionalLight(0xbccaff, 3.1);
  moon.castShadow = true;
  const shadowSize = coarse ? 1024 : 2048;
  moon.shadow.mapSize.set(shadowSize, shadowSize);
  moon.shadow.bias = -0.00035;
  moon.shadow.normalBias = 0.04;
  const sc = moon.shadow.camera;
  sc.near = 2;
  sc.far = 96;
  sc.left = -28;
  sc.right = 28;
  sc.top = 28;
  sc.bottom = -28;
  scene.add(moon);
  scene.add(moon.target);
  const fill = new THREE.DirectionalLight(0xff9a78, 0.45);
  fill.position.set(-18, 22, -12);
  scene.add(fill);

  const world: WorldApi = buildWorld(scene, tex, mulberry(11));
  const sky = new THREE.Mesh(
    new THREE.SphereGeometry(430, 28, 16),
    new THREE.MeshBasicMaterial({ map: tex.sky, side: THREE.BackSide, fog: false, depthWrite: false }),
  );
  sky.renderOrder = -2;
  scene.add(sky);
  const moonOrb = new THREE.Mesh(
    new THREE.SphereGeometry(16, 18, 12),
    new THREE.MeshBasicMaterial({ color: 0xd13a48, fog: false }),
  );
  moonOrb.position.set(-180, 120, -220);
  scene.add(moonOrb);

  const points: THREE.PointLight[] = [];
  for (let i = 0; i < 5; i++) {
    const l = new THREE.PointLight(0xffa060, 0, 14, 2);
    scene.add(l);
    points.push(l);
  }

  const playerRig = buildRig("pl", tex, scene);
  const openWalls = world.walls;
  const shutWalls = world.walls.concat([world.door]);
  let walls: Wall[] = shutWalls;

  const metal = new THREE.MeshStandardMaterial({ color: 0xb7c2cc, roughness: 0.22, metalness: 0.88 });
  const wrapM = new THREE.MeshStandardMaterial({ color: 0x2a2118, roughness: 0.7, metalness: 0.08 });
  const kunaiGeoBlade = new THREE.ConeGeometry(0.03, 0.2, 4);
  kunaiGeoBlade.rotateX(Math.PI / 2);
  kunaiGeoBlade.translate(0, 0, 0.12);
  const kunaiGeoHandle = new THREE.CylinderGeometry(0.014, 0.014, 0.14, 6);
  kunaiGeoHandle.rotateX(Math.PI / 2);
  kunaiGeoHandle.translate(0, 0, -0.02);
  type Kunai = {
    mesh: THREE.Group;
    x: number;
    y: number;
    z: number;
    vx: number;
    vy: number;
    vz: number;
    life: number;
    spin: number;
    active: boolean;
    stuck: boolean;
  };
  const kunai: Kunai[] = [];
  for (let i = 0; i < 18; i++) {
    const g = new THREE.Group();
    const b = new THREE.Mesh(kunaiGeoBlade, metal);
    const h = new THREE.Mesh(kunaiGeoHandle, wrapM);
    const ring = new THREE.Mesh(new THREE.TorusGeometry(0.026, 0.006, 6, 10), metal);
    ring.position.z = -0.1;
    b.castShadow = true;
    g.add(b, h, ring);
    g.visible = false;
    g.scale.setScalar(1.15);
    scene.add(g);
    kunai.push({ mesh: g, x: 0, y: -20, z: 0, vx: 0, vy: 0, vz: 0, life: 0, spin: 0, active: false, stuck: false });
  }

  const dummy = new THREE.Object3D();
  const BD = 80;
  const bloodMesh = new THREE.InstancedMesh(
    new THREE.SphereGeometry(0.045, 5, 4),
    new THREE.MeshBasicMaterial({ color: 0x9a1224 }),
    BD,
  );
  bloodMesh.frustumCulled = false;
  scene.add(bloodMesh);
  const drops = Array.from({ length: BD }, () => ({ life: 0, x: 0, y: 0, z: 0, vx: 0, vy: 0, vz: 0, s: 1 }));
  const DC = 48;
  const decalGeo = new THREE.CircleGeometry(1, 8);
  decalGeo.rotateX(-Math.PI / 2);
  const decals = new THREE.InstancedMesh(
    decalGeo,
    new THREE.MeshBasicMaterial({
      color: 0x4a0610,
      transparent: true,
      opacity: 0.88,
      depthWrite: false,
      polygonOffset: true,
      polygonOffsetFactor: -2,
      polygonOffsetUnits: -2,
    }),
    DC,
  );
  decals.frustumCulled = false;
  scene.add(decals);
  let decalN = 0;

  const slashMat = new THREE.MeshBasicMaterial({
    color: 0xfff1ea,
    transparent: true,
    opacity: 0,
    side: THREE.DoubleSide,
    depthWrite: false,
    blending: THREE.AdditiveBlending,
  });
  const slash = new THREE.Mesh(new THREE.RingGeometry(0.35, 1.2, 26, 1, 0.15, Math.PI * 1.2), slashMat);
  scene.add(slash);
  let slashOp = 0;

  const warnMat = new THREE.MeshBasicMaterial({
    color: 0xff3344,
    transparent: true,
    opacity: 0,
    side: THREE.DoubleSide,
    depthWrite: false,
  });
  const warn = new THREE.Mesh(new THREE.RingGeometry(0.55, 0.82, 28).rotateX(-Math.PI / 2), warnMat);
  scene.add(warn);

  let audio: AudioContext | null = null;
  const keys = new Set<string>();
  let joyX = 0;
  let joyY = 0;
  let inX = 0;
  let inZ = 0;
  let atkBtn = false;
  let dgeBtn = false;
  let jmpBtn = false;
  let kniBtn = false;
  let prevAtk = false;
  let prevDge = false;
  let prevJmp = false;
  let attackEdge = false;
  let dodgeEdge = false;
  let jumpEdge = false;
  let kunaiHeld = false;
  let queuedKunai = false;
  let padLookX = 0;
  let padLookY = 0;
  let camYaw = 0;
  let camPitch = 0.42;
  let time = 0;
  let shake = 0;
  let hitstop = 0;
  let msgT = 0;
  let doorOpen = false;
  let doorT = 0;
  let cleared = 0;
  let kills = 0;
  let state: "menu" | "play" | "dying" | "dead" | "winning" | "won" = "menu";
  let endT = 0;
  let mfc = 0;
  let raf = 0;
  const accHold = { v: 0 };
  const STEP = 1 / 60;
  const timer = new THREE.Timer();
  timer.connect(document);

  const P = {
    x: 0,
    y: 0,
    z: 132,
    yaw: 0,
    vx: 0,
    vz: 0,
    vy: 0,
    kx: 0,
    kz: 0,
    hp: 100,
    r: 0.36,
    speed: 0,
    attack: 0,
    ad: 0.4,
    combo: 0,
    buf: 0,
    comboWindow: 0,
    didHit: false,
    inv: 0,
    hurt: 0,
    dodge: 0,
    dodgeCd: 0,
    dodgeSide: 1,
    dvx: 0,
    dvz: 0,
    grounded: true,
    coyote: 0,
    jumpBuf: 0,
    ammo: 8,
    maxAmmo: 12,
    regen: 0,
    charge: 0,
    charging: false,
    kcd: 0,
    throwT: 0,
    deadT: 0,
  };

  let enemies: Enemy[] = [];
  const corpses: { rig: Rig; t: number }[] = [];

  function ensureAudio() {
    try {
      audio = audio || new AudioContext();
      if (audio.state === "suspended") void audio.resume();
    } catch {
      /* ignore */
    }
  }

  function sfx(freq: number, dur: number, type: OscillatorType, vol: number) {
    if (!audio) return;
    try {
      const o = audio.createOscillator();
      const g = audio.createGain();
      const t0 = audio.currentTime;
      o.type = type;
      o.frequency.setValueAtTime(freq, t0);
      o.frequency.exponentialRampToValueAtTime(Math.max(40, freq / 3), t0 + dur);
      g.gain.setValueAtTime(vol, t0);
      g.gain.exponentialRampToValueAtTime(0.001, t0 + dur);
      o.connect(g);
      g.connect(audio.destination);
      o.start();
      o.stop(t0 + dur);
    } catch {
      /* ignore */
    }
  }

  function say(text: string) {
    ui.msg.textContent = text;
    ui.msg.classList.add("on");
    msgT = 2.8;
  }

  function showOver(title: string, body: string, btn: string) {
    ui.ot.textContent = title;
    ui.op.textContent = body;
    ui.go.textContent = btn;
    ui.go.hidden = false;
    ui.ov.classList.add("on");
  }

  function clearBlood() {
    dummy.position.set(0, -40, 0);
    dummy.rotation.set(0, 0, 0);
    dummy.scale.setScalar(0.001);
    dummy.updateMatrix();
    for (let i = 0; i < DC; i++) decals.setMatrixAt(i, dummy.matrix);
    decals.instanceMatrix.needsUpdate = true;
    decalN = 0;
    for (const p of drops) p.life = 0;
  }

  function stamp(x: number, z: number, rad: number) {
    dummy.rotation.set(0, Math.random() * Math.PI * 2, 0);
    dummy.position.set(x, world.gh(x, z) + 0.045, z);
    dummy.scale.set(rad * 1.4, 1, rad * (0.65 + Math.random() * 0.4));
    dummy.updateMatrix();
    decals.setMatrixAt(decalN % DC, dummy.matrix);
    decalN++;
    decals.instanceMatrix.needsUpdate = true;
  }

  function spray(x: number, y: number, z: number, ang: number, n: number) {
    let c = 0;
    for (const p of drops) {
      if (c >= n) break;
      if (p.life > 0) continue;
      c++;
      const a = ang + (Math.random() - 0.5) * 1.5;
      const s = 4 + Math.random() * 7;
      p.life = 0.35 + Math.random() * 0.45;
      p.x = x;
      p.y = y;
      p.z = z;
      p.vx = Math.sin(a) * s;
      p.vz = Math.cos(a) * s;
      p.vy = 1.8 + Math.random() * 3.2;
      p.s = 0.7 + Math.random() * 0.8;
    }
  }

  function updDrops(dt: number) {
    for (let i = 0; i < BD; i++) {
      const p = drops[i]!;
      if (p.life > 0) {
        p.life -= dt;
        p.vy -= 16 * dt;
        p.x += p.vx * dt;
        p.y += p.vy * dt;
        p.z += p.vz * dt;
        if (p.y <= world.gh(p.x, p.z) + 0.05 || p.life <= 0) {
          if (p.life > -1) stamp(p.x, p.z, 0.07 + Math.random() * 0.07);
          p.life = 0;
          dummy.position.set(0, -40, 0);
          dummy.scale.setScalar(0.001);
          dummy.rotation.set(0, 0, 0);
        } else {
          dummy.position.set(p.x, p.y, p.z);
          dummy.rotation.set(0, 0, 0);
          dummy.scale.setScalar(p.s);
        }
      } else {
        dummy.position.set(0, -40, 0);
        dummy.rotation.set(0, 0, 0);
        dummy.scale.setScalar(0.001);
      }
      dummy.updateMatrix();
      bloodMesh.setMatrixAt(i, dummy.matrix);
    }
    bloodMesh.instanceMatrix.needsUpdate = true;
  }

  function pointInTall(x: number, z: number) {
    for (const w of walls) {
      if (w.tall && x > w.x0 && x < w.x1 && z > w.z0 && z < w.z1) return true;
    }
    return false;
  }

  function collide(o: { x: number; z: number }, r: number) {
    for (const w of walls) {
      const cx = clamp(o.x, w.x0, w.x1);
      const cz = clamp(o.z, w.z0, w.z1);
      const dx = o.x - cx;
      const dz = o.z - cz;
      const d2 = dx * dx + dz * dz;
      if (d2 >= r * r) continue;
      if (d2 > 1e-8) {
        const d = Math.sqrt(d2);
        o.x = cx + (dx / d) * r;
        o.z = cz + (dz / d) * r;
      } else {
        const dl = o.x - w.x0;
        const dr = w.x1 - o.x;
        const df = o.z - w.z0;
        const db = w.z1 - o.z;
        const m = Math.min(dl, dr, df, db);
        if (m === dl) o.x = w.x0 - r;
        else if (m === dr) o.x = w.x1 + r;
        else if (m === df) o.z = w.z0 - r;
        else o.z = w.z1 + r;
      }
    }
    const i = Math.floor(o.x / 20);
    const j = Math.floor(o.z / 20);
    for (let a = i - 1; a <= i + 1; a++) {
      for (let b = j - 1; b <= j + 1; b++) {
        const Ls = world.grid.get(`${a},${b}`);
        if (!Ls) continue;
        for (const c of Ls) {
          const dx = o.x - c.x;
          const dz = o.z - c.z;
          const m = r + c.r;
          const d2 = dx * dx + dz * dz;
          if (d2 < m * m && d2 > 1e-8) {
            const d = Math.sqrt(d2);
            o.x = c.x + (dx / d) * m;
            o.z = c.z + (dz / d) * m;
          }
        }
      }
    }
    o.x = clamp(o.x, -188, 188);
    o.z = clamp(o.z, -188, 188);
  }

  function slide(o: { x: number; z: number }, dx: number, dz: number, r: number) {
    o.x += dx;
    collide(o, r);
    o.z += dz;
    collide(o, r);
  }

  function los(ax: number, az: number, bx: number, bz: number) {
    const dist = Math.hypot(bx - ax, bz - az);
    const n = Math.ceil(dist / 0.9);
    for (let i = 1; i < n; i++) {
      const x = ax + ((bx - ax) * i) / n;
      const z = az + ((bz - az) * i) / n;
      if (pointInTall(x, z)) return false;
    }
    return true;
  }

  function makeEnemy(s: Spawn): Enemy {
    const st = STATS[s.kind as EKind];
    return {
      kind: s.kind as EKind,
      x: s.x,
      z: s.z,
      yaw: s.yaw,
      camp: s.camp,
      palace: s.palace,
      dormant: s.dormant,
      patrol: s.patrol,
      pi: 0,
      hp: st.hp,
      max: st.hp,
      r: st.r,
      alive: true,
      state: "idle",
      st: 0,
      alert: false,
      hurt: 0,
      kx: 0,
      kz: 0,
      slamCd: 2,
      rig: null,
    };
  }

  function alertNear(e: Enemy) {
    for (const q of enemies) {
      if (!q.alive || q === e || q.state !== "idle" || q.dormant) continue;
      if (Math.hypot(q.x - e.x, q.z - e.z) < 12) {
        q.alert = true;
        q.state = "chase";
      }
    }
  }

  function killEnemy(e: Enemy) {
    e.alive = false;
    kills++;
    P.ammo = Math.min(P.maxAmmo, P.ammo + 2);
    spray(e.x, world.gh(e.x, e.z) + 1.1, e.z, P.yaw, e.kind === "boss" ? 28 : 16);
    for (let i = 0; i < 6; i++) stamp(e.x + (Math.random() - 0.5) * 1.2, e.z + (Math.random() - 0.5) * 1.2, 0.16);
    shake = Math.max(shake, e.kind === "boss" ? 0.45 : 0.18);
    sfx(90, 0.28, "square", 0.08);
    if (e.rig) {
      corpses.push({ rig: e.rig, t: 0.01 });
      e.rig = null;
      if (corpses.length > 8) {
        const old = corpses.shift();
        if (old) destroyRig(old.rig, scene);
      }
    }
    if (e.camp >= 0 && !enemies.some((q) => q.alive && q.camp === e.camp)) {
      const camp = world.camps[e.camp];
      if (camp && !camp.done) {
        camp.done = true;
        cleared = world.camps.filter((c) => c.done).length;
        P.hp = Math.min(100, P.hp + 36);
        say(
          cleared < 4
            ? `تم تطهير المعسكر (${cleared}/4) — استعدت صحتك`
            : "تم تطهير كل المعسكرات — اقتحم القصر",
        );
        sfx(520, 0.3, "triangle", 0.05);
      }
    }
    if (!doorOpen && !enemies.some((q) => q.alive && q.palace && !q.dormant)) {
      doorOpen = true;
      walls = openWalls;
      say("انفتح باب قاعة العرش");
      sfx(180, 0.45, "sine", 0.06);
    }
    if (e.kind === "boss" && state === "play") {
      state = "winning";
      endT = 1.7;
    }
  }

  function hurtEnemy(e: Enemy, dmg: number, kx: number, kz: number, heavy: boolean) {
    if (!e.alive || e.dormant) return;
    e.hp -= dmg;
    e.hurt = 0.16;
    const bossScale = e.kind === "boss" ? 0.16 : 1;
    e.kx += kx * bossScale;
    e.kz += kz * bossScale;
    e.alert = true;
    alertNear(e);
    const ang = Math.atan2(kx, kz);
    spray(e.x, world.gh(e.x, e.z) + 1.2, e.z, ang, heavy ? 14 : 7);
    if (e.state === "idle") e.state = "chase";
    if (e.hp <= 0) {
      killEnemy(e);
      return;
    }
    if (heavy && e.kind !== "boss") {
      e.state = "recover";
      e.st = 0.34;
    }
    if (heavy) sfx(160, 0.1, "square", 0.06);
  }

  function hurtPlayer(dmg: number, fx: number, fz: number) {
    if (P.inv > 0 || P.hp <= 0 || state !== "play") return;
    P.hp = Math.max(0, P.hp - dmg);
    P.inv = 0.62;
    P.hurt = 0.22;
    P.kx += fx;
    P.kz += fz;
    shake = Math.max(shake, reduce ? 0.05 : 0.22);
    spray(P.x, P.y + 1.2, P.z, Math.atan2(fx, fz), 12);
    sfx(110, 0.18, "square", 0.07);
    if (P.hp <= 0) {
      state = "dying";
      endT = 1.25;
      P.deadT = 0;
      spray(P.x, P.y + 1.1, P.z, 0, 24);
    }
  }

  function beginSwing() {
    let bestYaw: number | null = null;
    let bd = 4.3;
    for (const e of enemies) {
      if (!e.alive || e.dormant) continue;
      const dx = e.x - P.x;
      const dz = e.z - P.z;
      const d = Math.hypot(dx, dz);
      const ty = Math.atan2(-dx, -dz);
      if (d < bd && angDiff(P.yaw, ty) < 1.2) {
        bd = d;
        bestYaw = ty;
      }
    }
    if (bestYaw !== null) P.yaw = bestYaw;
    P.ad = P.combo === 2 ? 0.5 : 0.4;
    P.attack = P.ad;
    P.didHit = false;
    P.buf = 0;
    const lunge = P.combo === 2 ? 7.2 : 4.6;
    P.kx += -Math.sin(P.yaw) * lunge;
    P.kz += -Math.cos(P.yaw) * lunge;
    slash.position.set(P.x - Math.sin(P.yaw) * 0.7, P.y + 1.15, P.z - Math.cos(P.yaw) * 0.7);
    slash.rotation.set(0.9, P.yaw + Math.PI, P.combo === 1 ? 0.6 : -0.4);
    slashOp = 0.85;
    sfx(P.combo === 2 ? 540 : 860, 0.12, "sawtooth", 0.035);
  }

  function tryAttack() {
    if (P.hp <= 0 || P.dodge > 0) return;
    if (P.attack > 0) {
      if (P.attack < P.ad * 0.58) P.buf = 0.28;
      return;
    }
    if (P.comboWindow > 0) P.combo = (P.combo + 1) % 3;
    else P.combo = 0;
    beginSwing();
  }

  function releaseKunai() {
    const fan = P.charge > 0.32 && P.ammo >= 3;
    const angles = fan ? [-0.16, 0, 0.16] : [0];
    for (const a of angles) {
      if (P.ammo <= 0) break;
      P.ammo--;
      const yaw = P.yaw + a;
      const fx = -Math.sin(yaw);
      const fz = -Math.cos(yaw);
      const rx = Math.cos(P.yaw);
      const rz = -Math.sin(P.yaw);
      let slot = kunai.find((k) => !k.active);
      if (!slot) slot = kunai[0]!;
      slot.active = true;
      slot.stuck = false;
      slot.life = 1.45;
      slot.spin = 0;
      slot.x = P.x + fx * 0.55 + rx * 0.25;
      slot.y = P.y + 1.42;
      slot.z = P.z + fz * 0.55 + rz * 0.25;
      slot.vx = fx * 36;
      slot.vz = fz * 36;
      slot.vy = 1.5;
      slot.mesh.visible = true;
    }
    P.kcd = fan ? 0.48 : 0.16;
    P.throwT = 1;
    sfx(fan ? 880 : 1480, 0.08, "sine", 0.04);
  }

  function updKunai(dt: number) {
    for (const k of kunai) {
      if (!k.active) {
        k.mesh.visible = false;
        continue;
      }
      if (k.stuck) {
        k.life -= dt;
        k.mesh.visible = k.life > 0;
        if (k.life <= 0) k.active = false;
        continue;
      }
      k.life -= dt;
      k.vy -= 7 * dt;
      const nx = k.x + k.vx * dt;
      const ny = k.y + k.vy * dt;
      const nz = k.z + k.vz * dt;
      let hit = pointInTall(nx, nz) || ny <= world.gh(nx, nz) + 0.06 || k.life <= 0;
      if (!hit) {
        for (const e of enemies) {
          if (!e.alive || e.dormant) continue;
          const d = Math.hypot(e.x - nx, e.z - nz);
          const gy = world.gh(e.x, e.z);
          if (d < e.r + 0.32 && Math.abs(ny - (gy + 1.05)) < 1.2) {
            const len = Math.hypot(k.vx, k.vz) || 1;
            hurtEnemy(e, 24, (k.vx / len) * 3.2, (k.vz / len) * 3.2, false);
            hit = true;
            break;
          }
        }
      }
      k.x = nx;
      k.y = ny;
      k.z = nz;
      k.spin += dt * 24;
      k.mesh.position.set(k.x, k.y, k.z);
      if (hit) {
        k.stuck = true;
        k.life = 7;
        k.vx = 0;
        k.vy = 0;
        k.vz = 0;
        k.mesh.position.y = Math.max(k.y, world.gh(k.x, k.z) + 0.08);
      } else {
        k.mesh.lookAt(k.x + k.vx, k.y + k.vy, k.z + k.vz);
        k.mesh.rotateZ(k.spin);
      }
      k.mesh.visible = true;
    }
  }

  function updEnemy(e: Enemy, dt: number) {
    const st = STATS[e.kind];
    if (e.hurt > 0) e.hurt -= dt;
    if (e.slamCd > 0) e.slamCd -= dt;
    e.kx *= Math.exp(-7 * dt);
    e.kz *= Math.exp(-7 * dt);
    if (e.dormant) {
      if (doorOpen && P.z < -23) e.dormant = false;
      else {
        e.x += e.kx * dt;
        e.z += e.kz * dt;
        slide(e, 0, 0, e.r);
        return;
      }
    }
    const dx = P.x - e.x;
    const dz = P.z - e.z;
    const dist = Math.hypot(dx, dz) || 0.0001;
    const see = dist < st.aggro && los(e.x, e.z, P.x, P.z);
    if ((see || e.alert) && e.state === "idle") e.state = "chase";

    let mx = 0;
    let mz = 0;
    let moving = false;
    if (e.state === "idle" && e.patrol) {
      const p = e.patrol[e.pi]!;
      mx = p[0] - e.x;
      mz = p[1] - e.z;
      if (Math.hypot(mx, mz) < 1.3) e.pi = (e.pi + 1) % e.patrol.length;
      moving = true;
    } else if (e.state === "chase") {
      mx = dx;
      mz = dz;
      for (const o of enemies) {
        if (o === e || !o.alive) continue;
        const sx = e.x - o.x;
        const sz = e.z - o.z;
        const sd = Math.hypot(sx, sz);
        if (sd < 1.25 && sd > 0.02) {
          mx += (sx / sd) * 1.4;
          mz += (sz / sd) * 1.4;
        }
      }
      moving = true;
      if (dist < st.range) {
        e.state = "wind";
        e.st = st.wind;
        moving = false;
      } else if (e.kind === "boss" && e.hp < e.max * 0.5 && e.slamCd <= 0 && dist < 6.5) {
        e.state = "slam";
        e.st = 0.72;
        e.slamCd = 5.4;
        moving = false;
      }
    } else if (e.state === "wind" || e.state === "slam") {
      const face = Math.atan2(-dx, -dz);
      e.yaw = lerpAng(e.yaw, face, 1 - Math.exp(-10 * dt));
      e.st -= dt;
      if (e.st <= 0) {
        if (e.state === "slam") {
          if (dist < 3.6) hurtPlayer(14, (dx / dist) * 8, (dz / dist) * 8);
          shake = Math.max(shake, 0.28);
          sfx(70, 0.2, "square", 0.08);
        } else if (dist < st.range + 0.55 && angDiff(e.yaw, Math.atan2(-dx, -dz)) < 1.05) {
          const fx = -Math.sin(e.yaw);
          const fz = -Math.cos(e.yaw);
          hurtPlayer(st.dmg, fx * 7, fz * 7);
        }
        e.state = "recover";
        e.st = e.kind === "boss" ? 0.5 : 0.38;
      }
    } else if (e.state === "recover") {
      e.st -= dt;
      if (e.st <= 0) e.state = e.alert || see ? "chase" : "idle";
    }

    if (moving) {
      const len = Math.hypot(mx, mz) || 1;
      const desired = Math.atan2(-mx / len, -mz / len);
      e.yaw = lerpAng(e.yaw, desired, 1 - Math.exp(-8 * dt));
      const sp = e.state === "idle" ? st.speed * 0.55 : st.speed;
      const fx = -Math.sin(e.yaw);
      const fz = -Math.cos(e.yaw);
      slide(e, fx * sp * dt + e.kx * dt, fz * sp * dt + e.kz * dt, e.r);
      e.kx = 0;
      e.kz = 0;
    } else {
      slide(e, e.kx * dt, e.kz * dt, e.r);
    }
  }

  function objectiveText() {
    if (cleared < 4) return `طهّر معسكرات الخونة (${cleared}/4)`;
    if (!doorOpen) {
      const left = enemies.filter((e) => e.alive && e.palace && !e.dormant).length;
      return `اقتحم القصر — الحراس المتبقون ${left}`;
    }
    return "اقتل اللورد على العرش";
  }

  function objectivePoint() {
    if (cleared < 4) {
      let best = world.camps[0]!;
      let bd = 1e9;
      for (const c of world.camps) {
        if (c.done) continue;
        const d = Math.hypot(c.x - P.x, c.z - P.z);
        if (d < bd) {
          bd = d;
          best = c;
        }
      }
      if (!best.done) return best;
    }
    if (!doorOpen) return { x: 0, z: 18 };
    const boss = enemies.find((e) => e.kind === "boss" && e.alive);
    return boss ? { x: boss.x, z: boss.z } : { x: 0, z: -36 };
  }

  function reset() {
    for (const e of enemies) if (e.rig) destroyRig(e.rig, scene);
    for (const c of corpses) destroyRig(c.rig, scene);
    corpses.length = 0;
    for (const k of kunai) {
      k.active = false;
      k.mesh.visible = false;
    }
    clearBlood();
    doorOpen = false;
    doorT = 0;
    world.doorL.rotation.y = 0;
    world.doorR.rotation.y = 0;
    walls = shutWalls;
    for (const c of world.camps) c.done = false;
    cleared = 0;
    kills = 0;
    enemies = world.spawns.map(makeEnemy);
    P.x = 0;
    P.z = 132;
    P.y = world.gh(0, 132);
    P.yaw = 0;
    P.vx = 0;
    P.vz = 0;
    P.vy = 0;
    P.kx = 0;
    P.kz = 0;
    P.hp = 100;
    P.speed = 0;
    P.attack = 0;
    P.combo = 0;
    P.buf = 0;
    P.comboWindow = 0;
    P.didHit = false;
    P.inv = 0;
    P.hurt = 0;
    P.dodge = 0;
    P.dodgeCd = 0;
    P.grounded = true;
    P.coyote = 0.12;
    P.jumpBuf = 0;
    P.ammo = 8;
    P.regen = 0;
    P.charge = 0;
    P.charging = false;
    P.kcd = 0;
    P.throwT = 0;
    P.deadT = 0;
    camYaw = 0;
    camPitch = 0.42;
    shake = 0;
    hitstop = 0;
    endT = 0;
    slashOp = 0;
    ui.boss.classList.remove("on");
  }

  function sim(dt: number, edges: boolean) {
    if (state === "dying" || state === "winning") {
      endT -= dt;
      if (state === "dying") P.deadT += dt;
      if (endT <= 0) {
        if (state === "dying") {
          state = "dead";
          showOver("سقطت يا ساموراي", "حرس القصر غلبوك هذه المرة. ارفع السيف وحاول من جديد.", "حاول مرة أخرى");
        } else {
          state = "won";
          showOver(
            "العدالة تحققت",
            "سقط اللورد الخائن على عرشه. غسلت الكاتانا والخناجر ما خانه من شرف.",
            "العب مرة أخرى",
          );
        }
      }
      return;
    }
    if (state !== "play") return;

    if (edges && attackEdge) tryAttack();
    if (edges) attackEdge = false;
    if (edges && dodgeEdge && P.dodgeCd <= 0 && P.dodge <= 0 && P.hp > 0) {
      const mag = Math.hypot(inX, inZ);
      let dx: number;
      let dz: number;
      if (mag > 0.2) {
        const fx = -Math.sin(camYaw);
        const fz = -Math.cos(camYaw);
        const rx = Math.cos(camYaw);
        const rz = -Math.sin(camYaw);
        dx = fx * (inZ / mag) + rx * (inX / mag);
        dz = fz * (inZ / mag) + rz * (inX / mag);
      } else {
        dx = -Math.sin(P.yaw);
        dz = -Math.cos(P.yaw);
      }
      const l = Math.hypot(dx, dz) || 1;
      P.dvx = (dx / l) * 15;
      P.dvz = (dz / l) * 15;
      P.dodge = 0.26;
      P.dodgeCd = 0.72;
      P.inv = Math.max(P.inv, 0.32);
      P.dodgeSide = dx >= 0 ? 1 : -1;
      P.attack = 0;
      slashOp = 0;
      sfx(280, 0.12, "triangle", 0.04);
    }
    if (edges) dodgeEdge = false;
    if (edges && jumpEdge) P.jumpBuf = 0.14;
    if (edges) jumpEdge = false;

    if (P.dodge > 0) P.dodge -= dt;
    if (P.dodgeCd > 0) P.dodgeCd -= dt;
    if (P.inv > 0) P.inv -= dt;
    if (P.hurt > 0) P.hurt -= dt;
    if (P.kcd > 0) P.kcd -= dt;
    if (P.throwT > 0) P.throwT = Math.max(0, P.throwT - dt * 3.4);
    if (P.jumpBuf > 0) P.jumpBuf -= dt;
    P.regen += dt;
    if (P.regen >= 1.35 && P.ammo < P.maxAmmo) {
      P.ammo++;
      P.regen = 0;
    }

    if (queuedKunai && !kunaiHeld) {
      queuedKunai = false;
      if (P.kcd <= 0 && P.ammo > 0 && P.attack <= 0 && P.dodge <= 0 && P.hp > 0) {
        P.charge = 0.02;
        P.charging = true;
        releaseKunai();
        P.charging = false;
        P.charge = 0;
      }
    } else if (kunaiHeld && P.kcd <= 0 && P.ammo > 0 && P.attack <= 0 && P.dodge <= 0 && P.hp > 0) {
      P.charge = Math.min(0.48, P.charge + dt);
      P.charging = true;
    } else if (P.charging) {
      releaseKunai();
      P.charging = false;
      P.charge = 0;
    }

    const mag = Math.min(1, Math.hypot(inX, inZ));
    let ix = inX;
    let iz = inZ;
    const il = Math.hypot(ix, iz);
    if (il > 1) {
      ix /= il;
      iz /= il;
    }
    const water = world.gh(P.x, P.z) < -0.75 ? 0.68 : 1;
    if (P.dodge > 0) {
      slide(P, P.dvx * dt, P.dvz * dt, P.r);
      P.vx = P.dvx;
      P.vz = P.dvz;
      P.yaw = lerpAng(P.yaw, Math.atan2(-P.dvx, -P.dvz), 1 - Math.exp(-18 * dt));
    } else if (il > 0.05 && P.hp > 0) {
      const fx = -Math.sin(camYaw);
      const fz = -Math.cos(camYaw);
      const rx = Math.cos(camYaw);
      const rz = -Math.sin(camYaw);
      const wx = fx * iz + rx * ix;
      const wz = fz * iz + rz * ix;
      const wl = Math.hypot(wx, wz) || 1;
      const speed = (3.35 + 4.05 * mag) * water * (P.attack > 0 ? 0.45 : 1);
      P.yaw = lerpAng(P.yaw, Math.atan2(-wx, -wz), 1 - Math.exp(-14 * dt));
      P.vx = (wx / wl) * speed + P.kx;
      P.vz = (wz / wl) * speed + P.kz;
      slide(P, P.vx * dt, P.vz * dt, P.r);
    } else {
      P.vx = P.kx;
      P.vz = P.kz;
      slide(P, P.vx * dt, P.vz * dt, P.r);
    }
    P.kx *= Math.exp(-8 * dt);
    P.kz *= Math.exp(-8 * dt);
    P.speed = Math.hypot(P.vx, P.vz);

    for (const e of enemies) {
      if (!e.alive) continue;
      const dx = P.x - e.x;
      const dz = P.z - e.z;
      const d = Math.hypot(dx, dz);
      const min = P.r + e.r * 0.85;
      if (d < min && d > 0.02 && !e.dormant) {
        P.x = e.x + (dx / d) * min;
        P.z = e.z + (dz / d) * min;
      }
    }
    collide(P, P.r);

    if (P.jumpBuf > 0 && P.dodge <= 0 && (P.grounded || P.coyote > 0)) {
      P.vy = 7.5;
      P.grounded = false;
      P.coyote = 0;
      P.jumpBuf = 0;
      sfx(420, 0.08, "triangle", 0.03);
    }
    P.vy -= 22 * dt;
    P.y += P.vy * dt;
    const g = world.gh(P.x, P.z);
    if (P.y <= g) {
      P.y = g;
      if (P.vy < 0) P.vy = 0;
      P.grounded = true;
      P.coyote = 0.12;
    } else {
      P.grounded = false;
      P.coyote -= dt;
    }

    if (P.attack > 0) {
      const u = 1 - P.attack / P.ad;
      if (!P.didHit && u > 0.32 && u < 0.72) {
        P.didHit = true;
        const reach = P.combo === 2 ? 2.75 : 2.2;
        const half = P.combo === 2 ? 1.25 : 1.02;
        const dmg = P.combo === 2 ? 68 : 38;
        const fx = -Math.sin(P.yaw);
        const fz = -Math.cos(P.yaw);
        let any = false;
        for (const e of enemies) {
          if (!e.alive || e.dormant) continue;
          const dx = e.x - P.x;
          const dz = e.z - P.z;
          const d = Math.hypot(dx, dz);
          if (d > reach + e.r) continue;
          if (angDiff(P.yaw, Math.atan2(-dx, -dz)) > half) continue;
          const f = (P.combo === 2 ? 8 : 5.2) * (e.kind === "boss" ? 1 : 1);
          hurtEnemy(e, dmg, fx * f, fz * f, true);
          any = true;
        }
        if (any) {
          shake = Math.max(shake, P.combo === 2 ? 0.2 : 0.11);
          hitstop = reduce ? 0 : 0.045;
        }
      }
      P.attack -= dt;
      if (P.attack <= 0) {
        if (P.buf > 0) {
          P.buf = 0;
          P.combo = (P.combo + 1) % 3;
          beginSwing();
        } else P.comboWindow = 0.46;
      }
    } else if (P.comboWindow > 0) {
      P.comboWindow -= dt;
      if (P.comboWindow <= 0) P.combo = 0;
    }
    if (P.buf > 0) P.buf -= dt;

    for (const e of enemies) if (e.alive) updEnemy(e, dt);
    updKunai(dt);
    updDrops(dt);

    if (doorOpen && doorT < 1) {
      doorT = Math.min(1, doorT + dt * 0.85);
      world.doorL.rotation.y = doorT * 1.5;
      world.doorR.rotation.y = -doorT * 1.5;
    }
    shake = Math.max(0, shake - dt * (reduce ? 3 : 1.5));
  }

  function aimLights() {
    const ranked: { d: number; i: number }[] = [];
    for (let i = 0; i < world.spots.length; i++) {
      const s = world.spots[i]!;
      const d = (s.x - P.x) ** 2 + (s.z - P.z) ** 2;
      if (ranked.length < 5) ranked.push({ d, i });
      else {
        let w = 0;
        for (let k = 1; k < ranked.length; k++) if (ranked[k]!.d > ranked[w]!.d) w = k;
        if (d < ranked[w]!.d) ranked[w] = { d, i };
      }
    }
    for (let i = 0; i < points.length; i++) {
      const slot = ranked[i];
      const light = points[i]!;
      if (!slot) {
        light.intensity = 0;
        continue;
      }
      const s = world.spots[slot.i]!;
      light.position.set(s.x, s.y + 0.2, s.z);
      light.intensity = s.fire ? 20 : 9;
      light.distance = s.fire ? 16 : 11;
    }
    moon.position.set(P.x + 26, 46, P.z + 14);
    moon.target.position.set(P.x, P.y, P.z);
    moon.target.updateMatrixWorld();
  }

  function drawMap() {
    const ctx = ui.map.getContext("2d");
    if (!ctx) return;
    const S = 120 / 400;
    const px = (x: number) => (x + 200) * S;
    const pz = (z: number) => (z + 200) * S;
    ctx.clearRect(0, 0, 120, 120);
    ctx.fillStyle = "rgba(8,4,10,.55)";
    ctx.fillRect(0, 0, 120, 120);
    ctx.strokeStyle = "rgba(216,180,90,.7)";
    ctx.strokeRect(0.5, 0.5, 119, 119);
    ctx.strokeStyle = "#2f6d86";
    ctx.lineWidth = 2;
    ctx.beginPath();
    for (let z = -190; z <= 190; z += 12) {
      const x = -78 + 18 * Math.sin(z * 0.02);
      if (z === -190) ctx.moveTo(px(x), pz(z));
      else ctx.lineTo(px(x), pz(z));
    }
    ctx.stroke();
    ctx.fillStyle = "#d8b45a";
    ctx.fillRect(px(-18), pz(-42), 36 * S, 68 * S);
    ctx.fillStyle = "#5aa0d0";
    ctx.beginPath();
    ctx.arc(px(0), pz(140), 3.5, 0, Math.PI * 2);
    ctx.fill();
    for (const c of world.camps) {
      ctx.fillStyle = c.done ? "#3f9a5a" : "#d12a3a";
      ctx.beginPath();
      ctx.arc(px(c.x), pz(c.z), 3.2, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.save();
    ctx.translate(px(P.x), pz(P.z));
    ctx.rotate(-P.yaw);
    ctx.fillStyle = "#fff8ee";
    ctx.beginPath();
    ctx.moveTo(0, -6);
    ctx.lineTo(4, 4);
    ctx.lineTo(-4, 4);
    ctx.fill();
    ctx.restore();
  }

  function hud() {
    ui.hp.style.width = `${clamp(P.hp, 0, 100)}%`;
    ui.obj.textContent = `الخونة: ${kills} — ${objectiveText()}`;
    ui.ammo.textContent = `خناجر ${P.ammo}/${P.maxAmmo}`;
    ui.charge.style.width = `${clamp((P.charge / 0.32) * 100, 0, 100)}%`;
    const o = objectivePoint();
    const ty = Math.atan2(-(o.x - P.x), -(o.z - P.z));
    const rel = Math.atan2(Math.sin(ty - camYaw), Math.cos(ty - camYaw));
    ui.arr.style.transform = `rotate(${-rel}rad)`;
    ui.dist.textContent = `${Math.round(Math.hypot(o.x - P.x, o.z - P.z))} م`;
    const boss = enemies.find((e) => e.kind === "boss" && e.alive && !e.dormant);
    ui.boss.classList.toggle("on", Boolean(boss) && (state === "play" || state === "winning"));
    if (boss) ui.bossHp.style.width = `${clamp((boss.hp / boss.max) * 100, 0, 100)}%`;
    if (mfc % 6 === 0) drawMap();
  }

  function ensureRigs() {
    for (const e of enemies) {
      if (!e.alive) continue;
      const d = Math.hypot(e.x - P.x, e.z - P.z);
      if (!e.rig && (d < 50 || e.kind === "boss")) {
        if (e.kind === "boss" && d > 55 && e.dormant) continue;
        e.rig = buildRig(e.kind, tex, scene);
      }
      if (e.rig && d > 80 && e.state === "idle" && e.kind !== "boss") {
        destroyRig(e.rig, scene);
        e.rig = null;
      }
    }
  }

  function animOf(e: Enemy): Anim {
    const st = STATS[e.kind];
    const winding = e.state === "wind" || e.state === "slam";
    return {
      speed: e.state === "chase" ? st.speed : e.state === "idle" && e.patrol ? 1.8 : 0,
      attack: winding ? Math.max(0.01, e.st) : 0,
      attackDur: e.state === "slam" ? 0.72 : st.wind,
      combo: e.kind === "boss" ? 2 : 0,
      throwing: 0,
      dodge: 0,
      dodgeSide: 1,
      hurt: e.hurt,
      time,
      dead: 0,
    };
  }

  function render(dt: number) {
    time += dt;
    if (state === "menu") camYaw += dt * 0.15;
    for (const f of world.flames) {
      const s = 0.82 + Math.sin(time * 10 + f.position.x) * 0.18;
      f.scale.set(1, s, 1);
    }
    world.waterMap.offset.y = time * 0.025;
    const wb = bumpOf(world.waterMap);
    if (wb) wb.offset.y = time * 0.025;
    const pet = world.petals.geometry.getAttribute("position") as THREE.BufferAttribute;
    for (let i = 0; i < pet.count; i++) {
      let x = pet.getX(i) + Math.sin(time * 0.6 + i) * dt * 0.35;
      let y = pet.getY(i) - dt * (0.28 + (i % 5) * 0.04);
      let z = pet.getZ(i) + dt * 0.22;
      if (y < 0.1) y = 4.5 + (i % 4);
      if (x > 18) x = -18;
      if (x < -18) x = 18;
      if (z > 18) z = -18;
      pet.setXYZ(i, x, y, z);
    }
    pet.needsUpdate = true;
    world.petals.position.set(P.x, 0, P.z);

    ensureRigs();
    const pAnim: Anim = {
      speed: state === "play" ? P.speed : 0,
      attack: P.attack,
      attackDur: P.ad,
      combo: P.combo,
      throwing: P.throwT,
      dodge: P.dodge,
      dodgeSide: P.dodgeSide,
      hurt: P.hurt,
      time,
      dead: P.hp <= 0 ? Math.max(0.01, P.deadT) : 0,
    };
    poseRig(playerRig, pAnim, dt);
    playerRig.root.position.set(P.x, P.y, P.z);
    playerRig.root.rotation.y = P.yaw + Math.PI;
    playerRig.root.visible = !(P.inv > 0 && P.dodge <= 0 && P.hp > 0 && Math.sin(time * 28) < -0.15);

    for (const e of enemies) {
      if (!e.rig) continue;
      if (!e.alive) {
        e.rig.root.visible = false;
        continue;
      }
      poseRig(e.rig, animOf(e), dt);
      e.rig.root.position.set(e.x, world.gh(e.x, e.z), e.z);
      e.rig.root.rotation.y = e.yaw + Math.PI;
      e.rig.root.visible = true;
    }
    for (const c of corpses) {
      c.t += dt;
      poseRig(c.rig, { ...animOfIdle(c.t), dead: c.t }, dt);
    }

    slashMat.opacity = slashOp;
    slashOp = Math.max(0, slashOp - dt * 3.2);
    let showWarn = false;
    for (const e of enemies) {
      if (!e.alive) continue;
      if (e.state === "wind" || e.state === "slam") {
        warn.position.set(e.x, world.gh(e.x, e.z) + 0.08, e.z);
        const u = e.state === "slam" ? 1.8 : 1;
        warn.scale.setScalar(u + (1 - e.st) * 0.4);
        warnMat.opacity = 0.35 + Math.sin(time * 16) * 0.15;
        showWarn = true;
        break;
      }
    }
    warn.visible = showWarn;

    aimLights();
    const pitch = camPitch;
    const cp = Math.cos(pitch);
    const fx = -Math.sin(camYaw);
    const fz = -Math.cos(camYaw);
    let dist = 5.7;
    for (let t = 5.7; t >= 1.6; t -= 0.4) {
      const x = P.x - fx * t * cp;
      const z = P.z - fz * t * cp;
      dist = t;
      if (!pointInTall(x, z)) break;
    }
    const sh = reduce ? shake * 0.25 : shake;
    camera.position.set(
      P.x - fx * dist * cp + (Math.random() - 0.5) * sh,
      P.y + 1.5 + dist * Math.sin(pitch) + (Math.random() - 0.5) * sh * 0.5,
      P.z - fz * dist * cp + (Math.random() - 0.5) * sh,
    );
    camera.lookAt(P.x, P.y + 1.35, P.z);
    renderer.render(scene, camera);
  }

  function animOfIdle(t: number): Anim {
    return {
      speed: 0,
      attack: 0,
      attackDur: 0.4,
      combo: 0,
      throwing: 0,
      dodge: 0,
      dodgeSide: 1,
      hurt: 0,
      time: t,
      dead: 0,
    };
  }

  function deadzone(x: number, y: number) {
    const m = Math.hypot(x, y);
    if (m < 0.18) return { x: 0, y: 0 };
    const s = (m - 0.18) / 0.82 / m;
    return { x: x * s, y: y * s };
  }

  function readPad(dt: number) {
    padLookX = 0;
    padLookY = 0;
    let ix = 0;
    let iz = 0;
    let atk = false;
    let dge = false;
    let jmp = false;
    let kni = false;
    const pads = navigator.getGamepads?.();
    if (pads) {
      for (const gp of pads) {
        if (!gp || !gp.connected) continue;
        const d = deadzone(gp.axes[0] ?? 0, -(gp.axes[1] ?? 0));
        ix += d.x;
        iz += d.y;
        const rx = gp.axes[2] ?? 0;
        const ry = gp.axes[3] ?? 0;
        if (Math.hypot(rx, ry) > 0.2) {
          padLookX = rx;
          padLookY = ry;
        }
        if (gp.buttons[12]?.pressed) iz += 1;
        if (gp.buttons[13]?.pressed) iz -= 1;
        if (gp.buttons[15]?.pressed) ix += 1;
        if (gp.buttons[14]?.pressed) ix -= 1;
        atk = Boolean(gp.buttons[0]?.pressed);
        dge = Boolean(gp.buttons[1]?.pressed);
        kni = Boolean(gp.buttons[2]?.pressed || (gp.buttons[7]?.value ?? 0) > 0.45);
        jmp = Boolean(gp.buttons[3]?.pressed);
        break;
      }
    }
    return { ix, iz, atk, dge, jmp, kni, dt };
  }

  function updateHeld(dt: number) {
    const pad = readPad(dt);
    let ix = pad.ix;
    let iz = pad.iz;
    if (keys.has("KeyW")) iz += 1;
    if (keys.has("KeyS")) iz -= 1;
    if (keys.has("KeyD")) ix += 1;
    if (keys.has("KeyA")) ix -= 1;
    ix += joyX;
    iz += joyY;
    inX = ix;
    inZ = iz;
    const atkDown = keys.has("Space") || atkBtn || pad.atk;
    if (atkDown && !prevAtk) attackEdge = true;
    prevAtk = atkDown;
    const dgeDown = keys.has("ShiftLeft") || keys.has("ShiftRight") || dgeBtn || pad.dge;
    if (dgeDown && !prevDge) dodgeEdge = true;
    prevDge = dgeDown;
    const jmpDown = keys.has("KeyC") || jmpBtn || pad.jmp;
    if (jmpDown && !prevJmp) jumpEdge = true;
    prevJmp = jmpDown;
    kunaiHeld = keys.has("KeyF") || kniBtn || pad.kni;
    if (keys.has("ArrowLeft")) camYaw += 1.8 * dt;
    if (keys.has("ArrowRight")) camYaw -= 1.8 * dt;
    if (keys.has("ArrowUp")) camPitch = clamp(camPitch - dt * 0.9, 0.2, 1.05);
    if (keys.has("ArrowDown")) camPitch = clamp(camPitch + dt * 0.9, 0.2, 1.05);
    if (padLookX) camYaw -= padLookX * 1.7 * dt;
    if (padLookY) camPitch = clamp(camPitch + padLookY * 1.05 * dt, 0.2, 1.05);
  }

  function frame(now: number) {
    timer.update(now);
    const dt = Math.min(timer.getDelta(), 0.05);
    updateHeld(dt);
    if (msgT > 0) {
      msgT -= dt;
      if (msgT <= 0) ui.msg.classList.remove("on");
    }
    if (hitstop > 0 && state === "play") {
      hitstop -= dt;
    } else {
      accHold.v += dt;
      let first = true;
      let guard = 0;
      while (accHold.v >= STEP && guard < 5) {
        sim(STEP, first);
        first = false;
        accHold.v -= STEP;
        guard++;
      }
    }
    mfc++;
    hud();
    render(dt);
    raf = requestAnimationFrame(frame);
  }

  function resize() {
    const w = ui.canvas.clientWidth || window.innerWidth || 1;
    const h = ui.canvas.clientHeight || window.innerHeight || 1;
    camera.aspect = w / Math.max(1, h);
    camera.updateProjectionMatrix();
    renderer.setSize(w, h, false);
  }

  const ac = new AbortController();
  const signal = ac.signal;
  window.addEventListener(
    "keydown",
    (e) => {
      keys.add(e.code);
      if (GAME_KEYS.has(e.code)) e.preventDefault();
    },
    { signal },
  );
  window.addEventListener(
    "keyup",
    (e) => {
      keys.delete(e.code);
      if (e.code === "KeyF" && P.charge <= 0 && !P.charging) queuedKunai = true;
    },
    { signal },
  );
  window.addEventListener(
    "blur",
    () => {
      keys.clear();
      joyX = 0;
      joyY = 0;
      atkBtn = false;
      dgeBtn = false;
      jmpBtn = false;
      kniBtn = false;
    },
    { signal },
  );
  document.addEventListener(
    "visibilitychange",
    () => {
      if (document.hidden) keys.clear();
    },
    { signal },
  );
  window.addEventListener("resize", resize, { signal });
  ui.canvas.addEventListener("contextmenu", (e) => e.preventDefault(), { signal });

  let joyId: number | null = null;
  let joyOx = 0;
  let joyOy = 0;
  let lookId: number | null = null;
  let lookX = 0;
  let lookY = 0;

  ui.zone.addEventListener(
    "pointerdown",
    (e) => {
      e.preventDefault();
      joyId = e.pointerId;
      joyOx = e.clientX;
      joyOy = e.clientY;
      ui.ring.style.left = `${e.clientX}px`;
      ui.ring.style.top = `${e.clientY}px`;
      ui.ring.classList.add("on");
      ui.zone.setPointerCapture(e.pointerId);
    },
    { signal, passive: false },
  );
  ui.look.addEventListener(
    "pointerdown",
    (e) => {
      if (state !== "play") return;
      lookId = e.pointerId;
      lookX = e.clientX;
      lookY = e.clientY;
    },
    { signal },
  );
  ui.canvas.addEventListener(
    "pointerdown",
    (e) => {
      if (e.pointerType === "touch" || state !== "play") return;
      if (e.button !== 0 && e.button !== 2) return;
      lookId = e.pointerId;
      lookX = e.clientX;
      lookY = e.clientY;
    },
    { signal },
  );
  window.addEventListener(
    "pointermove",
    (e) => {
      if (e.pointerId === joyId) {
        let dx = e.clientX - joyOx;
        let dy = e.clientY - joyOy;
        const max = 50;
        const m = Math.hypot(dx, dy) || 1;
        const c = Math.min(1, max / m);
        ui.knob.style.transform = `translate(${dx * c}px, ${dy * c}px)`;
        const dm = Math.min(1, m / max);
        if (dm < 0.14) {
          joyX = 0;
          joyY = 0;
        } else {
          const s = (dm - 0.14) / 0.86;
          joyX = (dx / m) * s;
          joyY = -(dy / m) * s;
        }
      }
      if (e.pointerId === lookId) {
        const dx = e.clientX - lookX;
        const dy = e.clientY - lookY;
        lookX = e.clientX;
        lookY = e.clientY;
        camYaw -= dx * 0.0055;
        camPitch = clamp(camPitch + dy * 0.0038, 0.2, 1.05);
      }
    },
    { signal },
  );
  const endPtr = (e: PointerEvent) => {
    if (e.pointerId === joyId) {
      joyId = null;
      joyX = 0;
      joyY = 0;
      ui.ring.classList.remove("on");
      ui.knob.style.transform = "translate(0px, 0px)";
    }
    if (e.pointerId === lookId) lookId = null;
  };
  window.addEventListener("pointerup", endPtr, { signal });
  window.addEventListener("pointercancel", endPtr, { signal });

  const bindHold = (el: HTMLElement, set: (v: boolean) => void) => {
    el.addEventListener(
      "pointerdown",
      (e) => {
        e.preventDefault();
        e.stopPropagation();
        set(true);
      },
      { signal, passive: false },
    );
    const up = () => set(false);
    el.addEventListener("pointerup", up, { signal });
    el.addEventListener("pointercancel", up, { signal });
  };
  bindHold(ui.atk, (v) => {
    atkBtn = v;
    if (v) attackEdge = true;
  });
  bindHold(ui.dge, (v) => {
    dgeBtn = v;
    if (v) dodgeEdge = true;
  });
  bindHold(ui.jmp, (v) => {
    jmpBtn = v;
    if (v) jumpEdge = true;
  });
  bindHold(ui.kni, (v) => {
    kniBtn = v;
    if (!v && P.charge <= 0 && !P.charging) queuedKunai = true;
  });

  ui.go.addEventListener(
    "click",
    () => {
      // Android browsers allow orientation locking after a user gesture,
      // usually once the game has entered fullscreen. Native APK wrappers
      // should additionally declare screenOrientation="landscape".
      const enterLandscape = async () => {
        try {
          const orientation = screen.orientation as ScreenOrientation & {
            lock?: (value: "landscape") => Promise<void>;
          };
          if (typeof orientation?.lock !== "function") return;
          if (!document.fullscreenElement && ui.root.requestFullscreen) {
            await ui.root.requestFullscreen();
          }
          await orientation.lock("landscape");
        } catch {
          // Browsers that do not support orientation locking still run the game.
        }
      };
      void enterLandscape();
      ensureAudio();
      reset();
      state = "play";
      queuedKunai = false;
      ui.ov.classList.remove("on");
    },
    { signal },
  );
  ui.root.addEventListener("pointerdown", () => ensureAudio(), { signal });

  window.__controlsTest = {
    getYaw: () => P.yaw,
    getSpeed: () => P.speed,
    setKeys: (codes: string[]) => {
      keys.clear();
      for (const c of codes) keys.add(c);
    },
  };

  reset();
  state = "menu";
  clearBlood();
  resize();
  raf = requestAnimationFrame(frame);

  return {
    stop() {
      ac.abort();
      cancelAnimationFrame(raf);
      timer.dispose();
      renderer.dispose();
      scene.environment?.dispose();
      if (window.__controlsTest) delete window.__controlsTest;
    },
  };
}
