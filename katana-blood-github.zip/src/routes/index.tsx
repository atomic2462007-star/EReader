import { createFileRoute } from "@tanstack/react-router";
import { KatanaGame } from "@/components/katana-game";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return <KatanaGame />;
}
