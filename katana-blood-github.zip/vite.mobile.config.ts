import { fileURLToPath } from "node:url";
import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import tailwindcss from "@tailwindcss/vite";

const here = (p: string) => fileURLToPath(new URL(p, import.meta.url));

// بناء ثابت (بدون خادم) للعبة فقط، يُغلَّف داخل APK عبر Capacitor.
// root = mobile حتى يخرج index.html مباشرة في dist-mobile/index.html
export default defineConfig({
  root: here("./mobile"),
  base: "./",
  publicDir: false,
  plugins: [tailwindcss(), react()],
  resolve: {
    alias: { "@": here("./src") },
  },
  build: {
    outDir: here("./dist-mobile"),
    emptyOutDir: true,
    chunkSizeWarningLimit: 2000,
  },
});
