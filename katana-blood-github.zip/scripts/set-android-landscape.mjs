import { readFileSync, writeFileSync } from "node:fs";
import { join } from "node:path";

const manifestPath = join("android", "app", "src", "main", "AndroidManifest.xml");
let manifest = readFileSync(manifestPath, "utf8");
const activityPattern = /<activity\b(?=[^>]*android:name="[^"]*MainActivity")[^>]*>/s;
const match = manifest.match(activityPattern);
if (!match) throw new Error("Could not find MainActivity in AndroidManifest.xml");
const updated = match[0].replace(/\s+android:screenOrientation="[^"]*"/, "").replace(/>$/, '\n            android:screenOrientation="landscape">');
manifest = manifest.replace(match[0], updated);
writeFileSync(manifestPath, manifest);
console.log("Android MainActivity is locked to landscape.");
