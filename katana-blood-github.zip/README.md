# دم الكاتانا — Katana Blood ⚔️

لعبة ساموراي ثلاثية الأبعاد (Three.js + React + Vite) تعمل على المتصفح وتُغلَّف كتطبيق أندرويد (APK) باستخدام Capacitor، بوضع أفقي وبدون إنترنت.

3D samurai game built with Three.js + React + Vite, packaged as an offline landscape Android APK via Capacitor.

## بناء الـ APK من GitHub (بدون كمبيوتر)
1. ارفع كل ملفات المشروع إلى مستودع GitHub (في الجذر).
2. افتح تبويب **Actions** ثم **Build Android APK** ثم **Run workflow**.
3. بعد النجاح، نزّل الـ Artifact باسم `katana-android-apk` وبداخله `app-debug.apk`.

> النسخة Debug للتجربة والتثبيت المباشر، وليست نسخة متجر موقّعة.

## تشغيل اللعبة محليًا
```bash
npm ci
npm run dev            # نسخة الويب
npm run build:mobile   # بناء ملفات الموبايل في dist-mobile
```

## بنية المشروع
- `src/game/` — محرك اللعبة (engine, rig, world, materials)
- `src/components/katana-game.tsx` — واجهة اللعبة
- `mobile/` + `vite.mobile.config.ts` — نقطة دخول البناء الثابت للـ APK
- `capacitor.config.json` — إعدادات تطبيق أندرويد (`com.atomic.katana`)
- `.github/workflows/android-apk.yml` — بناء الـ APK تلقائيًا
