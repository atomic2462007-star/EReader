package com.ereader.app

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.ui.Modifier
import androidx.compose.runtime.*
import java.io.File
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import com.ereader.app.ui.EReaderTheme
import com.ereader.app.ui.LibraryScreen
import com.ereader.app.ui.ReaderHost

class MainActivity : ComponentActivity() {
    private val vm: AppViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(Color.TRANSPARENT)
        )
        if (savedInstanceState == null) handleIntent(intent)
        setContent {
            EReaderTheme {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    val openId by vm.openBookId.collectAsState()
                    BackHandler(enabled = openId != null) { vm.openBookId.value = null }
                    val crashFile = remember { File(filesDir, "crash.txt") }
                    var crash by remember { mutableStateOf(if (crashFile.exists()) runCatching { crashFile.readText() }.getOrNull() else null) }
                    crash?.let { txt ->
                        AlertDialog(
                            onDismissRequest = { crashFile.delete(); crash = null },
                            title = { Text("حدث خطأ في الجلسة السابقة") },
                            text = { SelectionContainer { Text(txt, fontSize = androidx.compose.ui.unit.TextUnit(10f, androidx.compose.ui.unit.TextUnitType.Sp), modifier = Modifier.verticalScroll(rememberScrollState())) } },
                            confirmButton = { TextButton({ crashFile.delete(); crash = null }) { Text("إغلاق") } }
                        )
                    }
                    val id = openId
                    if (id == null) LibraryScreen(vm) else ReaderHost(vm, id)
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    private fun handleIntent(i: Intent?) {
        if (i?.action == Intent.ACTION_VIEW) {
            i.data?.let { vm.importUris(listOf(it), openFirst = true) }
        }
    }
}
