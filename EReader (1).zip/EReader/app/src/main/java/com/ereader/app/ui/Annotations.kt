package com.ereader.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ereader.app.epub.Chapter
import com.ereader.app.reader.Page

/** ألوان التظليل المتاحة (قائمة صغيرة للاختيار). */
internal val HighlightColors = listOf(
    0xFFFFD54F.toInt(), // أصفر
    0xFF81C784.toInt(), // أخضر
    0xFF64B5F6.toInt(), // أزرق
    0xFFF48FB1.toInt(), // وردي
    0xFFFFB74D.toInt()  // برتقالي
)

/** تحديد نص في فصل: id != null يعني تظليلًا محفوظًا. */
internal data class Sel(val chapter: Int, val start: Int, val end: Int, val id: Long? = null, val color: Int = 0)

/* ---------------- أدوات النص ---------------- */

internal fun isIgnorable(c: Char): Boolean =
    c in '\u064B'..'\u065F' || c in '\u0610'..'\u061A' || c == '\u0670' || c == '\u0640'

internal fun normalizeChar(c: Char): Char = when (c) {
    'أ', 'إ', 'آ', 'ٱ' -> 'ا'
    'ى' -> 'ي'
    else -> c.lowercaseChar()
}

internal fun isWordChar(c: Char): Boolean = c.isLetterOrDigit() || isIgnorable(c) || c == '\'' || c == '’'

/** موضع الحرف تحت اللمس داخل الصفحة، أو null إن لم يكن فوق نص. الإحداثيات نسبة للتخطيط. */
internal fun hitOffset(page: Page, x: Float, y: Float): Int? {
    if (y < page.top || y > page.bottom) return null
    val l = page.layout
    val line = l.getLineForVertical(y.toInt()).coerceIn(page.startLine, page.endLine - 1)
    if (x < l.getLineLeft(line) - 12f || x > l.getLineRight(line) + 12f) return null
    return l.getOffsetForHorizontal(line, x)
}

internal fun wordRange(t: CharSequence, o: Int): Pair<Int, Int>? {
    if (t.isEmpty()) return null
    var i = o.coerceIn(0, t.length - 1)
    if (!isWordChar(t[i])) {
        if (i > 0 && isWordChar(t[i - 1])) i-- else return null
    }
    var s = i
    while (s > 0 && isWordChar(t[s - 1])) s--
    var e = i + 1
    while (e < t.length && isWordChar(t[e])) e++
    return s to e
}

internal fun nextWordEnd(t: CharSequence, e: Int): Int {
    var i = e.coerceIn(0, t.length)
    while (i < t.length && !isWordChar(t[i])) i++
    while (i < t.length && isWordChar(t[i])) i++
    return i
}

internal fun prevWordStart(t: CharSequence, s: Int): Int {
    var i = s.coerceIn(0, t.length)
    while (i > 0 && !isWordChar(t[i - 1])) i--
    while (i > 0 && isWordChar(t[i - 1])) i--
    return i
}

internal fun paraStart(t: CharSequence, i: Int): Int {
    var s = i.coerceIn(0, t.length)
    while (s > 0 && t[s - 1] != '\n') s--
    return s
}

internal fun paraEnd(t: CharSequence, i: Int): Int {
    var e = i.coerceIn(0, t.length)
    while (e < t.length && t[e] != '\n') e++
    return e
}

/* ---------------- البحث داخل الكتاب ---------------- */

internal fun searchBook(pages: List<Page>, chapters: List<Chapter>, query: String): List<SearchHit> {
    val qb = StringBuilder()
    for (c in query.trim()) if (!isIgnorable(c)) qb.append(normalizeChar(c))
    val q = qb.toString()
    if (q.length < 2) return emptyList()

    val out = ArrayList<SearchHit>()
    val seen = HashSet<Int>()
    for (pg in pages) {
        if (out.size >= 200) break
        if (!seen.add(pg.chapter)) continue
        val text = pg.layout.text
        val norm = StringBuilder(text.length)
        val map = IntArray(text.length)
        var n = 0
        for (i in 0 until text.length) {
            val c = text[i]
            if (isIgnorable(c)) continue
            norm.append(normalizeChar(c))
            map[n++] = i
        }
        var from = 0
        while (out.size < 200) {
            val idx = norm.indexOf(q, from)
            if (idx < 0) break
            val s = map[idx]
            val e = map[idx + q.length - 1] + 1
            val a = maxOf(0, s - 35)
            val b = minOf(text.length, e + 45)
            val raw = text.subSequence(a, b).toString().replace('\n', ' ')
            out.add(
                SearchHit(
                    label = chapters.getOrNull(pg.chapter)?.title.orEmpty(),
                    pre = raw.substring(0, s - a), mid = raw.substring(s - a, e - a), post = raw.substring(e - a),
                    chapter = pg.chapter, start = s, end = e
                )
            )
            from = idx + q.length
        }
    }
    return out
}

/* ---------------- واجهة التظليل ---------------- */

@Composable
internal fun SelectionToolbar(
    isExisting: Boolean, currentColor: Int, note: String,
    onColor: (Int) -> Unit, onNote: () -> Unit, onCopy: () -> Unit, onDelete: () -> Unit,
    onBefore: () -> Unit, onAfter: () -> Unit, onParagraph: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier, color = Color(0xF2202020), contentColor = Color.White,
        shape = RoundedCornerShape(16.dp), shadowElevation = 6.dp
    ) {
        Column(Modifier.padding(horizontal = 10.dp, vertical = 6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            if (note.isNotBlank()) {
                Text(
                    note, fontSize = 12.sp, color = Color(0xFFBDBDBD), maxLines = 3, overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.widthIn(max = 260.dp).padding(bottom = 6.dp)
                )
            }
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                HighlightColors.forEach { c ->
                    Box(
                        Modifier.size(26.dp).clip(CircleShape).background(Color(c))
                            .then(if (c == currentColor) Modifier.border(2.dp, Color.White, CircleShape) else Modifier)
                            .clickable { onColor(c) }
                    )
                }
                Spacer(Modifier.width(2.dp))
                IconButton(onNote, Modifier.size(36.dp)) { Icon(Icons.Default.Edit, "ملاحظة", tint = Color.White) }
                IconButton(onCopy, Modifier.size(36.dp)) { Icon(Icons.Default.ContentCopy, "نسخ", tint = Color.White) }
                if (isExisting) {
                    IconButton(onDelete, Modifier.size(36.dp)) { Icon(Icons.Default.Delete, "حذف التظليل", tint = Color(0xFFEF9A9A)) }
                }
            }
            if (!isExisting) {
                Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                    TextButton(onBefore, contentPadding = PaddingValues(horizontal = 8.dp)) { Text("+ كلمة قبل", fontSize = 12.sp, color = Color(0xFFE0E0E0)) }
                    TextButton(onAfter, contentPadding = PaddingValues(horizontal = 8.dp)) { Text("+ كلمة بعد", fontSize = 12.sp, color = Color(0xFFE0E0E0)) }
                    TextButton(onParagraph, contentPadding = PaddingValues(horizontal = 8.dp)) { Text("الفقرة كاملة", fontSize = 12.sp, color = Color(0xFFE0E0E0)) }
                }
            }
        }
    }
}

@Composable
internal fun NoteDialog(initial: String, onSave: (String) -> Unit, onDismiss: () -> Unit) {
    var t by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("ملاحظة") },
        text = {
            OutlinedTextField(
                value = t, onValueChange = { t = it }, modifier = Modifier.fillMaxWidth(),
                minLines = 3, label = { Text("اكتب ملاحظتك") }
            )
        },
        confirmButton = { TextButton({ onSave(t.trim()) }) { Text("حفظ") } },
        dismissButton = { TextButton(onDismiss) { Text("إلغاء") } }
    )
}
