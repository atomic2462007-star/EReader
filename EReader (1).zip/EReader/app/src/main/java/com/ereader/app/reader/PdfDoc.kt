package com.ereader.app.reader

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import android.util.LruCache
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.Closeable
import java.io.File

/** غلاف آمن حول PdfRenderer (لا يسمح بفتح أكثر من صفحة في نفس الوقت) مع ذاكرة مؤقتة. */
class PdfDoc(file: File) : Closeable {
    private val pfd: ParcelFileDescriptor = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
    private val renderer: PdfRenderer = try { PdfRenderer(pfd) } catch (e: Exception) { pfd.close(); throw e }
    private val mutex = Mutex()
    @Volatile private var closed = false
    val pageCount: Int = renderer.pageCount

    private val cache = object : LruCache<Long, Bitmap>(
        (Runtime.getRuntime().maxMemory() / 6).toInt().coerceAtMost(96 * 1024 * 1024)
    ) {
        override fun sizeOf(key: Long, value: Bitmap): Int = value.byteCount
    }

    suspend fun render(index: Int, width: Int): Bitmap {
        val key = index.toLong() * 100000L + width
        cache.get(key)?.let { return it }
        return withContext(Dispatchers.IO) {
            mutex.withLock {
                cache.get(key)?.let { return@withLock it }
                if (closed) throw CancellationException("closed")
                val bmp = renderer.openPage(index).use { page ->
                    val scale = width.toFloat() / page.width
                    val h = (page.height * scale).toInt().coerceIn(1, 8000)
                    val b = Bitmap.createBitmap(width, h, Bitmap.Config.ARGB_8888)
                    b.eraseColor(Color.WHITE)
                    page.render(b, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                    b
                }
                cache.put(key, bmp)
                bmp
            }
        }
    }

    override fun close() {
        runBlocking {
            mutex.withLock {
                closed = true
                try { renderer.close() } catch (e: Exception) { }
                try { pfd.close() } catch (e: Exception) { }
            }
        }
        cache.evictAll()
    }
}
