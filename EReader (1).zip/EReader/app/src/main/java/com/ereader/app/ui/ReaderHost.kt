package com.ereader.app.ui

import android.app.Activity
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChanged
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.ereader.app.AppViewModel
import com.ereader.app.data.BookEntity
import com.ereader.app.data.HighlightEntity
import com.ereader.app.epub.Chapter
import com.ereader.app.epub.EpubParser
import com.ereader.app.reader.Page
import com.ereader.app.reader.Paginator
import com.ereader.app.reader.PdfDoc
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

@Composable
fun ReaderHost(vm: AppViewModel, id: Long) {
    val activity = LocalContext.current as Activity
    val view = LocalView.current
    val ui = remember { ReaderUiState() }
    val book by remember(id) { vm.observeBook(id) }.collectAsState(initial = null)

    DisposableEffect(Unit) {
        val c = WindowCompat.getInsetsController(activity.window, view)
        c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        view.keepScreenOn = true
        onDispose {
            view.keepScreenOn = false
            c.show(WindowInsetsCompat.Type.systemBars())
            setBrightness(activity, -1f)
        }
    }
    LaunchedEffect(ui.bars) {
        val c = WindowCompat.getInsetsController(activity.window, view)
        if (ui.bars) c.show(WindowInsetsCompat.Type.systemBars()) else c.hide(WindowInsetsCompat.Type.systemBars())
    }

    val b = book
    LaunchedEffect(b?.brightness) { setBrightness(activity, b?.brightness ?: -1f) }
    if (b == null) {
        Box(Modifier.fillMaxSize().background(Color.Black), Alignment.Center) { CircularProgressIndicator(color = Color.Gray) }
        return
    }
    val onBack = { vm.openBookId.value = null }
    if (b.type == "pdf") PdfReader(b, vm, ui, onBack) else EpubReader(b, vm, ui, onBack)
}

@Composable
private fun CenterMessage(text: String, onBack: () -> Unit) {
    Box(Modifier.fillMaxSize().background(Color.Black), Alignment.Center) {
        Text(text, color = Color(0xFFBDBDBD), fontSize = 15.sp, modifier = Modifier.clickable { onBack() }.padding(24.dp))
    }
}

/** -1 = يسار الشاشة، 1 = يمين الشاشة، 0 = المنتصف */
private fun tapSide(x: Float, w: Float): Int = when {
    x < w * 0.28f -> -1
    x > w * 0.72f -> 1
    else -> 0
}

/* ============================== EPUB ============================== */

@Composable
fun EpubReader(book: BookEntity, vm: AppViewModel, ui: ReaderUiState, onBack: () -> Unit) {
    val density = LocalDensity.current
    var chapters by remember(book.filePath) { mutableStateOf<List<Chapter>?>(null) }
    var error by remember(book.filePath) { mutableStateOf<String?>(null) }
    LaunchedEffect(book.filePath) {
        try {
            val ch = withContext(Dispatchers.IO) { EpubParser.readChapters(File(book.filePath)) }
            if (ch.isEmpty()) error = "لا يوجد نص قابل للعرض في هذا الكتاب" else chapters = ch
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            error = "تعذر قراءة الكتاب"
        }
    }
    // آخر موضع معروف؛ يبقى ثابتًا أثناء إعادة التقسيم إلى صفحات
    val anchor = remember { intArrayOf(book.lastChapter, book.lastOffset) }

    val light = book.pageTheme == 1
    BoxWithConstraints(Modifier.fillMaxSize().background(if (light) Color(0xFFFAFAFA) else Color.Black).displayCutoutPadding()) {
        val marginPx = with(density) { 26.dp.toPx() }
        val topPx = with(density) { 44.dp.toPx() }
        val bottomPx = with(density) { 56.dp.toPx() }
        val wPx = (constraints.maxWidth - 2 * marginPx).toInt()
        val hPx = (constraints.maxHeight - topPx - bottomPx).toInt()
        val textPx = with(density) { book.fontSizeSp.sp.toPx() }

        var pages by remember { mutableStateOf<List<Page>?>(null) }
        LaunchedEffect(chapters, wPx, hPx, book.fontSizeSp, book.fontFamily, book.lineSpacing, light) {
            val ch = chapters ?: return@LaunchedEffect
            pages = withContext(Dispatchers.Default) {
                Paginator.paginate(ch, wPx, hPx, textPx, book.fontFamily, book.lineSpacing, light)
            }
        }

        val pg = pages
        val ch = chapters
        when {
            error != null -> CenterMessage(error!!, onBack)
            pg == null || ch == null -> Column(
                Modifier.fillMaxSize(), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally
            ) {
                CircularProgressIndicator(color = Color.Gray)
                Spacer(Modifier.height(14.dp))
                Text("جارٍ تجهيز الصفحات…", color = Color(0xFF8A8A8A), fontSize = 13.sp)
            }
            pg.isEmpty() -> CenterMessage("لا يوجد نص قابل للعرض", onBack)
            else -> key(pg) { EpubPager(book, vm, ui, pg, ch, anchor, marginPx, topPx, wPx, onBack) }
        }
    }
}

@Composable
private fun EpubPager(
    book: BookEntity, vm: AppViewModel, ui: ReaderUiState, pages: List<Page>, chapters: List<Chapter>,
    anchor: IntArray, marginPx: Float, topPx: Float, wPx: Int, onBack: () -> Unit
) {
    val scope = rememberCoroutineScope()
    val pagerState = rememberPagerState(initialPage = Paginator.findPage(pages, anchor[0], anchor[1])) { pages.size }
    val bookmarks by remember(book.id) { vm.observeBookmarks(book.id) }.collectAsState(initial = emptyList())
    val highlights by remember(book.id) { vm.observeHighlights(book.id) }.collectAsState(initial = emptyList())
    val toc = remember(chapters) { chapters.mapIndexed { i, c -> TocItem(c.title, i) } }
    val light = book.pageTheme == 1
    var sel by remember { mutableStateOf<Sel?>(null) }
    var noteFor by remember { mutableStateOf<Sel?>(null) }
    var searchHit by remember { mutableStateOf<IntArray?>(null) }
    val clipboard = LocalClipboardManager.current

    BackHandler(enabled = sel != null) { sel = null }

    LaunchedEffect(pagerState) {
        snapshotFlow { pagerState.currentPage }.collect { p ->
            val pg = pages[p.coerceIn(0, pages.size - 1)]
            anchor[0] = pg.chapter
            anchor[1] = pg.startChar
            vm.savePosition(book.id, pg.chapter, pg.startChar, (p + 1f) / pages.size)
        }
    }

    val cur = pages[pagerState.currentPage.coerceIn(0, pages.size - 1)]
    val bookmarked = bookmarks.any { it.chapter == cur.chapter && it.charOffset in cur.startChar until cur.endChar }
    val rtl = book.isRtl

    fun go(delta: Int) {
        scope.launch { pagerState.animateScrollToPage((pagerState.currentPage + delta).coerceIn(0, pages.size - 1)) }
    }
    fun chapterText(ch: Int): CharSequence? = pages.firstOrNull { it.chapter == ch }?.layout?.text
    fun selText(s: Sel): String {
        val t = chapterText(s.chapter) ?: return ""
        return t.subSequence(s.start.coerceIn(0, t.length), s.end.coerceIn(0, t.length)).toString().replace('\n', ' ').trim()
    }
    fun savedOf(s: Sel): HighlightEntity? = s.id?.let { id -> highlights.firstOrNull { it.id == id } }

    CompositionLocalProvider(LocalLayoutDirection provides if (rtl) LayoutDirection.Rtl else LayoutDirection.Ltr) {
        Box(
            Modifier.fillMaxSize().pointerInput(rtl) {
                detectTapGestures(
                    onLongPress = { off ->
                        val p = pages[pagerState.currentPage.coerceIn(0, pages.size - 1)]
                        val o = hitOffset(p, off.x - marginPx, off.y - topPx + p.top)
                        if (o != null) {
                            ui.bars = false
                            searchHit = null
                            val ex = highlights.firstOrNull { it.chapter == p.chapter && o >= it.startOffset && o <= it.endOffset }
                            if (ex != null) sel = Sel(ex.chapter, ex.startOffset, ex.endOffset, ex.id, ex.color)
                            else wordRange(p.layout.text, o)?.let { r -> sel = Sel(p.chapter, r.first, r.second) }
                        }
                    },
                    onTap = { off ->
                        searchHit = null
                        if (sel != null) {
                            sel = null
                        } else {
                            val p = pages[pagerState.currentPage.coerceIn(0, pages.size - 1)]
                            val o = hitOffset(p, off.x - marginPx, off.y - topPx + p.top)
                            val ex = if (o == null) null
                            else highlights.firstOrNull { it.chapter == p.chapter && o >= it.startOffset && o <= it.endOffset }
                            if (ex != null) {
                                ui.bars = false
                                sel = Sel(ex.chapter, ex.startOffset, ex.endOffset, ex.id, ex.color)
                            } else {
                                val side = tapSide(off.x, size.width.toFloat())
                                if (side == 0) ui.bars = !ui.bars
                                else {
                                    ui.bars = false
                                    go(if ((side == 1) != rtl) 1 else -1)
                                }
                            }
                        }
                    }
                )
            }
        ) {
            HorizontalPager(state = pagerState, modifier = Modifier.fillMaxSize(), beyondViewportPageCount = 1) { i ->
                val pg = pages[i]
                EpubPageView(pg, marginPx, topPx, wPx, highlights, sel?.takeIf { it.chapter == pg.chapter }, searchHit, light)
            }
        }
    }

    ReaderOverlay(
        book = book, vm = vm, ui = ui, isPdf = false,
        pageIndex = pagerState.currentPage, pageCount = pages.size,
        topLabel = chapters.getOrNull(cur.chapter)?.title,
        toc = toc, bookmarks = bookmarks, bookmarked = bookmarked,
        onBack = onBack,
        onToggleBookmark = {
            val hit = bookmarks.filter { it.chapter == cur.chapter && it.charOffset in cur.startChar until cur.endChar }
            if (hit.isNotEmpty()) hit.forEach { vm.deleteBookmark(it.id) }
            else vm.addBookmark(book.id, cur.chapter, cur.startChar, cur.preview().ifBlank { "صفحة ${pagerState.currentPage + 1}" })
        },
        onJumpBookmark = { b -> scope.launch { pagerState.scrollToPage(Paginator.findPage(pages, b.chapter, b.charOffset)) } },
        onJumpToc = { t -> scope.launch { pagerState.scrollToPage(Paginator.findPage(pages, t.chapter, 0)) } },
        onGoToPage = { scope.launch { pagerState.scrollToPage(it.coerceIn(0, pages.size - 1)) } },
        highlights = highlights,
        onJumpHighlight = { h -> scope.launch { pagerState.scrollToPage(Paginator.findPage(pages, h.chapter, h.startOffset)) } },
        onDeleteHighlight = { h -> vm.deleteHighlight(h.id) },
        onSearch = { q -> withContext(Dispatchers.Default) { searchBook(pages, chapters, q) } },
        onJumpSearch = { h ->
            searchHit = intArrayOf(h.chapter, h.start, h.end)
            ui.bars = false
            scope.launch { pagerState.scrollToPage(Paginator.findPage(pages, h.chapter, h.start)) }
        }
    )

    val s = sel
    if (s != null) {
        val saved = savedOf(s)
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.BottomCenter) {
            SelectionToolbar(
                isExisting = s.id != null, currentColor = saved?.color ?: s.color, note = saved?.note.orEmpty(),
                onColor = { c ->
                    val id = s.id
                    if (id != null) {
                        vm.updateHighlight(id, c, saved?.note.orEmpty())
                        sel = s.copy(color = c)
                    } else {
                        vm.addHighlight(book.id, s.chapter, s.start, s.end, c, "", selText(s))
                        sel = null
                    }
                },
                onNote = { noteFor = s },
                onCopy = { clipboard.setText(AnnotatedString(selText(s))); sel = null },
                onDelete = { s.id?.let { vm.deleteHighlight(it) }; sel = null },
                onBefore = { chapterText(s.chapter)?.let { t -> sel = s.copy(start = prevWordStart(t, s.start)) } },
                onAfter = { chapterText(s.chapter)?.let { t -> sel = s.copy(end = nextWordEnd(t, s.end)) } },
                onParagraph = { chapterText(s.chapter)?.let { t -> sel = s.copy(start = paraStart(t, s.start), end = paraEnd(t, s.start)) } },
                modifier = Modifier.padding(bottom = 64.dp)
            )
        }
    }

    val nf = noteFor
    if (nf != null) {
        NoteDialog(
            initial = savedOf(nf)?.note.orEmpty(),
            onSave = { txt ->
                val id = nf.id
                if (id != null) vm.updateHighlight(id, savedOf(nf)?.color ?: nf.color, txt)
                else vm.addHighlight(book.id, nf.chapter, nf.start, nf.end, HighlightColors[0], txt, selText(nf))
                noteFor = null
                sel = null
            },
            onDismiss = { noteFor = null }
        )
    }
}

@Composable
private fun EpubPageView(
    page: Page, marginPx: Float, topPx: Float, wPx: Int,
    highlights: List<HighlightEntity>, sel: Sel?, hit: IntArray?, light: Boolean
) {
    val path = remember { android.graphics.Path() }
    val paint = remember { android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply { style = android.graphics.Paint.Style.FILL } }
    Canvas(Modifier.fillMaxSize()) {
        drawIntoCanvas { c ->
            val n = c.nativeCanvas
            n.save()
            n.translate(marginPx, topPx - page.top)
            n.clipRect(0f, page.top.toFloat(), wPx.toFloat(), page.bottom.toFloat())
            val alpha = if (light) 0x88 else 0x66
            fun fill(s: Int, e: Int, argb: Int) {
                val a = maxOf(s, page.startChar)
                val b = minOf(e, page.endChar)
                if (a >= b) return
                path.rewind()
                page.layout.getSelectionPath(a, b, path)
                paint.color = argb
                n.drawPath(path, paint)
            }
            for (h in highlights) {
                if (h.chapter == page.chapter) fill(h.startOffset, h.endOffset, (h.color and 0x00FFFFFF) or (alpha shl 24))
            }
            if (hit != null && hit[0] == page.chapter) fill(hit[1], hit[2], 0xAAFF9800.toInt())
            if (sel != null) fill(sel.start, sel.end, 0x8890CAF9.toInt())
            page.layout.draw(n)
            n.restore()
        }
    }
}

/* ============================== PDF ============================== */

private fun nightFilter(mode: Int): ColorFilter? = when (mode) {
    // قلب الألوان مع تعتيم خفيف (الأبيض يصبح أسود والنص الداكن رمادي فاتح)
    1 -> ColorFilter.colorMatrix(ColorMatrix(floatArrayOf(
        -0.86f, 0f, 0f, 0f, 219.3f,
        0f, -0.86f, 0f, 0f, 219.3f,
        0f, 0f, -0.86f, 0f, 219.3f,
        0f, 0f, 0f, 1f, 0f
    )))
    // قلب + تدوير اللون 180° ليحافظ على ألوان الصور قدر الإمكان
    2 -> ColorFilter.colorMatrix(ColorMatrix(floatArrayOf(
        0.494f, -1.230f, -0.124f, 0f, 219.3f,
        -0.366f, -0.370f, -0.124f, 0f, 219.3f,
        -0.366f, -1.230f, 0.736f, 0f, 219.3f,
        0f, 0f, 0f, 1f, 0f
    )))
    else -> null
}

@Composable
fun PdfReader(book: BookEntity, vm: AppViewModel, ui: ReaderUiState, onBack: () -> Unit) {
    val doc = remember(book.filePath) { try { PdfDoc(File(book.filePath)) } catch (e: Exception) { null } }
    DisposableEffect(doc) { onDispose { doc?.close() } }
    if (doc == null || doc.pageCount == 0) {
        CenterMessage("تعذر فتح ملف PDF (قد يكون تالفًا أو محميًا بكلمة مرور)", onBack)
        return
    }

    val scope = rememberCoroutineScope()
    val count = doc.pageCount
    val pagerState = rememberPagerState(initialPage = book.lastChapter.coerceIn(0, count - 1)) { count }
    val bookmarks by remember(book.id) { vm.observeBookmarks(book.id) }.collectAsState(initial = emptyList())
    val rtl = book.isRtl
    val filter = remember(book.pdfNight) { nightFilter(book.pdfNight) }
    val density = LocalDensity.current

    LaunchedEffect(pagerState) {
        snapshotFlow { pagerState.currentPage }.collect { p ->
            vm.savePosition(book.id, p, 0, (p + 1f) / count)
        }
    }
    val cur = pagerState.currentPage
    val bookmarked = bookmarks.any { it.chapter == cur }

    fun go(delta: Int) {
        scope.launch { pagerState.animateScrollToPage((pagerState.currentPage + delta).coerceIn(0, count - 1)) }
    }

    BoxWithConstraints(Modifier.fillMaxSize().background(Color.Black)) {
        val renderW = (constraints.maxWidth * 1.5f).toInt().coerceIn(600, 2200)
        CompositionLocalProvider(LocalLayoutDirection provides if (rtl) LayoutDirection.Rtl else LayoutDirection.Ltr) {
            HorizontalPager(state = pagerState, modifier = Modifier.fillMaxSize(), beyondViewportPageCount = 1) { i ->
                ZoomablePage(onTap = { off, size ->
                    val side = tapSide(off.x, size.width.toFloat())
                    if (side == 0) ui.bars = !ui.bars
                    else {
                        ui.bars = false
                        go(if ((side == 1) != rtl) 1 else -1)
                    }
                }) {
                    val bmp by produceState<ImageBitmap?>(null, doc, i, renderW) {
                        value = try {
                            doc.render(i, renderW).asImageBitmap()
                        } catch (e: CancellationException) {
                            throw e
                        } catch (e: Exception) {
                            null
                        }
                    }
                    val b = bmp
                    if (b != null) {
                        Image(b, null, Modifier.fillMaxSize(), contentScale = ContentScale.Fit, colorFilter = filter)
                    } else {
                        Box(Modifier.fillMaxSize(), Alignment.Center) { CircularProgressIndicator(color = Color(0xFF555555), strokeWidth = 2.dp) }
                    }
                }
            }
        }
    }

    ReaderOverlay(
        book = book, vm = vm, ui = ui, isPdf = true,
        pageIndex = cur, pageCount = count, topLabel = null,
        toc = emptyList(), bookmarks = bookmarks, bookmarked = bookmarked,
        onBack = onBack,
        onToggleBookmark = {
            val hit = bookmarks.filter { it.chapter == cur }
            if (hit.isNotEmpty()) hit.forEach { vm.deleteBookmark(it.id) }
            else vm.addBookmark(book.id, cur, 0, "صفحة ${cur + 1}")
        },
        onJumpBookmark = { b -> scope.launch { pagerState.scrollToPage(b.chapter.coerceIn(0, count - 1)) } },
        onJumpToc = {},
        onGoToPage = { scope.launch { pagerState.scrollToPage(it.coerceIn(0, count - 1)) } }
    )
}

/** صفحة قابلة للتكبير بإصبعين، والنقر مرتين للتكبير/الإرجاع. لا تعترض السحب بإصبع واحد وهي غير مكبّرة. */
@Composable
private fun ZoomablePage(onTap: (Offset, IntSize) -> Unit, content: @Composable () -> Unit) {
    var scale by remember { mutableFloatStateOf(1f) }
    var offset by remember { mutableStateOf(Offset.Zero) }
    Box(
        Modifier.fillMaxSize().clipToBounds()
            .pointerInput(Unit) {
                detectTapGestures(
                    onDoubleTap = { if (scale > 1f) { scale = 1f; offset = Offset.Zero } else scale = 2.5f },
                    onTap = { onTap(it, size) }
                )
            }
            .pointerInput(Unit) {
                awaitEachGesture {
                    awaitFirstDown(requireUnconsumed = false)
                    do {
                        val ev = awaitPointerEvent()
                        val zoom = ev.calculateZoom()
                        val pan = ev.calculatePan()
                        if (ev.changes.size > 1 || scale > 1f) {
                            val ns = (scale * zoom).coerceIn(1f, 5f)
                            scale = ns
                            val maxX = size.width * (ns - 1f) / 2f
                            val maxY = size.height * (ns - 1f) / 2f
                            offset = if (ns <= 1f) Offset.Zero
                            else Offset((offset.x + pan.x).coerceIn(-maxX, maxX), (offset.y + pan.y).coerceIn(-maxY, maxY))
                            ev.changes.forEach { if (it.positionChanged()) it.consume() }
                        }
                    } while (ev.changes.any { it.pressed })
                }
            }
    ) {
        Box(
            Modifier.fillMaxSize().graphicsLayer(scaleX = scale, scaleY = scale, translationX = offset.x, translationY = offset.y)
        ) { content() }
    }
}
