package com.ereader.app

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.ereader.app.data.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class AppViewModel(app: Application) : AndroidViewModel(app) {
    private val db = AppDatabase.get(app)
    private val repo = LibraryRepository(app, db)

    val books: StateFlow<List<BookEntity>?> =
        db.books().observeAll().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val openBookId = MutableStateFlow<Long?>(null)
    val importing = MutableStateFlow(false)
    val message = MutableSharedFlow<String>(extraBufferCapacity = 8)

    fun observeBook(id: Long): Flow<BookEntity?> = db.books().observe(id)
    fun observeBookmarks(id: Long): Flow<List<BookmarkEntity>> = db.bookmarks().observe(id)

    fun importUris(uris: List<Uri>, openFirst: Boolean = false) {
        viewModelScope.launch {
            importing.value = true
            var ok = 0
            var last: Long? = null
            for (u in uris) {
                try {
                    last = repo.import(u)
                    ok++
                } catch (e: Exception) {
                    message.tryEmit(e.message ?: "تعذر إضافة الملف")
                }
            }
            importing.value = false
            if (ok > 0 && !openFirst) message.tryEmit(if (ok == 1) "تمت إضافة الكتاب" else "تمت إضافة $ok كتب")
            if (openFirst && last != null) openBookId.value = last
        }
    }

    fun deleteBook(b: BookEntity) { viewModelScope.launch { repo.delete(b) } }

    fun savePosition(id: Long, chapter: Int, offset: Int, progress: Float) {
        viewModelScope.launch { db.books().savePosition(id, chapter, offset, progress, System.currentTimeMillis()) }
    }
    fun saveText(id: Long, size: Float, family: String, spacing: Float) {
        viewModelScope.launch { db.books().saveText(id, size, family, spacing) }
    }
    fun saveBrightness(id: Long, b: Float) { viewModelScope.launch { db.books().saveBrightness(id, b) } }
    fun savePdfNight(id: Long, m: Int) { viewModelScope.launch { db.books().savePdfNight(id, m) } }
    fun saveRtl(id: Long, rtl: Boolean) { viewModelScope.launch { db.books().saveRtl(id, rtl) } }

    fun addBookmark(bookId: Long, chapter: Int, offset: Int, label: String) {
        viewModelScope.launch {
            db.bookmarks().insert(BookmarkEntity(bookId = bookId, chapter = chapter, charOffset = offset, label = label, createdAt = System.currentTimeMillis()))
        }
    }
    fun deleteBookmark(id: Long) { viewModelScope.launch { db.bookmarks().delete(id) } }

    fun savePageTheme(id: Long, t: Int) { viewModelScope.launch { db.books().savePageTheme(id, t) } }

    fun observeHighlights(id: Long): Flow<List<HighlightEntity>> = db.highlights().observe(id)
    fun addHighlight(bookId: Long, chapter: Int, start: Int, end: Int, color: Int, note: String, text: String) {
        viewModelScope.launch {
            db.highlights().insert(HighlightEntity(bookId = bookId, chapter = chapter, startOffset = start, endOffset = end, color = color, note = note, text = text, createdAt = System.currentTimeMillis()))
        }
    }
    fun updateHighlight(id: Long, color: Int, note: String) { viewModelScope.launch { db.highlights().update(id, color, note) } }
    fun deleteHighlight(id: Long) { viewModelScope.launch { db.highlights().delete(id) } }
}
