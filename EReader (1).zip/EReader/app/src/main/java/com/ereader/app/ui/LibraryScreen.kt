package com.ereader.app.ui

import android.graphics.BitmapFactory
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Book
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ereader.app.AppViewModel
import com.ereader.app.data.BookEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.roundToInt

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LibraryScreen(vm: AppViewModel) {
    val books by vm.books.collectAsState()
    val importing by vm.importing.collectAsState()
    val snack = remember { SnackbarHostState() }
    LaunchedEffect(Unit) { vm.message.collect { snack.showSnackbar(it) } }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) vm.importUris(uris)
    }
    val mimes = arrayOf("application/pdf", "application/epub+zip", "application/octet-stream")
    var toDelete by remember { mutableStateOf<BookEntity?>(null) }

    Scaffold(
        containerColor = Color.Black,
        snackbarHost = { SnackbarHost(snack) },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { picker.launch(mimes) },
                containerColor = Color(0xFFE8E8E8),
                contentColor = Color.Black,
                icon = { Icon(Icons.Default.Add, null) },
                text = { Text("إضافة كتاب") }
            )
        }
    ) { padding ->
        Column(Modifier.padding(padding).fillMaxSize()) {
            Column(Modifier.padding(horizontal = 20.dp, vertical = 16.dp)) {
                Text("مكتبتي", fontSize = 30.sp, fontWeight = FontWeight.Bold, color = Color.White)
                val n = books?.size ?: 0
                if (n > 0) Text("$n كتاب", fontSize = 13.sp, color = Color(0xFF8A8A8A))
            }
            if (importing) LinearProgressIndicator(Modifier.fillMaxWidth(), color = Color(0xFFCCCCCC), trackColor = Color(0xFF2A2A2A))

            val list = books
            when {
                list == null -> Box(Modifier.fillMaxSize(), Alignment.Center) { CircularProgressIndicator(color = Color.Gray) }
                list.isEmpty() -> Column(
                    Modifier.fillMaxSize().padding(32.dp),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(Icons.Default.Book, null, tint = Color(0xFF444444), modifier = Modifier.size(72.dp))
                    Spacer(Modifier.height(16.dp))
                    Text("لا توجد كتب بعد", fontSize = 18.sp, color = Color(0xFFCCCCCC))
                    Spacer(Modifier.height(6.dp))
                    Text(
                        "أضف كتبك الشخصية بصيغة PDF أو EPUB من ذاكرة الهاتف",
                        fontSize = 13.sp, color = Color(0xFF8A8A8A), textAlign = TextAlign.Center
                    )
                }
                else -> LazyVerticalGrid(
                    columns = GridCells.Adaptive(150.dp),
                    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 110.dp),
                    horizontalArrangement = Arrangement.spacedBy(16.dp),
                    verticalArrangement = Arrangement.spacedBy(22.dp)
                ) {
                    items(list, key = { it.id }) { b ->
                        BookCard(b, onClick = { vm.openBookId.value = b.id }, onLongClick = { toDelete = b })
                    }
                }
            }
        }
    }

    toDelete?.let { b ->
        AlertDialog(
            onDismissRequest = { toDelete = null },
            title = { Text("حذف الكتاب") },
            text = { Text("سيُحذف «${b.title}» وعلاماته المرجعية من التطبيق. الملف الأصلي في هاتفك لن يتأثر.") },
            confirmButton = { TextButton({ vm.deleteBook(b); toDelete = null }) { Text("حذف", color = Color(0xFFFF8A80)) } },
            dismissButton = { TextButton({ toDelete = null }) { Text("إلغاء") } }
        )
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun BookCard(b: BookEntity, onClick: () -> Unit, onLongClick: () -> Unit) {
    val cover by produceState<ImageBitmap?>(null, b.coverPath) {
        value = b.coverPath?.let { p -> withContext(Dispatchers.IO) { BitmapFactory.decodeFile(p)?.asImageBitmap() } }
    }
    Column(Modifier.combinedClickable(onClick = onClick, onLongClick = onLongClick)) {
        Box(
            Modifier.fillMaxWidth().aspectRatio(2f / 3f)
                .clip(RoundedCornerShape(10.dp)).background(Color(0xFF1A1A1A))
        ) {
            val c = cover
            if (c != null) {
                Image(c, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            } else {
                Column(
                    Modifier.fillMaxSize().padding(12.dp),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(Icons.Default.Book, null, tint = Color(0xFF555555), modifier = Modifier.size(34.dp))
                    Spacer(Modifier.height(8.dp))
                    Text(b.title, color = Color(0xFFBDBDBD), fontSize = 13.sp, maxLines = 4, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center)
                }
            }
            Text(
                b.type.uppercase(), fontSize = 10.sp, color = Color.White,
                modifier = Modifier.align(Alignment.TopStart).padding(6.dp)
                    .background(Color(0xCC000000), RoundedCornerShape(4.dp)).padding(horizontal = 5.dp, vertical = 1.dp)
            )
        }
        Spacer(Modifier.height(8.dp))
        Text(b.title, fontSize = 14.sp, fontWeight = FontWeight.Medium, color = Color(0xFFE6E6E6), maxLines = 2, overflow = TextOverflow.Ellipsis)
        if (b.author.isNotBlank()) Text(b.author, fontSize = 12.sp, color = Color(0xFF8A8A8A), maxLines = 1, overflow = TextOverflow.Ellipsis)
        Spacer(Modifier.height(6.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            LinearProgressIndicator(
                progress = { b.progress.coerceIn(0f, 1f) },
                modifier = Modifier.weight(1f).height(3.dp),
                color = Color(0xFFE0E0E0), trackColor = Color(0xFF2E2E2E)
            )
            Spacer(Modifier.width(8.dp))
            Text("${(b.progress * 100).roundToInt()}%", fontSize = 11.sp, color = Color(0xFF9A9A9A))
        }
    }
}
