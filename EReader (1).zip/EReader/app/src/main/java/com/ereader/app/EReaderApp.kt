package com.ereader.app

import android.app.Application
import java.io.File

class EReaderApp : Application() {
    override fun onCreate() {
        super.onCreate()
        val prev = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            try {
                File(filesDir, "crash.txt").writeText(e.stackTraceToString().take(3500))
            } catch (_: Throwable) {}
            prev?.uncaughtException(t, e)
        }
    }
}
