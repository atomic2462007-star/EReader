package com.ereader.app.data

import android.content.Context
import androidx.room.*
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "books")
data class BookEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val author: String,
    val originalName: String,
    val sizeBytes: Long,
    val filePath: String,
    val type: String,              // "pdf" | "epub"
    val coverPath: String?,
    val isRtl: Boolean,
    val addedAt: Long,
    val lastOpenedAt: Long,
    // الموضع: EPUB => (فصل، حرف) ، PDF => lastChapter = رقم الصفحة
    val lastChapter: Int = 0,
    val lastOffset: Int = 0,
    val progress: Float = 0f,
    // إعدادات مستقلة لكل كتاب
    val fontSizeSp: Float = 20f,
    val fontFamily: String = "serif",
    val lineSpacing: Float = 1.5f,
    val brightness: Float = -1f,   // -1 = سطوع النظام
    val pdfNight: Int = 2,         // 0 عادي، 1 ليلي، 2 ليلي مع الحفاظ على الألوان
    @ColumnInfo(defaultValue = "0") val pageTheme: Int = 0   // EPUB: 0 صفحة سوداء/خط أبيض، 1 صفحة بيضاء/خط أسود
)

@Entity(
    tableName = "bookmarks",
    foreignKeys = [ForeignKey(entity = BookEntity::class, parentColumns = ["id"], childColumns = ["bookId"], onDelete = ForeignKey.CASCADE)],
    indices = [Index("bookId")]
)
data class BookmarkEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val bookId: Long,
    val chapter: Int,
    val charOffset: Int,
    val label: String,
    val createdAt: Long
)

@Entity(
    tableName = "highlights",
    foreignKeys = [ForeignKey(entity = BookEntity::class, parentColumns = ["id"], childColumns = ["bookId"], onDelete = ForeignKey.CASCADE)],
    indices = [Index("bookId")]
)
data class HighlightEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val bookId: Long,
    val chapter: Int,
    val startOffset: Int,
    val endOffset: Int,
    val color: Int,
    val note: String,
    val text: String,
    val createdAt: Long
)

@Dao
interface BookDao {
    @Query("SELECT * FROM books ORDER BY lastOpenedAt DESC")
    fun observeAll(): Flow<List<BookEntity>>

    @Query("SELECT * FROM books WHERE id = :id")
    fun observe(id: Long): Flow<BookEntity?>

    @Query("SELECT * FROM books WHERE originalName = :name AND sizeBytes = :size LIMIT 1")
    suspend fun findDuplicate(name: String, size: Long): BookEntity?

    @Insert
    suspend fun insert(b: BookEntity): Long

    @Query("DELETE FROM books WHERE id = :id")
    suspend fun delete(id: Long)

    @Query("UPDATE books SET lastChapter = :chapter, lastOffset = :offset, progress = :progress, lastOpenedAt = :now WHERE id = :id")
    suspend fun savePosition(id: Long, chapter: Int, offset: Int, progress: Float, now: Long)

    @Query("UPDATE books SET fontSizeSp = :size, fontFamily = :family, lineSpacing = :spacing WHERE id = :id")
    suspend fun saveText(id: Long, size: Float, family: String, spacing: Float)

    @Query("UPDATE books SET brightness = :b WHERE id = :id")
    suspend fun saveBrightness(id: Long, b: Float)

    @Query("UPDATE books SET pdfNight = :m WHERE id = :id")
    suspend fun savePdfNight(id: Long, m: Int)

    @Query("UPDATE books SET isRtl = :rtl WHERE id = :id")
    suspend fun saveRtl(id: Long, rtl: Boolean)

    @Query("UPDATE books SET pageTheme = :t WHERE id = :id")
    suspend fun savePageTheme(id: Long, t: Int)
}

@Dao
interface BookmarkDao {
    @Query("SELECT * FROM bookmarks WHERE bookId = :bookId ORDER BY chapter, charOffset")
    fun observe(bookId: Long): Flow<List<BookmarkEntity>>

    @Insert
    suspend fun insert(b: BookmarkEntity)

    @Query("DELETE FROM bookmarks WHERE id = :id")
    suspend fun delete(id: Long)
}

@Dao
interface HighlightDao {
    @Query("SELECT * FROM highlights WHERE bookId = :bookId ORDER BY chapter, startOffset")
    fun observe(bookId: Long): Flow<List<HighlightEntity>>

    @Insert
    suspend fun insert(h: HighlightEntity)

    @Query("UPDATE highlights SET color = :color, note = :note WHERE id = :id")
    suspend fun update(id: Long, color: Int, note: String)

    @Query("DELETE FROM highlights WHERE id = :id")
    suspend fun delete(id: Long)
}

private val MIGRATION_1_2 = object : Migration(1, 2) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("ALTER TABLE books ADD COLUMN pageTheme INTEGER NOT NULL DEFAULT 0")
        db.execSQL("CREATE TABLE IF NOT EXISTS `highlights` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `bookId` INTEGER NOT NULL, `chapter` INTEGER NOT NULL, `startOffset` INTEGER NOT NULL, `endOffset` INTEGER NOT NULL, `color` INTEGER NOT NULL, `note` TEXT NOT NULL, `text` TEXT NOT NULL, `createdAt` INTEGER NOT NULL, FOREIGN KEY(`bookId`) REFERENCES `books`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE )")
        db.execSQL("CREATE INDEX IF NOT EXISTS `index_highlights_bookId` ON `highlights` (`bookId`)")
    }
}

@Database(entities = [BookEntity::class, BookmarkEntity::class, HighlightEntity::class], version = 2, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun books(): BookDao
    abstract fun bookmarks(): BookmarkDao
    abstract fun highlights(): HighlightDao

    companion object {
        @Volatile private var inst: AppDatabase? = null
        fun get(ctx: Context): AppDatabase = inst ?: synchronized(this) {
            inst ?: Room.databaseBuilder(ctx.applicationContext, AppDatabase::class.java, "ereader.db")
                .addMigrations(MIGRATION_1_2)
                .build().also { inst = it }
        }
    }
}
