import * as THREE from "three";
import { repeat, type TexSet } from "./materials";
import type { Kind } from "./rig";

export type Wall = { x0: number; z0: number; x1: number; z1: number; tall: boolean };
export type Obs = { x: number; z: number; r: number };
export type CampSite = { x: number; z: number; done: boolean };
export type LightSpot = { x: number; y: number; z: number; fire: boolean };
export type Spawn = {
  kind: Kind;
  x: number;
  z: number;
  yaw: number;
  camp: number;
  palace: boolean;
  dormant: boolean;
  patrol: [number, number][] | null;
};

export type WorldApi = {
  walls: Wall[];
  door: Wall;
  doorL: THREE.Group;
  doorR: THREE.Group;
  grid: Map<string, Obs[]>;
  camps: CampSite[];
  spots: LightSpot[];
  flames: THREE.Object3D[];
  gh: (x: number, z: number) => number;
  petals: THREE.Points;
  waterMap: THREE.Texture;
  spawns: Spawn[];
};

const TAU = Math.PI * 2;
const clamp = (v: number, a: number, b: number) => Math.max(a, Math.min(b, v));
const ss = (outer: number, inner: number, x: number) => {
  const t = clamp((x - outer) / (inner - outer), 0, 1);
  return t * t * (3 - 2 * t);
};

export const CAMP_POS = [
  { x: -95, z: 55 },
  { x: 105, z: 15 },
  { x: -55, z: -95 },
  { x: 85, z: -110 },
];

const VIL = { x: 0, z: 140 };

function rvx(z: number) {
  return -78 + 18 * Math.sin(z * 0.02);
}
function roadX(z: number) {
  return z > 26 ? 8 * Math.sin((z - 26) * 0.045) : 0;
}

function rectDist(x: number, z: number, x0: number, z0: number, x1: number, z1: number) {
  const cx = clamp(x, x0, x1);
  const cz = clamp(z, z0, z1);
  return Math.hypot(x - cx, z - cz);
}

export function flatAt(x: number, z: number) {
  let f = ss(26, 0, rectDist(x, z, -24, -48, 24, 32));
  f = Math.max(f, ss(36, 12, Math.hypot(x - VIL.x, z - VIL.z)));
  for (const c of CAMP_POS) f = Math.max(f, ss(22, 8, Math.hypot(x - c.x, z - c.z)));
  if (z > 18 && z < 155) f = Math.max(f, ss(7, 1.4, Math.abs(x - roadX(z))));
  return f;
}

export function groundHeight(x: number, z: number) {
  const f = flatAt(x, z);
  let h =
    (3.4 * Math.sin(x * 0.031 + 1) * Math.cos(z * 0.027) +
      2.3 * Math.sin(x * 0.068) * Math.sin(z * 0.055 + 2) +
      1.15 * Math.sin(x * 0.15 + z * 0.12)) *
    (1 - f);
  const m = Math.max(Math.abs(x), Math.abs(z));
  if (m > 150) h += ((m - 150) / 36) ** 2 * 24;
  const dr = (x - rvx(z)) / 7.2;
  const w = Math.exp(-dr * dr) * (1 - f * 0.92);
  return h * (1 - w) - 2.15 * w;
}

export function buildWorld(scene: THREE.Scene, tex: TexSet, rng: () => number): WorldApi {
  const walls: Wall[] = [];
  const obs: Obs[] = [];
  const spots: LightSpot[] = [];
  const flames: THREE.Object3D[] = [];
  const camps: CampSite[] = CAMP_POS.map((c) => ({ ...c, done: false }));

  const lambert = (map: THREE.Texture, color = 0xffffff) =>
    new THREE.MeshStandardMaterial({ color, map, roughness: 0.86, metalness: 0.02 });
  const std = (color: number, rough = 0.7, metal = 0.04, map?: THREE.Texture) =>
    new THREE.MeshStandardMaterial({ color, roughness: rough, metalness: metal, map: map ?? null });

  const plasterMat = lambert(tex.plaster);
  const tileMat = lambert(tex.tile);
  const woodMat = lambert(tex.wood);
  const stoneMat = std(0x8a8478, 0.82, 0.05);
  const goldMat = std(0xd8b45a, 0.28, 0.86);
  const redMat = std(0x8a1424, 0.4, 0.35);
  const darkMat = std(0x1a1210, 0.6, 0.2);

  function mesh(
    g: THREE.BufferGeometry,
    mat: THREE.Material,
    x: number,
    y: number,
    z: number,
    cast = true,
  ) {
    const m = new THREE.Mesh(g, mat);
    m.position.set(x, y, z);
    m.castShadow = cast;
    m.receiveShadow = true;
    scene.add(m);
    return m;
  }

  function bx(x0: number, z0: number, x1: number, z1: number, y0: number, y1: number, mat: THREE.Material, cast = true) {
    const m = mesh(
      new THREE.BoxGeometry(Math.max(0.05, x1 - x0), Math.max(0.05, y1 - y0), Math.max(0.05, z1 - z0)),
      mat,
      (x0 + x1) / 2,
      (y0 + y1) / 2,
      (z0 + z1) / 2,
      cast,
    );
    return m;
  }

  function floor(x0: number, z0: number, x1: number, z1: number, y: number, map: THREE.Texture, tw: number, td: number) {
    const t = repeat(map, Math.max(0.4, (x1 - x0) / tw), Math.max(0.4, (z1 - z0) / td));
    const m = new THREE.Mesh(
      new THREE.PlaneGeometry(x1 - x0, z1 - z0),
      new THREE.MeshStandardMaterial({ map: t, roughness: 0.9, metalness: 0.02 }),
    );
    m.rotation.x = -Math.PI / 2;
    m.position.set((x0 + x1) / 2, y, (z0 + z1) / 2);
    m.receiveShadow = true;
    scene.add(m);
  }

  function wall(x0: number, z0: number, x1: number, z1: number, h: number, roof = true) {
    walls.push({ x0, z0, x1, z1, tall: h > 2.2 });
    const L = Math.max(x1 - x0, z1 - z0);
    bx(x0, z0, x1, z1, 0, h, lambert(repeat(tex.plaster, L / 3, h / 2.4)));
    if (roof) {
      bx(x0 - 0.25, z0 - 0.25, x1 + 0.25, z1 + 0.25, h, h + 0.28, lambert(repeat(tex.tile, Math.max(1, L / 2), 1)));
    }
  }

  function gable(x0: number, x1: number, z0: number, z1: number, yb: number, hr: number) {
    const d = z1 - z0;
    const w = x1 - x0;
    const sl = Math.hypot(d / 2, hr) + 1.1;
    const ang = Math.atan2(hr, d / 2);
    const mt = lambert(repeat(tex.tile, Math.max(1, w / 2), Math.max(1, sl / 2)));
    for (const s of [-1, 1]) {
      const m = new THREE.Mesh(new THREE.BoxGeometry(w + 1.4, 0.22, sl), mt);
      m.position.set((x0 + x1) / 2, yb + hr / 2, (z0 + z1) / 2 + s * d * 0.25);
      m.rotation.x = s * ang;
      m.castShadow = true;
      scene.add(m);
    }
    bx(x0, (z0 + z1) / 2 - 0.2, x1, (z0 + z1) / 2 + 0.2, yb + hr, yb + hr + 0.22, darkMat, false);
  }

  function pillar(x: number, z: number, h: number) {
    obs.push({ x, z, r: 0.42 });
    mesh(new THREE.CylinderGeometry(0.38, 0.42, h, 12), redMat, x, h / 2, z);
    mesh(new THREE.CylinderGeometry(0.46, 0.46, 0.14, 12), goldMat, x, h - 0.35, z);
  }

  function lantern(x: number, y: number, z: number) {
    spots.push({ x, y, z, fire: false });
    mesh(new THREE.CylinderGeometry(0.02, 0.02, 1.1, 6), darkMat, x, y + 0.7, z, false);
    const glow = new THREE.Mesh(
      new THREE.CylinderGeometry(0.22, 0.22, 0.46, 10),
      new THREE.MeshBasicMaterial({ color: 0xffb464 }),
    );
    glow.position.set(x, y, z);
    scene.add(glow);
    mesh(new THREE.CylinderGeometry(0.26, 0.26, 0.05, 10), darkMat, x, y + 0.26, z, false);
    mesh(new THREE.CylinderGeometry(0.26, 0.26, 0.05, 10), darkMat, x, y - 0.26, z, false);
  }

  function stoneLantern(x: number, z: number) {
    obs.push({ x, z, r: 0.34 });
    spots.push({ x, y: 1.35, z, fire: false });
    mesh(new THREE.CylinderGeometry(0.28, 0.34, 0.28, 8), stoneMat, x, 0.16, z);
    mesh(new THREE.CylinderGeometry(0.1, 0.12, 0.7, 8), stoneMat, x, 0.62, z);
    const f = new THREE.Mesh(new THREE.BoxGeometry(0.34, 0.32, 0.34), new THREE.MeshBasicMaterial({ color: 0xffc070 }));
    f.position.set(x, 1.22, z);
    scene.add(f);
    const roof = mesh(new THREE.ConeGeometry(0.42, 0.32, 4), stoneMat, x, 1.58, z);
    roof.rotation.y = Math.PI / 4;
  }

  function brazier(x: number, z: number, scale = 1) {
    obs.push({ x, z, r: 0.5 * scale });
    spots.push({ x, y: 1.4 * scale, z, fire: true });
    mesh(new THREE.CylinderGeometry(0.08 * scale, 0.1 * scale, 0.7 * scale, 8), darkMat, x, 0.35 * scale, z);
    mesh(new THREE.CylinderGeometry(0.42 * scale, 0.28 * scale, 0.36 * scale, 12), darkMat, x, 0.8 * scale, z);
    const flame = new THREE.Mesh(
      new THREE.ConeGeometry(0.22 * scale, 0.7 * scale, 8),
      new THREE.MeshBasicMaterial({ color: 0xff8a2a, transparent: true, opacity: 0.9 }),
    );
    flame.position.set(x, 1.25 * scale, z);
    scene.add(flame);
    flames.push(flame);
    const sp = new THREE.Sprite(
      new THREE.SpriteMaterial({
        map: tex.glow,
        blending: THREE.AdditiveBlending,
        transparent: true,
        depthWrite: false,
      }),
    );
    sp.position.set(x, 1.35 * scale, z);
    sp.scale.setScalar(2.4 * scale);
    scene.add(sp);
  }

  function sakura(x: number, z: number) {
    obs.push({ x, z, r: 0.55 });
    mesh(new THREE.CylinderGeometry(0.18, 0.28, 2.4, 7), woodMat, x, 1.2, z);
    const cols = [0xe58aa8, 0xf4b6c8, 0xf3c3d4, 0xd47898];
    for (let i = 0; i < 4; i++) {
      const r = 1.15 + rng() * 0.7;
      const m = mesh(
        new THREE.IcosahedronGeometry(1, 1),
        new THREE.MeshStandardMaterial({ color: cols[i % 4], roughness: 0.85, flatShading: true }),
        x + (rng() - 0.5) * 1.8,
        2.8 + rng() * 0.9,
        z + (rng() - 0.5) * 1.8,
      );
      m.scale.set(r, r * 0.75, r);
    }
  }

  function house(cx: number, cz: number, w: number, d: number) {
    const x0 = cx - w / 2;
    const x1 = cx + w / 2;
    const z0 = cz - d / 2;
    const z1 = cz + d / 2;
    walls.push({ x0, z0, x1, z1, tall: true });
    bx(x0, z0, x1, z1, 0, 3.1, plasterMat);
    gable(x0, x1, z0, z1, 3.1, 1.7);
    bx(cx - 0.55, z1, cx + 0.55, z1 + 0.08, 0, 2.1, woodMat, false);
    const win = new THREE.Mesh(
      new THREE.PlaneGeometry(1.05, 0.8),
      new THREE.MeshBasicMaterial({ color: 0xffc070 }),
    );
    win.position.set(cx + w * 0.22, 1.6, z1 + 0.05);
    scene.add(win);
  }

  // terrain
  const tg = new THREE.PlaneGeometry(400, 400, 120, 120);
  tg.rotateX(-Math.PI / 2);
  const pos = tg.attributes.position;
  const col = new Float32Array(pos.count * 3);
  for (let i = 0; i < pos.count; i++) {
    const x = pos.getX(i);
    const z = pos.getZ(i);
    const h = groundHeight(x, z);
    pos.setY(i, h);
    const sl = Math.abs(groundHeight(x + 2, z) - h) + Math.abs(groundHeight(x, z + 2) - h);
    const n = Math.sin(x * 0.41) * Math.sin(z * 0.37);
    const f = flatAt(x, z);
    let r = 0.18 + n * 0.03;
    let g = 0.3 + n * 0.04;
    let b = 0.14;
    if (h < -0.85) {
      r = 0.16;
      g = 0.18;
      b = 0.14;
    }
    if (h > 4.5 || sl > 0.85) {
      const t = clamp((h - 4.5) / 9 + sl * 0.45, 0, 1);
      r += (0.42 - r) * t;
      g += (0.4 - g) * t;
      b += (0.38 - b) * t;
    }
    const dx = Math.abs(x - roadX(z));
    if (z > 22 && z < 152 && dx < 2.4) {
      const t = 1 - dx / 2.4;
      r += (0.4 - r) * t;
      g += (0.32 - g) * t;
      b += (0.2 - b) * t;
    }
    if (f > 0.65 && !(Math.abs(x) < 26 && z < 34 && z > -50)) {
      r += (0.32 - r) * 0.45;
      g += (0.26 - g) * 0.45;
      b += (0.18 - b) * 0.45;
    }
    col[i * 3] = r;
    col[i * 3 + 1] = g;
    col[i * 3 + 2] = b;
  }
  tg.setAttribute("color", new THREE.BufferAttribute(col, 3));
  tg.computeVertexNormals();
  const terr = new THREE.Mesh(
    tg,
    new THREE.MeshStandardMaterial({
      map: repeat(tex.grass, 70, 70),
      vertexColors: true,
      roughness: 0.94,
      metalness: 0,
    }),
  );
  terr.receiveShadow = true;
  scene.add(terr);

  // river
  const wg = new THREE.PlaneGeometry(16, 400, 1, 70);
  wg.rotateX(-Math.PI / 2);
  const wp = wg.attributes.position;
  for (let i = 0; i < wp.count; i++) {
    const z = wp.getZ(i);
    wp.setX(i, rvx(z) + wp.getX(i));
    wp.setY(i, -1.22);
  }
  wg.computeVertexNormals();
  const waterMap = repeat(tex.water, 4, 18);
  const water = new THREE.Mesh(
    wg,
    new THREE.MeshStandardMaterial({
      color: 0x8fb8c8,
      map: waterMap,
      roughness: 0.08,
      metalness: 0.55,
      transparent: true,
      opacity: 0.86,
      envMapIntensity: 1.2,
    }),
  );
  water.receiveShadow = true;
  scene.add(water);

  // forest
  const NT = 260;
  const dummy = new THREE.Object3D();
  const cc = new THREE.Color();
  const trunks = new THREE.InstancedMesh(new THREE.CylinderGeometry(0.16, 0.26, 2.3, 6), std(0xffffff, 0.9, 0), NT);
  const f1 = new THREE.InstancedMesh(new THREE.ConeGeometry(1.45, 3.1, 7), std(0xffffff, 0.86, 0), NT);
  const f2 = new THREE.InstancedMesh(new THREE.ConeGeometry(1.05, 2.4, 7), std(0xffffff, 0.86, 0), NT);
  trunks.castShadow = true;
  f1.castShadow = true;
  let n = 0;
  for (let t = 0; t < 5000 && n < NT; t++) {
    const x = (rng() - 0.5) * 370;
    const z = (rng() - 0.5) * 370;
    if (flatAt(x, z) > 0.12) continue;
    if (groundHeight(x, z) < -0.7) continue;
    if (Math.abs(x - roadX(z)) < 4.2 && z > 18 && z < 155) continue;
    if (Math.abs(groundHeight(x + 2, z) - groundHeight(x, z)) > 0.9) continue;
    const s = 0.75 + rng() * 0.95;
    const h = groundHeight(x, z);
    dummy.rotation.set(0, rng() * TAU, 0);
    dummy.scale.setScalar(s);
    dummy.position.set(x, h + 1.15 * s, z);
    dummy.updateMatrix();
    trunks.setMatrixAt(n, dummy.matrix);
    cc.setHSL(0.07 + rng() * 0.04, 0.35, 0.22 + rng() * 0.08);
    trunks.setColorAt(n, cc);
    dummy.position.y = h + 2.9 * s;
    dummy.updateMatrix();
    f1.setMatrixAt(n, dummy.matrix);
    cc.setHSL(0.3 + rng() * 0.06, 0.38, 0.16 + rng() * 0.08);
    f1.setColorAt(n, cc);
    f2.setColorAt(n, cc);
    dummy.position.y = h + 4.3 * s;
    dummy.updateMatrix();
    f2.setMatrixAt(n, dummy.matrix);
    obs.push({ x, z, r: 0.42 * s });
    n++;
  }
  trunks.count = f1.count = f2.count = n;
  for (const m of [trunks, f1, f2]) {
    m.frustumCulled = false;
    scene.add(m);
  }

  const NR = 70;
  const rocks = new THREE.InstancedMesh(
    new THREE.DodecahedronGeometry(1, 0),
    new THREE.MeshStandardMaterial({ color: 0x7a766e, roughness: 0.9, flatShading: true }),
    NR,
  );
  let q = 0;
  for (let t = 0; t < 2000 && q < NR; t++) {
    const x = (rng() - 0.5) * 360;
    const z = (rng() - 0.5) * 360;
    if (flatAt(x, z) > 0.15 || groundHeight(x, z) < -0.5) continue;
    const s = 0.55 + rng() * 1.7;
    dummy.position.set(x, groundHeight(x, z) + s * 0.25, z);
    dummy.scale.set(s, s * (0.45 + rng() * 0.4), s);
    dummy.rotation.set(rng(), rng() * TAU, rng());
    dummy.updateMatrix();
    rocks.setMatrixAt(q, dummy.matrix);
    if (s > 1.25) obs.push({ x, z, r: s * 0.75 });
    q++;
  }
  rocks.count = q;
  rocks.castShadow = true;
  rocks.frustumCulled = false;
  scene.add(rocks);

  // camps
  for (const c of camps) {
    brazier(c.x, c.z, 1.15);
    for (let k = 0; k < 3; k++) {
      const a = (k / 3) * TAU + 0.6;
      const tx = c.x + Math.cos(a) * 8.5;
      const tz = c.z + Math.sin(a) * 8.5;
      const tent = mesh(new THREE.ConeGeometry(2.5, 2.6, 8), std([0x5c4c34, 0x3e3224, 0x6a5840][k]!, 0.9), tx, 1.3, tz);
      tent.castShadow = true;
      obs.push({ x: tx, z: tz, r: 2.1 });
    }
    mesh(new THREE.CylinderGeometry(0.06, 0.06, 4.2, 6), darkMat, c.x + 6, 2.1, c.z - 5);
    const bn = new THREE.Mesh(
      new THREE.PlaneGeometry(1.3, 2.1),
      new THREE.MeshStandardMaterial({ map: tex.banner, roughness: 0.7, side: THREE.DoubleSide }),
    );
    bn.position.set(c.x + 6.7, 3.5, c.z - 5);
    scene.add(bn);
    for (let k = 0; k < 3; k++) {
      const bx0 = c.x - 4 + k * 0.95;
      mesh(new THREE.CylinderGeometry(0.38, 0.42, 0.8, 10), woodMat, bx0, 0.4, c.z + 6.5);
      obs.push({ x: bx0, z: c.z + 6.5, r: 0.42 });
    }
  }

  // village
  for (const h of [
    [-15, -10, 9, 7],
    [15, -10, 9, 7],
    [-17, 8, 8, 7],
    [17, 8, 8, 7],
    [-6, 18, 8, 6],
    [9, 18, 8, 6],
  ] as const) {
    house(VIL.x + h[0], VIL.z + h[1], h[2], h[3]);
  }
  for (const p of [
    [-5, 132],
    [5, 132],
    [-5, 148],
    [5, 148],
  ] as const) {
    stoneLantern(p[0], p[1]);
  }
  obs.push({ x: VIL.x, z: VIL.z, r: 1.2 });
  mesh(new THREE.CylinderGeometry(1.05, 1.05, 0.8, 12), stoneMat, VIL.x, 0.4, VIL.z);
  const wr = mesh(new THREE.ConeGeometry(1.5, 0.7, 4), tileMat, VIL.x, 2.5, VIL.z);
  wr.rotation.y = Math.PI / 4;
  mesh(new THREE.CylinderGeometry(0.07, 0.07, 2.2, 6), woodMat, VIL.x - 0.85, 1.1, VIL.z);
  mesh(new THREE.CylinderGeometry(0.07, 0.07, 2.2, 6), woodMat, VIL.x + 0.85, 1.1, VIL.z);
  for (const p of [
    [-10, 4],
    [12, -2],
    [1, 14],
  ] as const) {
    sakura(VIL.x + p[0], VIL.z + p[1]);
  }
  // torii toward the palace road
  for (const sx of [-1, 1]) {
    obs.push({ x: sx * 2.3, z: 118, r: 0.35 });
    mesh(new THREE.CylinderGeometry(0.22, 0.26, 4.4, 10), redMat, sx * 2.3, 2.2, 118);
  }
  bx(-3.2, 117.7, 3.2, 118.3, 4.2, 4.7, redMat);
  bx(-3.4, 117.75, 3.4, 118.25, 3.7, 4.0, darkMat);

  // palace grounds
  floor(-19, 2, 19, 26, 0.02, tex.gravel, 4, 4);
  floor(-3, 2, 3, 26, 0.035, tex.stone, 3, 3);
  floor(-17, -27, 17, 1.4, 0.03, tex.tatami, 2, 1);
  floor(-17, -40, -6, -28, 0.03, tex.wood, 2.5, 2.5);
  floor(6, -40, 17, -28, 0.03, tex.wood, 2.5, 2.5);
  floor(-6, -40, 6, -29, 0.03, tex.wood, 2.2, 2.2);
  floor(-17, -42, 17, -29.2, 0.04, tex.lacquer, 2, 2);

  wall(-18.2, -42.2, 18.2, -41.4, 6.2);
  wall(-18.2, -42.2, -17.4, 1.6, 6.2);
  wall(17.4, -42.2, 18.2, 1.6, 6.2);
  wall(-18.2, 1.2, -2.8, 2.0, 6.2);
  wall(2.8, 1.2, 18.2, 2.0, 6.2);
  wall(-17.4, -28.5, -2.7, -27.7, 6.2, false);
  wall(2.7, -28.5, 17.4, -27.7, 6.2, false);
  // courtyard fences
  wall(-19.5, 2, -18.3, 25.5, 2.3);
  wall(18.3, 2, 19.5, 25.5, 2.3);
  wall(-19.5, 24.6, -3.1, 25.6, 2.3);
  wall(3.1, 24.6, 19.5, 25.6, 2.3);

  gable(-18, 18, -8, 2, 6.2, 2.5);
  gable(-18, 18, -42.4, -28.2, 6.4, 3.6);

  // garden pocket
  walls.push({ x0: -7.2, z0: -23, x1: 7.2, z1: -9, tall: false });
  bx(-7.2, -23, 7.2, -9, 0, 0.08, lambert(repeat(tex.gravel, 3, 3)), false);
  bx(-7.4, -23.3, 7.4, -22.7, 0, 0.7, woodMat);
  bx(-7.4, -9.4, 7.4, -8.8, 0, 0.7, woodMat);
  bx(-7.4, -23.3, -6.8, -8.8, 0, 0.7, woodMat);
  bx(6.8, -23.3, 7.4, -8.8, 0, 0.7, woodMat);
  const pond = new THREE.Mesh(
    new THREE.CircleGeometry(1, 28),
    new THREE.MeshStandardMaterial({
      color: 0x2a6e80,
      roughness: 0.08,
      metalness: 0.45,
      transparent: true,
      opacity: 0.9,
    }),
  );
  pond.rotation.x = -Math.PI / 2;
  pond.scale.set(4.6, 2.8, 1);
  pond.position.set(0, 0.12, -16);
  pond.receiveShadow = true;
  scene.add(pond);

  for (const p of [
    [-10, 10],
    [-6, 18],
    [10, 10],
    [7, 18],
    [-14, 20],
    [14, 19],
  ] as const) {
    sakura(p[0], p[1]);
  }
  for (const p of [
    [-5, 8],
    [5, 8],
    [-5, 16],
    [5, 16],
  ] as const) {
    stoneLantern(p[0], p[1]);
  }

  // gate
  for (const sx of [-1, 1]) {
    obs.push({ x: sx * 2.7, z: 25.2, r: 0.45 });
    mesh(new THREE.CylinderGeometry(0.4, 0.46, 5.6, 12), redMat, sx * 2.7, 2.8, 25.2);
    mesh(new THREE.CylinderGeometry(0.5, 0.5, 0.16, 12), goldMat, sx * 2.7, 5.3, 25.2);
  }
  bx(-3.3, 24.95, 3.3, 25.45, 5.15, 5.7, darkMat);
  lantern(0, 4.3, 25.2);

  for (const p of [
    [-12, -8],
    [-12, -18],
    [12, -8],
    [12, -18],
    [-8, -33],
    [8, -33],
    [-8, -38],
    [8, -38],
  ] as const) {
    pillar(p[0], p[1], p[1] < -29 ? 7.2 : 6.2);
  }
  for (const p of [
    [-12, 4.4, -6],
    [12, 4.4, -6],
    [-12, 4.4, -20],
    [12, 4.4, -20],
    [0, 5.2, -34],
  ] as const) {
    lantern(p[0], p[1], p[2]);
  }
  for (const p of [
    [-6, -34],
    [6, -34],
    [-6, -39],
    [6, -39],
  ] as const) {
    brazier(p[0], p[1], 0.9);
  }

  // throne
  bx(-4.2, -41.2, 4.2, -36.6, 0, 0.45, woodMat);
  bx(-3.2, -41.2, 3.2, -38.4, 0.45, 0.9, woodMat);
  bx(-1.3, -41, 1.3, -38.6, 0.9, 1.45, redMat);
  bx(-1.15, -41.05, 1.15, -40.5, 1.45, 3.3, darkMat);
  bx(-1.25, -41.1, 1.25, -40.45, 3.2, 3.45, goldMat, false);
  walls.push({ x0: -4.2, z0: -41.4, x1: 4.2, z1: -36.4, tall: false });
  const scr = new THREE.Mesh(
    new THREE.PlaneGeometry(9, 3.6),
    new THREE.MeshStandardMaterial({ color: 0xc9a24a, roughness: 0.55, metalness: 0.15 }),
  );
  scr.position.set(0, 2.4, -41.15);
  scene.add(scr);
  for (const bx0 of [-13, -8, 8, 13]) {
    const b = new THREE.Mesh(
      new THREE.PlaneGeometry(1.15, 3.4),
      new THREE.MeshStandardMaterial({ map: tex.banner, side: THREE.DoubleSide, roughness: 0.65 }),
    );
    b.position.set(bx0, 4.4, -41);
    scene.add(b);
  }

  const doorMat = lambert(tex.door);
  const door: Wall = { x0: -2.7, z0: -28.55, x1: 2.7, z1: -27.85, tall: true };
  function hinge(hingeX: number, leaf: number) {
    const g = new THREE.Group();
    g.position.set(hingeX, 0, -28.2);
    const m = new THREE.Mesh(new THREE.BoxGeometry(Math.abs(leaf), 4.5, 0.16), doorMat);
    m.position.set(leaf / 2, 2.25, 0);
    m.castShadow = true;
    m.receiveShadow = true;
    g.add(m);
    scene.add(g);
    return g;
  }
  const doorL = hinge(-2.65, 2.6);
  const doorR = hinge(2.65, -2.6);
  bx(-3.4, -28.7, 3.4, -27.7, 4.7, 5.5, darkMat);

  // petals
  const PN = 160;
  const petals = new THREE.Points(
    new THREE.BufferGeometry(),
    new THREE.PointsMaterial({
      color: 0xf4b6c8,
      size: 0.14,
      transparent: true,
      opacity: 0.8,
      depthWrite: false,
    }),
  );
  const pp = new Float32Array(PN * 3);
  for (let i = 0; i < PN; i++) {
    pp[i * 3] = (rng() - 0.5) * 40;
    pp[i * 3 + 1] = rng() * 6;
    pp[i * 3 + 2] = (rng() - 0.5) * 40;
  }
  petals.geometry.setAttribute("position", new THREE.BufferAttribute(pp, 3));
  petals.frustumCulled = false;
  scene.add(petals);

  const grid = new Map<string, Obs[]>();
  for (const o of obs) {
    const k = `${Math.floor(o.x / 20)},${Math.floor(o.z / 20)}`;
    const list = grid.get(k);
    if (list) list.push(o);
    else grid.set(k, [o]);
  }

  const spawns: Spawn[] = [];
  const push = (
    kind: Kind,
    x: number,
    z: number,
    yaw: number,
    camp: number,
    palace: boolean,
    dormant: boolean,
    patrol: [number, number][] | null = null,
  ) => spawns.push({ kind, x, z, yaw, camp, palace, dormant, patrol });

  push("sam", -4, 30, Math.PI, -1, true, false);
  push("sam", 4, 30, Math.PI, -1, true, false);
  push("ash", -8, 16, Math.PI, -1, true, false);
  push("ash", 8, 16, Math.PI, -1, true, false);
  push("ash", -12, 8, 0.4, -1, true, false);
  push("ash", 12, 8, -0.4, -1, true, false);
  push("sam", -8, -8, 0, -1, true, false);
  push("sam", 8, -8, 0, -1, true, false);
  push("sam", -6, -20, 0.6, -1, true, false);
  push("sam", 6, -20, -0.6, -1, true, false);
  push("eli", -4, -32, 0, -1, true, true);
  push("eli", 4, -32, 0, -1, true, true);
  push("boss", 0, -37.2, 0, -1, true, true);

  camps.forEach((c, ci) => {
    for (let k = 0; k < 5; k++) {
      const a = (k / 5) * TAU + ci * 0.4;
      push(k < 3 ? "ash" : "sam", c.x + Math.cos(a) * 6.2, c.z + Math.sin(a) * 6.2, a + Math.PI, ci, false, false);
    }
  });
  push("eli", camps[3]!.x + 3.2, camps[3]!.z + 4.4, Math.PI, 3, false, false);
  push("ash", -8, 96, Math.PI, -1, false, false, [
    [-8, 96],
    [6, 78],
  ]);
  push("ash", 14, 70, Math.PI, -1, false, false, [
    [14, 70],
    [-4, 54],
  ]);
  push("ash", -16, 46, 0.5, -1, false, false, [
    [-16, 46],
    [8, 36],
  ]);

  return {
    walls,
    door,
    doorL,
    doorR,
    grid,
    camps,
    spots,
    flames,
    gh: groundHeight,
    petals,
    waterMap,
    spawns,
  };
}
