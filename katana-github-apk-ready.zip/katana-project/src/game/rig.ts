import * as THREE from "three";
import type { TexSet } from "./materials";

export type Kind = "pl" | "ash" | "sam" | "eli" | "boss";

export type Anim = {
  speed: number;
  attack: number;
  attackDur: number;
  combo: number;
  throwing: number;
  dodge: number;
  dodgeSide: number;
  hurt: number;
  time: number;
  dead: number;
};

export type Rig = {
  kind: Kind;
  root: THREE.Group;
  body: THREE.Group;
  torso: THREE.Group;
  head: THREE.Group;
  legs: [THREE.Group, THREE.Group];
  knees: [THREE.Group, THREE.Group];
  arms: [THREE.Group, THREE.Group];
  fores: [THREE.Group, THREE.Group];
  cape: THREE.Group | null;
  mats: THREE.MeshStandardMaterial[];
  phase: number;
  flashing: boolean;
};

type Pal = {
  armor: number;
  armor2: number;
  cloth: number;
  trim: number;
  skin: number;
  eye: number;
  scale: number;
  hat: "kabuto" | "jingasa" | "hair";
  crest: "moon" | "horn" | "antler" | "none";
  mask: boolean;
  cape: boolean;
  banner: boolean;
  beard: boolean;
  scar: boolean;
};

const PALS: Record<Kind, Pal> = {
  pl: {
    armor: 0x1c3158,
    armor2: 0x121c36,
    cloth: 0x1a2030,
    trim: 0xd8b45a,
    skin: 0xc68662,
    eye: 0x1a2744,
    scale: 1,
    hat: "hair",
    crest: "moon",
    mask: false,
    cape: false,
    banner: true,
    beard: false,
    scar: true,
  },
  ash: {
    armor: 0x6a5438,
    armor2: 0x4a3824,
    cloth: 0x5c4a34,
    trim: 0xa89068,
    skin: 0xb88868,
    eye: 0x2a1a10,
    scale: 0.98,
    hat: "jingasa",
    crest: "none",
    mask: false,
    cape: false,
    banner: false,
    beard: true,
    scar: false,
  },
  sam: {
    armor: 0x4a1520,
    armor2: 0x2a0c12,
    cloth: 0x1a1214,
    trim: 0xd0b060,
    skin: 0xc09070,
    eye: 0x14080c,
    scale: 1.02,
    hat: "kabuto",
    crest: "horn",
    mask: true,
    cape: false,
    banner: false,
    beard: false,
    scar: false,
  },
  eli: {
    armor: 0x14151a,
    armor2: 0x0c0c10,
    cloth: 0x101014,
    trim: 0xd8b45a,
    skin: 0xa87860,
    eye: 0xff2a2a,
    scale: 1.06,
    hat: "kabuto",
    crest: "horn",
    mask: true,
    cape: false,
    banner: false,
    beard: false,
    scar: false,
  },
  boss: {
    armor: 0x100e0c,
    armor2: 0x070606,
    cloth: 0x6e0c18,
    trim: 0xe0c05a,
    skin: 0x2a2422,
    eye: 0xff1a1a,
    scale: 1.38,
    hat: "kabuto",
    crest: "antler",
    mask: true,
    cape: true,
    banner: false,
    beard: false,
    scar: false,
  },
};

const geos = new Map<string, THREE.BufferGeometry>();

function geo(key: string, build: () => THREE.BufferGeometry) {
  let g = geos.get(key);
  if (!g) {
    g = build();
    geos.set(key, g);
  }
  return g;
}

const box = (w: number, h: number, d: number) =>
  geo(`b${w}_${h}_${d}`, () => new THREE.BoxGeometry(w, h, d));
const cyl = (rt: number, rb: number, h: number, s = 10) =>
  geo(`c${rt}_${rb}_${h}_${s}`, () => new THREE.CylinderGeometry(rt, rb, h, s));
const sph = (r: number, w = 12, h = 8) =>
  geo(`s${r}_${w}_${h}`, () => new THREE.SphereGeometry(r, w, h));

let bladeGeo: THREE.BufferGeometry | null = null;
function blade() {
  if (bladeGeo) return bladeGeo;
  const s = new THREE.Shape();
  s.moveTo(-0.02, 0);
  s.lineTo(-0.016, 0.78);
  s.lineTo(0.004, 0.92);
  s.lineTo(0.02, 0.78);
  s.lineTo(0.018, 0);
  const g = new THREE.ExtrudeGeometry(s, { depth: 0.012, bevelEnabled: false });
  g.translate(0, 0, -0.006);
  bladeGeo = g;
  return g;
}

const whiteEye = new THREE.MeshBasicMaterial({ color: 0xf2f4f6 });
const bossEye = new THREE.MeshBasicMaterial({ color: 0xff2a2a });
const darkEye = new THREE.MeshBasicMaterial({ color: 0x140c0c });

export function buildRig(kind: Kind, tex: TexSet, scene: THREE.Scene): Rig {
  const pal = PALS[kind];
  const mats: THREE.MeshStandardMaterial[] = [];
  const M = (color: number, rough: number, metal: number, map?: THREE.Texture | null) => {
    const m = new THREE.MeshStandardMaterial({
      color,
      roughness: rough,
      metalness: metal,
      map: map ?? null,
      envMapIntensity: metal > 0.4 ? 1 : 0.55,
    });
    mats.push(m);
    return m;
  };
  const armor = M(pal.armor, 0.38, 0.62, tex.lacing);
  const armor2 = M(pal.armor2, 0.45, 0.48, tex.lacing);
  const cloth = M(pal.cloth, 0.9, 0.02);
  const trim = M(pal.trim, 0.26, 0.88);
  const skin = M(pal.skin, 0.55, 0.02, tex.skin);
  const dark = M(0x16130f, 0.5, 0.25);
  const steel = M(0xdfe7ef, 0.16, 0.84, tex.hamon);
  const wood = M(0x3a2718, 0.72, 0.04, tex.wood);
  const wrap = M(0x1a120e, 0.78, 0.08);

  const root = new THREE.Group();
  root.scale.setScalar(pal.scale);
  const body = new THREE.Group();
  root.add(body);

  const add = (
    g: THREE.BufferGeometry,
    mat: THREE.Material,
    parent: THREE.Object3D,
    x = 0,
    y = 0,
    z = 0,
    rx = 0,
    ry = 0,
    rz = 0,
  ) => {
    const m = new THREE.Mesh(g, mat);
    m.position.set(x, y, z);
    m.rotation.set(rx, ry, rz);
    m.castShadow = true;
    m.receiveShadow = true;
    parent.add(m);
    return m;
  };

  const legs: [THREE.Group, THREE.Group] = [new THREE.Group(), new THREE.Group()];
  const knees: [THREE.Group, THREE.Group] = [new THREE.Group(), new THREE.Group()];

  for (const side of [-1, 1] as const) {
    const i = side === -1 ? 0 : 1;
    const hip = legs[i];
    hip.position.set(side * 0.1, 0.98, 0);
    body.add(hip);
    add(cyl(0.09, 0.11, 0.42, 8), cloth, hip, 0, -0.2, 0);
    add(box(0.12, 0.16, 0.06), armor2, hip, 0, -0.16, 0.07);
    const knee = knees[i];
    knee.position.set(0, -0.4, 0);
    hip.add(knee);
    add(cyl(0.07, 0.055, 0.4, 8), cloth, knee, 0, -0.2, 0);
    add(box(0.1, 0.22, 0.05), armor, knee, 0, -0.16, 0.06);
    add(box(0.1, 0.05, 0.22), dark, knee, 0, -0.42, 0.04);
    add(box(0.09, 0.02, 0.08), wrap, knee, 0, -0.4, 0.08);
  }

  const torso = new THREE.Group();
  torso.position.y = 0.98;
  body.add(torso);
  add(cyl(0.2, 0.16, 0.28, 12), cloth, torso, 0, 0.16, 0);
  const chest = add(box(0.38, 0.32, 0.2), armor, torso, 0, 0.34, 0.02);
  chest.scale.set(1, 1, 1);
  add(box(0.34, 0.06, 0.22), trim, torso, 0, 0.2, 0.02);
  add(cyl(0.045, 0.045, 0.02, 10), trim, torso, 0, 0.38, 0.13, Math.PI / 2, 0, 0);
  add(box(0.42, 0.08, 0.16), armor2, torso, 0, 0.5, 0);
  // hakama
  const hakama = add(cyl(0.13, 0.28, 0.48, 10), cloth, torso, 0, -0.12, 0);
  hakama.scale.set(1.15, 1, 0.85);
  // obi knot
  add(box(0.1, 0.1, 0.08), trim, torso, 0, 0.08, 0.16);
  add(box(0.04, 0.16, 0.03), trim, torso, 0.05, -0.02, 0.16);

  for (const side of [-1, 1] as const) {
    const sode = add(box(0.16, 0.2, 0.18), armor, torso, side * 0.28, 0.46, 0);
    sode.rotation.z = side * -0.35;
    add(box(0.17, 0.03, 0.19), trim, torso, side * 0.3, 0.56, 0);
  }

  // saya on left hip (local +X is model's left when facing +Z)
  add(box(0.045, 0.06, 0.72), wood, torso, 0.2, 0.02, -0.18, 0.35, 0, 0.4);
  add(box(0.07, 0.04, 0.06), trim, torso, 0.22, 0.16, 0.02);
  // kunai pouch
  add(box(0.1, 0.12, 0.06), dark, torso, -0.18, 0.02, 0.1);
  for (let i = 0; i < 3; i++) {
    add(box(0.012, 0.08, 0.012), dark, torso, -0.2 + i * 0.02, 0.1, 0.12);
  }

  if (pal.banner) {
    add(box(0.02, 0.7, 0.02), dark, torso, 0, 0.55, -0.16);
    const bn = new THREE.Mesh(
      box(0.02, 0.46, 0.28),
      new THREE.MeshStandardMaterial({
        map: tex.banner,
        roughness: 0.7,
        metalness: 0.05,
        side: THREE.DoubleSide,
      }),
    );
    bn.position.set(-0.02, 0.42, -0.16);
    bn.castShadow = true;
    torso.add(bn);
    mats.push(bn.material);
  }

  let cape: THREE.Group | null = null;
  if (pal.cape) {
    cape = new THREE.Group();
    cape.position.set(0, 0.5, -0.12);
    torso.add(cape);
    const cm = add(box(0.7, 0.95, 0.02), cloth, cape, 0, -0.45, 0);
    cm.material = cloth;
  }

  const head = new THREE.Group();
  head.position.set(0, 0.62, 0);
  torso.add(head);
  add(cyl(0.05, 0.055, 0.1, 8), skin, head, 0, -0.02, 0);
  add(sph(0.11, 16, 12), skin, head, 0, 0.1, 0);
  const eyeMat = pal.eye === 0xff2a2a || pal.eye === 0xff1a1a ? bossEye : darkEye;
  for (const side of [-1, 1] as const) {
    add(sph(0.02, 8, 6), whiteEye, head, side * 0.038, 0.12, 0.086);
    const pupil = add(sph(0.011, 6, 6), eyeMat, head, side * 0.038, 0.12, 0.1);
    pupil.scale.setScalar(pal.mask ? 0.8 : 1);
    add(box(0.034, 0.008, 0.012), dark, head, side * 0.04, 0.15, 0.09);
  }
  if (!pal.mask) {
    add(box(0.018, 0.028, 0.02), skin, head, 0, 0.1, 0.1);
    add(box(0.03, 0.008, 0.012), dark, head, 0, 0.078, 0.1);
  }
  if (pal.scar) add(box(0.05, 0.008, 0.012), M(0x8a3a3a, 0.6, 0), head, 0.04, 0.1, 0.09, 0, 0, 0.6);
  if (pal.beard) {
    add(sph(0.055, 8, 6), dark, head, 0, 0.04, 0.06);
    add(box(0.07, 0.04, 0.03), dark, head, 0, 0.02, 0.08);
  }
  if (pal.mask) {
    add(sph(0.105, 14, 10), armor2, head, 0, 0.06, 0.03);
    add(box(0.09, 0.025, 0.04), trim, head, 0, 0.05, 0.11);
  }

  if (pal.hat === "jingasa") {
    const hat = add(geo("jinga", () => new THREE.ConeGeometry(0.28, 0.12, 16)), wood, head, 0, 0.22, 0);
    hat.scale.set(1, 1, 1);
    add(cyl(0.05, 0.05, 0.04, 8), dark, head, 0, 0.18, 0);
  } else if (pal.hat === "hair") {
    add(cyl(0.045, 0.07, 0.16, 8), dark, head, 0, 0.22, -0.02);
    add(sph(0.05, 8, 6), dark, head, 0, 0.32, -0.02);
    add(box(0.16, 0.025, 0.04), trim, head, 0, 0.2, 0.02);
    if (pal.crest === "moon") {
      const moon = add(
        geo("moon", () => new THREE.TorusGeometry(0.09, 0.01, 6, 16, Math.PI * 1.25)),
        trim,
        head,
        0,
        0.34,
        0.02,
      );
      moon.rotation.z = -0.4;
    }
  } else {
    add(sph(0.125, 14, 10), armor, head, 0, 0.14, 0);
    add(cyl(0.16, 0.14, 0.05, 12), armor2, head, 0, 0.08, 0);
    add(box(0.2, 0.04, 0.08), trim, head, 0, 0.05, 0.1);
    if (pal.crest === "horn") {
      for (const side of [-1, 1] as const) {
        const h = add(geo("horn", () => new THREE.ConeGeometry(0.016, 0.22, 6)), trim, head, side * 0.08, 0.28, 0.02);
        h.rotation.z = side * -0.45;
      }
    } else if (pal.crest === "antler") {
      for (const side of [-1, 1] as const) {
        const h = add(geo("ant", () => new THREE.ConeGeometry(0.02, 0.36, 6)), trim, head, side * 0.09, 0.32, 0.02);
        h.rotation.z = side * -0.4;
        const b = add(geo("antb", () => new THREE.ConeGeometry(0.012, 0.16, 5)), trim, head, side * 0.16, 0.3, 0.02);
        b.rotation.z = side * -1.1;
      }
    }
  }

  const arms: [THREE.Group, THREE.Group] = [new THREE.Group(), new THREE.Group()];
  const fores: [THREE.Group, THREE.Group] = [new THREE.Group(), new THREE.Group()];
  for (const side of [-1, 1] as const) {
    const i = side === -1 ? 1 : 0; // -1 is model's right
    const arm = new THREE.Group();
    arm.position.set(side * 0.24, 0.48, 0);
    torso.add(arm);
    arms[i] = arm;
    add(cyl(0.055, 0.05, 0.26, 8), cloth, arm, 0, -0.14, 0);
    add(box(0.08, 0.12, 0.08), armor2, arm, 0, -0.08, 0.02);
    const fore = new THREE.Group();
    fore.position.set(0, -0.28, 0);
    arm.add(fore);
    fores[i] = fore;
    add(cyl(0.048, 0.04, 0.24, 8), armor2, fore, 0, -0.12, 0);
    add(sph(0.045, 8, 6), dark, fore, 0, -0.26, 0.02);
  }

  const sw = new THREE.Group();
  sw.position.set(0, -0.28, 0.02);
  sw.rotation.set(-1.05, 0.2, 0.15);
  fores[1].add(sw);
  add(cyl(0.016, 0.016, 0.22, 8), wrap, sw, 0, 0.08, 0);
  add(cyl(0.055, 0.055, 0.018, 12), trim, sw, 0, 0.2, 0);
  add(blade(), steel, sw, 0, 0.2, 0);
  add(sph(0.02, 6, 6), trim, sw, 0, -0.02, 0);

  scene.add(root);
  const rig: Rig = {
    kind,
    root,
    body,
    torso,
    head,
    legs,
    knees,
    arms,
    fores,
    cape,
    mats,
    phase: Math.random() * 6,
    flashing: false,
  };
  poseRig(rig, idleAnim(0), 0);
  return rig;
}

export function idleAnim(time: number): Anim {
  return {
    speed: 0,
    attack: 0,
    attackDur: 0.4,
    combo: 0,
    throwing: 0,
    dodge: 0,
    dodgeSide: 1,
    hurt: 0,
    time,
    dead: 0,
  };
}

export function poseRig(r: Rig, a: Anim, dt: number) {
  r.phase += dt * (2.1 + Math.min(8, a.speed) * 1.35);
  const s = Math.sin(r.phase);
  const walk = Math.min(1, a.speed / 3.4);
  r.legs[0].rotation.x = s * 0.7 * walk;
  r.legs[1].rotation.x = -s * 0.7 * walk;
  r.knees[0].rotation.x = Math.max(0, -s) * 0.95 * walk;
  r.knees[1].rotation.x = Math.max(0, s) * 0.95 * walk;
  r.body.position.y = -Math.abs(Math.sin(r.phase)) * 0.035 * walk;
  r.torso.rotation.set(Math.sin(a.time * 1.6) * 0.02, 0, 0);
  r.head.rotation.set(-0.08, Math.sin(a.time * 0.7) * 0.05, 0);
  r.arms[0].rotation.set(0.22 + s * 0.35 * walk, 0, 0.22);
  r.arms[1].rotation.set(0.42 - s * 0.2 * walk, 0.1, -0.28);
  r.fores[0].rotation.set(-0.5, 0, 0);
  r.fores[1].rotation.set(-0.62, 0, 0);

  if (a.dead > 0) {
    const u = Math.min(1, a.dead / 0.7);
    r.body.rotation.x = u * 1.35;
    r.body.position.y = -u * 0.15;
    r.arms[0].rotation.x = 0.4;
    r.arms[1].rotation.x = 0.2;
    return;
  }
  r.body.rotation.x = 0;

  if (a.attack > 0) {
    const u = 1 - a.attack / Math.max(0.05, a.attackDur);
    const swing = Math.sin(Math.min(1, Math.max(0, u)) * Math.PI);
    if (a.combo === 0) {
      r.torso.rotation.y = -swing * 1.05;
      r.torso.rotation.x = -0.12 * swing;
      r.arms[1].rotation.set(-0.5 + u * 2.1, 0, -0.55);
      r.fores[1].rotation.x = -0.15;
    } else if (a.combo === 1) {
      r.torso.rotation.y = swing * 1.15;
      r.arms[1].rotation.set(-0.15, 0, 0.35 - u * 1.5);
      r.fores[1].rotation.x = -0.25;
    } else {
      r.torso.rotation.x = -0.55 + u * 1.25;
      r.arms[1].rotation.set(-2.5 + u * 3.5, 0, -0.15);
      r.fores[1].rotation.x = -0.05;
      r.body.position.y -= 0.04;
    }
  } else if (a.throwing > 0) {
    r.torso.rotation.y = -0.4 * a.throwing;
    r.torso.rotation.x = -0.1 * a.throwing;
    r.arms[1].rotation.set(-1.65 * a.throwing, 0, -0.1);
    r.fores[1].rotation.x = -0.05 * a.throwing;
  }

  if (a.dodge > 0) {
    r.torso.rotation.x = 0.85;
    r.body.rotation.z = a.dodgeSide * 0.28;
    r.body.position.y -= 0.12;
  } else {
    r.body.rotation.z = 0;
  }

  if (a.hurt > 0) r.torso.rotation.x += 0.4;

  if (r.cape) r.cape.rotation.x = 0.16 + Math.sin(a.time * 2.5) * 0.07 + walk * 0.22;

  const on = a.hurt > 0;
  if (r.flashing !== on) {
    r.flashing = on;
    for (const m of r.mats) m.emissive.setHex(on ? 0x7a1618 : 0x000000);
  }
}

export function destroyRig(rig: Rig, scene: THREE.Scene) {
  scene.remove(rig.root);
  for (const m of rig.mats) m.dispose();
}
