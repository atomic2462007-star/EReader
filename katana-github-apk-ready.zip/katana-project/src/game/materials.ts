import * as THREE from "three";

export type TexSet = {
  grass: THREE.CanvasTexture;
  gravel: THREE.CanvasTexture;
  stone: THREE.CanvasTexture;
  wood: THREE.CanvasTexture;
  plaster: THREE.CanvasTexture;
  tile: THREE.CanvasTexture;
  tatami: THREE.CanvasTexture;
  lacquer: THREE.CanvasTexture;
  banner: THREE.CanvasTexture;
  door: THREE.CanvasTexture;
  sky: THREE.CanvasTexture;
  glow: THREE.CanvasTexture;
  hamon: THREE.CanvasTexture;
  lacing: THREE.CanvasTexture;
  skin: THREE.CanvasTexture;
  water: THREE.CanvasTexture;
};

function cvs(
  w: number,
  h: number,
  aniso: number,
  fn: (g: CanvasRenderingContext2D, w: number, h: number) => void,
  repeat = true,
) {
  const c = document.createElement("canvas");
  c.width = w;
  c.height = h;
  const g = c.getContext("2d");
  if (!g) throw new Error("canvas");
  fn(g, w, h);
  const t = new THREE.CanvasTexture(c);
  if (repeat) {
    t.wrapS = THREE.RepeatWrapping;
    t.wrapT = THREE.RepeatWrapping;
  }
  t.colorSpace = THREE.SRGBColorSpace;
  t.anisotropy = aniso;
  return t;
}

export function makeTextures(aniso: number): TexSet {
  const rnd = (n: number) => {
    const x = Math.sin(n * 127.1 + 311.7) * 43758.5453;
    return x - Math.floor(x);
  };

  const grass = cvs(256, 256, aniso, (g, w, h) => {
    g.fillStyle = "#c5cbb8";
    g.fillRect(0, 0, w, h);
    for (let i = 0; i < 1800; i++) {
      const n = rnd(i + 3);
      g.fillStyle = n < 0.5 ? "rgba(255,255,255,.16)" : "rgba(20,30,10,.18)";
      g.fillRect(rnd(i) * w, rnd(i + 9) * h, 1, 2 + rnd(i + 4) * 5);
    }
  });

  const gravel = cvs(256, 256, aniso, (g, w, h) => {
    g.fillStyle = "#6d6858";
    g.fillRect(0, 0, w, h);
    for (let i = 0; i < 2400; i++) {
      g.fillStyle = rnd(i) < 0.5 ? "rgba(255,248,220,.12)" : "rgba(0,0,0,.16)";
      g.fillRect(rnd(i + 1) * w, rnd(i + 2) * h, 1 + rnd(i + 3) * 2.4, 1 + rnd(i + 4) * 2);
    }
  });

  const stone = cvs(256, 256, aniso, (g, w, h) => {
    g.fillStyle = "#2a2723";
    g.fillRect(0, 0, w, h);
    for (let r = 0; r < 4; r++) {
      for (let c = -1; c < 3; c++) {
        const x0 = c * 128 + (r % 2 ? 64 : 0);
        const y0 = r * 64;
        const l = 42 + rnd(r * 8 + c + 20) * 14;
        g.fillStyle = `hsl(36 6% ${l}%)`;
        g.fillRect(x0 + 2, y0 + 2, 124, 60);
        g.fillStyle = "rgba(255,255,255,.1)";
        g.fillRect(x0 + 2, y0 + 2, 124, 3);
      }
    }
  });

  const wood = cvs(256, 256, aniso, (g, w, h) => {
    for (let i = 0; i < 8; i++) {
      const l = 28 + rnd(i + 4) * 10;
      g.fillStyle = `hsl(24 34% ${l}%)`;
      g.fillRect(0, i * 32, w, 32);
      g.fillStyle = "rgba(0,0,0,.45)";
      g.fillRect(0, i * 32, w, 2);
      for (let k = 0; k < 10; k++) {
        g.fillStyle = "rgba(0,0,0,.08)";
        g.fillRect(rnd(i * 20 + k) * w, i * 32 + rnd(k + i) * 28, 40 + rnd(k) * 70, 1);
      }
    }
  });

  const plaster = cvs(256, 256, aniso, (g, w, h) => {
    g.fillStyle = "#d9d0bc";
    g.fillRect(0, 0, w, h);
    for (let i = 0; i < 900; i++) {
      g.fillStyle = `rgba(40,24,12,${rnd(i) * 0.06})`;
      g.fillRect(rnd(i + 2) * w, rnd(i + 5) * h, 2 + rnd(i) * 7, 1 + rnd(i + 1) * 3);
    }
    g.fillStyle = "#3a2416";
    g.fillRect(0, 0, 12, h);
    g.fillRect(0, 0, w, 10);
    g.fillRect(0, h - 10, w, 10);
  });

  const tile = cvs(256, 256, aniso, (g, w, h) => {
    g.fillStyle = "#2a2e36";
    g.fillRect(0, 0, w, h);
    for (let r = 0; r < 16; r++) {
      for (let c = 0; c < 8; c++) {
        const x0 = c * 32 + (r % 2 ? 16 : 0);
        const y0 = r * 16;
        const l = 16 + rnd(r * 3 + c) * 8;
        g.fillStyle = `hsl(218 10% ${l}%)`;
        g.beginPath();
        g.moveTo(x0 + 2, y0);
        g.lineTo(x0 + 30, y0);
        g.lineTo(x0 + 27, y0 + 14);
        g.lineTo(x0 + 5, y0 + 14);
        g.fill();
        g.fillStyle = "rgba(255,255,255,.06)";
        g.fillRect(x0 + 3, y0, 24, 2);
      }
    }
  });

  const tatami = cvs(256, 128, aniso, (g, w, h) => {
    g.fillStyle = "hsl(72 22% 46%)";
    g.fillRect(0, 0, w, h);
    for (let y = 2; y < h; y += 3) {
      g.fillStyle = "rgba(0,0,0,.06)";
      g.fillRect(0, y, w, 1);
    }
    g.fillStyle = "#1c1810";
    g.fillRect(0, 0, w, 7);
    g.fillRect(0, h - 7, w, 7);
    g.fillRect(0, 0, 4, h);
    g.fillRect(w - 4, 0, 4, h);
  });

  const lacquer = cvs(256, 256, aniso, (g, w, h) => {
    for (let i = 0; i < 4; i++) {
      for (let j = 0; j < 4; j++) {
        g.fillStyle = (i + j) % 2 ? "#241510" : "#311c16";
        g.fillRect(i * 64, j * 64, 64, 64);
      }
    }
    g.strokeStyle = "rgba(216,180,90,.35)";
    g.lineWidth = 2;
    for (let i = 0; i <= 4; i++) {
      g.beginPath();
      g.moveTo(i * 64, 0);
      g.lineTo(i * 64, h);
      g.moveTo(0, i * 64);
      g.lineTo(w, i * 64);
      g.stroke();
    }
  });

  const banner = cvs(128, 256, aniso, (g, w, h) => {
    g.fillStyle = "#8d1428";
    g.fillRect(0, 0, w, h);
    g.strokeStyle = "#d8b45a";
    g.lineWidth = 4;
    g.strokeRect(5, 5, w - 10, h - 10);
    g.fillStyle = "#d8b45a";
    g.beginPath();
    g.arc(w / 2, h * 0.42, 28, 0, Math.PI * 2);
    g.fill();
    g.fillStyle = "#8d1428";
    g.beginPath();
    g.arc(w / 2, h * 0.42, 16, 0, Math.PI * 2);
    g.fill();
    g.fillStyle = "#d8b45a";
    g.beginPath();
    g.arc(w / 2, h * 0.42, 7, 0, Math.PI * 2);
    g.fill();
  });

  const door = cvs(128, 256, aniso, (g, w, h) => {
    g.fillStyle = "#6e0e1c";
    g.fillRect(0, 0, w, h);
    g.strokeStyle = "#d8b45a";
    g.lineWidth = 4;
    g.strokeRect(4, 4, w - 8, h - 8);
    g.strokeRect(12, 12, w - 24, h - 24);
    g.fillStyle = "#d8b45a";
    for (let i = 0; i < 4; i++) {
      for (let j = 0; j < 8; j++) {
        g.beginPath();
        g.arc(22 + i * 26, 28 + j * 28, 2.4, 0, Math.PI * 2);
        g.fill();
      }
    }
  });

  const sky = cvs(
    1024,
    512,
    1,
    (g, w, h) => {
      const gr = g.createLinearGradient(0, 0, 0, h * 0.55);
      gr.addColorStop(0, "#07060f");
      gr.addColorStop(0.45, "#1a1430");
      gr.addColorStop(0.78, "#4a2040");
      gr.addColorStop(1, "#b85a48");
      g.fillStyle = gr;
      g.fillRect(0, 0, w, h);
      for (let i = 0; i < 420; i++) {
        g.fillStyle = `rgba(255,255,255,${0.25 + rnd(i) * 0.75})`;
        g.fillRect(rnd(i + 2) * w, rnd(i + 8) * h * 0.42, 1 + rnd(i) * 1.3, 1 + rnd(i + 3) * 1.3);
      }
      g.fillStyle = "#140910";
      g.beginPath();
      g.moveTo(0, h * 0.58);
      for (let x = 0; x <= w; x += 8) {
        const y =
          h * 0.5 -
          26 * (Math.sin(x * 0.02) * 0.5 + Math.sin(x * 0.007 + 1) * 0.5 + 1) * 0.35;
        g.lineTo(x, y);
      }
      g.lineTo(w, h);
      g.lineTo(0, h);
      g.fill();
    },
    false,
  );

  const glow = cvs(
    128,
    128,
    1,
    (g, w, h) => {
      const gr = g.createRadialGradient(64, 64, 0, 64, 64, 64);
      gr.addColorStop(0, "rgba(255,170,90,.95)");
      gr.addColorStop(0.35, "rgba(255,90,40,.35)");
      gr.addColorStop(1, "rgba(255,60,20,0)");
      g.fillStyle = gr;
      g.fillRect(0, 0, w, h);
    },
    false,
  );

  const hamon = cvs(64, 256, aniso, (g, w, h) => {
    const gr = g.createLinearGradient(0, 0, w, 0);
    gr.addColorStop(0, "#8ea0b4");
    gr.addColorStop(0.45, "#f4f7fb");
    gr.addColorStop(1, "#9aabbc");
    g.fillStyle = gr;
    g.fillRect(0, 0, w, h);
    g.strokeStyle = "rgba(180,200,220,.85)";
    g.lineWidth = 2;
    g.beginPath();
    g.moveTo(w * 0.55, 0);
    for (let y = 0; y <= h; y += 8) g.lineTo(w * 0.5 + Math.sin(y * 0.18) * 6, y);
    g.stroke();
  });

  const lacing = cvs(128, 128, aniso, (g, w, h) => {
    g.fillStyle = "#1a1c22";
    g.fillRect(0, 0, w, h);
    for (let y = 0; y < h; y += 8) {
      g.fillStyle = y % 16 === 0 ? "#2a3140" : "#3a2a30";
      g.fillRect(0, y, w, 6);
      g.fillStyle = "rgba(216,180,90,.35)";
      for (let x = (y / 8) % 2 === 0 ? 4 : 10; x < w; x += 14) g.fillRect(x, y, 2, 6);
    }
  });

  const skin = cvs(128, 128, aniso, (g, w, h) => {
    g.fillStyle = "#e6c2a4";
    g.fillRect(0, 0, w, h);
    for (let i = 0; i < 500; i++) {
      g.fillStyle = `rgba(90,40,30,${rnd(i) * 0.08})`;
      g.fillRect(rnd(i + 1) * w, rnd(i + 2) * h, 2, 2);
    }
  });

  const water = cvs(256, 256, aniso, (g, w, h) => {
    g.fillStyle = "#1a5870";
    g.fillRect(0, 0, w, h);
    g.strokeStyle = "rgba(220,245,255,.18)";
    g.lineWidth = 2;
    for (let k = 0; k < 18; k++) {
      g.beginPath();
      const y = (k / 18) * h;
      g.moveTo(0, y);
      for (let x = 0; x <= w; x += 12) g.lineTo(x, y + Math.sin(x * 0.08 + k) * 4);
      g.stroke();
    }
  });

  return {
    grass,
    gravel,
    stone,
    wood,
    plaster,
    tile,
    tatami,
    lacquer,
    banner,
    door,
    sky,
    glow,
    hamon,
    lacing,
    skin,
    water,
  };
}

export function repeat(tex: THREE.Texture, x: number, y: number) {
  const c = tex.clone();
  c.repeat.set(x, y);
  c.needsUpdate = true;
  return c;
}
