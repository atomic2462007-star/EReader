# EReader — قارئ كتب إلكترونية (Android / Kotlin / Compose)

## طريقة إنتاج ملف APK
1. ثبّت **Android Studio** (إصدار Ladybug أو أحدث) ثم `File > Open` واختر مجلد `EReader`.
2. انتظر انتهاء Gradle Sync (يحتاج إنترنت مرة واحدة لتحميل المكتبات).
3. من القائمة: `Build > Build Bundle(s) / APK(s) > Build APK(s)`
   - أو من الطرفية: `./gradlew assembleRelease` (محسّن وأصغر حجمًا، موقّع بمفتاح debug فيصلح للتثبيت الشخصي)
   - أو `./gradlew assembleDebug`
4. الملف يظهر في: `app/build/outputs/apk/release/app-release.apk`
5. انقله للهاتف وثبّته (فعّل "التثبيت من مصادر غير معروفة").

> إن لم يوجد `gradlew` في المجلد فـ Android Studio ينشئ ما يلزم تلقائيًا عند أول Sync (الإصدار المطلوب Gradle 8.9 مكتوب في gradle-wrapper.properties).

## هيكل المشروع
- `data/` قاعدة Room: الكتب (مع إعدادات كل كتاب ومكان التوقف) والعلامات المرجعية + استيراد الملفات
- `epub/EpubParser.kt` قراءة EPUB (ZIP + OPF + NCX/nav + XHTML → فقرات وعناوين) دون مكتبات خارجية
- `reader/Paginator.kt` تقسيم النص إلى صفحات بـ StaticLayout (يدعم RTL والتبرير)
- `reader/PdfDoc.kt` عرض PDF عبر PdfRenderer المدمج
- `ui/` Compose: المكتبة، القارئ، شريط الأدوات، الإعدادات

## ملاحظات
- لا توجد صلاحية INTERNET ولا أي مكتبة تحليلات ⇒ يعمل دون إنترنت ولا يجمع بيانات.
- الكتب تُنسخ إلى تخزين التطبيق الخاص ليبقى الكتاب متاحًا حتى لو نُقل الملف الأصلي.
- أنواع الخطوط: خطوط النظام (Serif / Sans / Mono). لإضافة خط .ttf ضعه في `res/font` وأضفه في `Paginator.typeface`.
- حدود النسخة الأولى: صور داخل نص EPUB لا تُعرض (الغلاف فقط)، وPDF المحمي بكلمة مرور غير مدعوم.
