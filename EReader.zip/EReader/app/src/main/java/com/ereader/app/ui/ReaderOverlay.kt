package com.ereader.app.ui

import android.app.Activity
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.List
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.TextFields
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ereader.app.AppViewModel
import com.ereader.app.data.BookEntity
import com.ereader.app.data.BookmarkEntity
import kotlin.math.roundToInt

class ReaderUiState { var bars by mutableStateOf(false) }
data class TocItem(val title: String, val chapter: Int)

fun setBrightness(activity: Activity, v: Float) {
    val lp = activity.window.attributes
    lp.screenBrightness = v   // -1 = سطوع النظام
    activity.window.attributes = lp
}

private enum class Sheet { None, Settings, Contents }
private val BarBg = Color(0xF2121212)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReaderOverlay(
    book: BookEntity, vm: AppViewModel, ui: ReaderUiState, isPdf: Boolean,
    pageIndex: Int, pageCount: Int, topLabel: String?,
    toc: List<TocItem>, bookmarks: List<BookmarkEntity>, bookmarked: Boolean,
    onBack: () -> Unit, onToggleBookmark: () -> Unit,
    onJumpBookmark: (BookmarkEntity) -> Unit, onJumpToc: (TocItem) -> Unit,
    onGoToPage: (Int) -> Unit
) {
    var sheet by remember { mutableStateOf(Sheet.None) }
    var showGoto by remember { mutableStateOf(false) }
    val bookDir = if (book.isRtl) LayoutDirection.Rtl else LayoutDirection.Ltr
    val progress = if (pageCount > 0) (pageIndex + 1f) / pageCount else 0f

    Box(Modifier.fillMaxSize()) {
        // شريط تقدم رفيع دائم
        CompositionLocalProvider(LocalLayoutDirection provides bookDir) {
            LinearProgressIndicator(
                progress = { progress.coerceIn(0f, 1f) },
                modifier = Modifier.align(Alignment.BottomCenter).fillMaxWidth().height(2.dp),
                color = Color(0xFF8E8E8E), trackColor = Color.Transparent
            )
        }
        // رقم الصفحة في المنتصف أسفل الصفحة
        Text(
            "${pageIndex + 1}", color = Color(0xFF8E8E8E), fontSize = 13.sp,
            modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 16.dp)
        )
        if (!ui.bars && !topLabel.isNullOrBlank()) {
            Text(
                topLabel, color = Color(0xFF6E6E6E), fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                modifier = Modifier.align(Alignment.TopCenter).padding(top = 14.dp, start = 48.dp, end = 48.dp)
            )
        }

        AnimatedVisibility(
            ui.bars, Modifier.align(Alignment.TopCenter),
            enter = fadeIn() + slideInVertically { -it }, exit = fadeOut() + slideOutVertically { -it }
        ) {
            Row(
                Modifier.fillMaxWidth().background(BarBg).statusBarsPadding()
                    .pointerInput(Unit) { detectTapGestures { } }
                    .padding(horizontal = 4.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "رجوع", tint = Color.White) }
                Text(
                    book.title, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Medium,
                    maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f)
                )
                IconButton(onToggleBookmark) {
                    Icon(
                        if (bookmarked) Icons.Default.Bookmark else Icons.Default.BookmarkBorder,
                        "علامة مرجعية", tint = if (bookmarked) Color(0xFFFFD54F) else Color.White
                    )
                }
                IconButton({ sheet = Sheet.Contents }) { Icon(Icons.AutoMirrored.Filled.List, "الفهرس والعلامات", tint = Color.White) }
                IconButton({ sheet = Sheet.Settings }) { Icon(Icons.Default.TextFields, "إعدادات القراءة", tint = Color.White) }
            }
        }

        AnimatedVisibility(
            ui.bars, Modifier.align(Alignment.BottomCenter),
            enter = fadeIn() + slideInVertically { it }, exit = fadeOut() + slideOutVertically { it }
        ) {
            Column(
                Modifier.fillMaxWidth().background(BarBg).navigationBarsPadding()
                    .pointerInput(Unit) { detectTapGestures { } }
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("${(progress * 100).roundToInt()}%", color = Color(0xFFBDBDBD), fontSize = 13.sp)
                    Spacer(Modifier.weight(1f))
                    TextButton({ showGoto = true }) { Text("صفحة ${pageIndex + 1} من $pageCount  ·  انتقال", color = Color.White, fontSize = 13.sp) }
                }
                var drag by remember { mutableStateOf<Float?>(null) }
                CompositionLocalProvider(LocalLayoutDirection provides bookDir) {
                    Slider(
                        value = drag ?: pageIndex.toFloat(),
                        onValueChange = { drag = it },
                        onValueChangeFinished = { drag?.let { onGoToPage(it.roundToInt()) }; drag = null },
                        valueRange = 0f..(pageCount - 1).coerceAtLeast(1).toFloat(),
                        colors = SliderDefaults.colors(
                            thumbColor = Color.White, activeTrackColor = Color(0xFFCCCCCC), inactiveTrackColor = Color(0xFF3A3A3A)
                        )
                    )
                }
                Spacer(Modifier.height(10.dp))
            }
        }
    }

    if (sheet != Sheet.None) {
        ModalBottomSheet(onDismissRequest = { sheet = Sheet.None }, containerColor = Color(0xFF151515)) {
            if (sheet == Sheet.Settings) {
                SettingsContent(book, vm, isPdf)
            } else {
                ContentsContent(
                    toc, bookmarks,
                    onToc = { sheet = Sheet.None; onJumpToc(it) },
                    onBookmark = { sheet = Sheet.None; onJumpBookmark(it) },
                    onDelete = { vm.deleteBookmark(it.id) }
                )
            }
            Spacer(Modifier.navigationBarsPadding().height(12.dp))
        }
    }

    if (showGoto) {
        var text by remember { mutableStateOf("${pageIndex + 1}") }
        val submit = {
            text.toIntOrNull()?.let { if (it in 1..pageCount) { onGoToPage(it - 1); showGoto = false } }
            Unit
        }
        AlertDialog(
            onDismissRequest = { showGoto = false },
            title = { Text("الانتقال إلى صفحة") },
            text = {
                OutlinedTextField(
                    value = text, onValueChange = { text = it.filter(Char::isDigit).take(6) },
                    singleLine = true, label = { Text("من 1 إلى $pageCount") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                )
            },
            confirmButton = { TextButton({ submit() }) { Text("انتقال") } },
            dismissButton = { TextButton({ showGoto = false }) { Text("إلغاء") } }
        )
    }
}

@Composable
private fun SectionTitle(t: String) = Text(t, fontSize = 14.sp, color = Color(0xFF9A9A9A), fontWeight = FontWeight.Medium)

@Composable
private fun SettingsContent(book: BookEntity, vm: AppViewModel, isPdf: Boolean) {
    val activity = LocalContext.current as Activity
    Column(
        Modifier.verticalScroll(rememberScrollState()).padding(horizontal = 20.dp).padding(bottom = 12.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        if (!isPdf) {
            SectionTitle("حجم الخط")
            var size by remember(book.fontSizeSp) { mutableFloatStateOf(book.fontSizeSp) }
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton({ vm.saveText(book.id, (size - 1f).coerceAtLeast(14f), book.fontFamily, book.lineSpacing) }) { Icon(Icons.Default.Remove, "تصغير") }
                Slider(
                    value = size, onValueChange = { size = it },
                    onValueChangeFinished = { vm.saveText(book.id, size.roundToInt().toFloat(), book.fontFamily, book.lineSpacing) },
                    valueRange = 14f..40f, modifier = Modifier.weight(1f)
                )
                IconButton({ vm.saveText(book.id, (size + 1f).coerceAtMost(40f), book.fontFamily, book.lineSpacing) }) { Icon(Icons.Default.Add, "تكبير") }
                Text("${size.roundToInt()}", fontSize = 14.sp, modifier = Modifier.width(28.dp))
            }

            SectionTitle("نوع الخط")
            val fonts = listOf("serif" to "نسخ (Serif)", "sans" to "Sans", "sans_medium" to "Sans متوسط", "mono" to "Mono")
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                fonts.forEach { (k, l) ->
                    FilterChip(
                        selected = book.fontFamily == k,
                        onClick = { vm.saveText(book.id, book.fontSizeSp, k, book.lineSpacing) },
                        label = { Text(l) }
                    )
                }
            }

            SectionTitle("تباعد الأسطر")
            var ls by remember(book.lineSpacing) { mutableFloatStateOf(book.lineSpacing) }
            Slider(
                value = ls, onValueChange = { ls = it },
                onValueChangeFinished = { vm.saveText(book.id, book.fontSizeSp, book.fontFamily, ls) },
                valueRange = 1.1f..2.2f
            )
        } else {
            SectionTitle("الوضع الليلي لملف PDF")
            val modes = listOf(0 to "عادي", 1 to "ليلي", 2 to "ليلي (يحفظ ألوان الصور)")
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                modes.forEach { (k, l) ->
                    FilterChip(selected = book.pdfNight == k, onClick = { vm.savePdfNight(book.id, k) }, label = { Text(l) })
                }
            }
            Text("تكبير وتصغير: بإصبعين، أو بالنقر مرتين على الصفحة.", fontSize = 12.sp, color = Color(0xFF8A8A8A))
        }

        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("تقليب الصفحات من اليمين إلى اليسار", Modifier.weight(1f), fontSize = 14.sp)
            Switch(book.isRtl, { vm.saveRtl(book.id, it) })
        }

        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("سطوع الشاشة", Modifier.weight(1f), fontSize = 14.sp)
            Text("تلقائي", fontSize = 13.sp, color = Color(0xFF9A9A9A))
            Spacer(Modifier.width(8.dp))
            Switch(
                checked = book.brightness < 0,
                onCheckedChange = { auto -> vm.saveBrightness(book.id, if (auto) -1f else 0.5f) }
            )
        }
        if (book.brightness >= 0) {
            var br by remember(book.brightness) { mutableFloatStateOf(book.brightness) }
            Slider(
                value = br,
                onValueChange = { br = it; setBrightness(activity, it) },
                onValueChangeFinished = { vm.saveBrightness(book.id, br) },
                valueRange = 0.02f..1f
            )
        }
    }
}

@Composable
private fun ContentsContent(
    toc: List<TocItem>, bookmarks: List<BookmarkEntity>,
    onToc: (TocItem) -> Unit, onBookmark: (BookmarkEntity) -> Unit, onDelete: (BookmarkEntity) -> Unit
) {
    var tab by remember { mutableIntStateOf(if (toc.isNotEmpty()) 0 else 1) }
    Column {
        if (toc.isNotEmpty()) {
            TabRow(selectedTabIndex = tab, containerColor = Color.Transparent) {
                Tab(tab == 0, { tab = 0 }) { Text("الفهرس", Modifier.padding(14.dp)) }
                Tab(tab == 1, { tab = 1 }) { Text("العلامات (${bookmarks.size})", Modifier.padding(14.dp)) }
            }
        } else {
            Text("العلامات المرجعية", Modifier.padding(horizontal = 20.dp, vertical = 8.dp), fontWeight = FontWeight.Bold)
        }
        LazyColumn(Modifier.fillMaxWidth().heightIn(max = 460.dp)) {
            if (tab == 0 && toc.isNotEmpty()) {
                items(toc) { t ->
                    Text(
                        t.title, maxLines = 2, overflow = TextOverflow.Ellipsis, fontSize = 15.sp,
                        modifier = Modifier.fillMaxWidth().clickable { onToc(t) }.padding(horizontal = 20.dp, vertical = 14.dp)
                    )
                }
            } else if (bookmarks.isEmpty()) {
                item {
                    Text(
                        "لا توجد علامات بعد. اضغط على أيقونة العلامة في الشريط العلوي لإضافة علامة للصفحة الحالية.",
                        color = Color(0xFF8A8A8A), fontSize = 13.sp, modifier = Modifier.padding(20.dp)
                    )
                }
            } else {
                items(bookmarks) { b ->
                    Row(
                        Modifier.fillMaxWidth().clickable { onBookmark(b) }.padding(start = 20.dp, end = 8.dp, top = 6.dp, bottom = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Bookmark, null, tint = Color(0xFFFFD54F), modifier = Modifier.size(20.dp))
                        Spacer(Modifier.width(12.dp))
                        Text(b.label, Modifier.weight(1f), maxLines = 2, overflow = TextOverflow.Ellipsis, fontSize = 14.sp)
                        IconButton({ onDelete(b) }) { Icon(Icons.Default.Delete, "حذف", tint = Color(0xFF9A9A9A)) }
                    }
                }
            }
        }
    }
}
